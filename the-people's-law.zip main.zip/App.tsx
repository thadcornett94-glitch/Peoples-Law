import React, { useState, useRef, useEffect } from 'react';
import { Sidebar } from './components/Sidebar';
import { MessageBubble } from './components/MessageBubble';
import { DisclaimerModal } from './components/DisclaimerModal';
import { CaseLawExplorer } from './components/CaseLawExplorer';
import { LearningPath } from './components/LearningPath';
import { QuizMode } from './components/QuizMode';
import { PoliceEncounterGuide } from './components/PoliceEncounterGuide';
import { KnowYourRights } from './components/KnowYourRights';
import { Glossary } from './components/Glossary';
import { CivicsGuide } from './components/CivicsGuide';
import { DraftingLab } from './components/DraftingLab';
import { ScotusDocket } from './components/ScotusDocket';
import { StateLaws } from './components/StateLaws';
import { FoundingDocuments } from './components/FoundingDocuments';
import { Briefcase } from './components/Briefcase';
import { EducatorMode } from './components/EducatorMode';
import { TourModal } from './components/TourModal';
import { Tribute } from './components/Tribute';
import { JurySimulator } from './components/JurySimulator';
import { DeploymentGuide } from './components/DeploymentGuide';
import { GlobalRightsMap } from './components/GlobalRightsMap';
import { DebateDojo } from './components/DebateDojo';
import { CommonLawGuide } from './components/CommonLawGuide';
import { sendMessageStream, resetChat } from './services/geminiService';
import { Message, Role, ChatState, AppView, TutorMode, Bookmark, UserStats } from './types';
import { INITIAL_QUESTIONS, LEGAL_FACTS } from './constants';

export const App: React.FC = () => {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [showDisclaimer, setShowDisclaimer] = useState(true);
  const [showTour, setShowTour] = useState(false);
  const [currentView, setCurrentView] = useState<AppView>('chat');
  
  const [inputValue, setInputValue] = useState('');
  const [isListening, setIsListening] = useState(false);
  const [dailyFact, setDailyFact] = useState('');
  
  // Interactive Feature: Tutor Mode
  const [tutorMode, setTutorMode] = useState<TutorMode>('standard');
  
  // Text Size Preference
  const [textSize, setTextSize] = useState<'small' | 'normal' | 'large'>('normal');

  // Voice Preference: 'Fenrir' (Male) or 'Kore' (Female)
  const [voicePreference, setVoicePreference] = useState<string>(() => {
    return localStorage.getItem('amicus_voice_pref') || 'Fenrir';
  });

  const handleVoiceChange = (voice: string) => {
    setVoicePreference(voice);
    localStorage.setItem('amicus_voice_pref', voice);
  };

  // Calculate base font size class based on preference
  const getTextSizeClass = () => {
      switch (textSize) {
          case 'small': return 'text-sm';
          case 'large': return 'text-lg';
          default: return 'text-base';
      }
  };

  // User Stats (Adaptive Learning)
  const [userStats, setUserStats] = useState<UserStats>(() => {
    try {
        const saved = localStorage.getItem('amicus_user_stats');
        return saved ? JSON.parse(saved) : { 
            xp: 0, 
            level: 'Law Student', 
            topicScores: {},
            questionsAnswered: 0
        };
    } catch (e) {
        return { xp: 0, level: 'Law Student', topicScores: {}, questionsAnswered: 0 };
    }
  });

  useEffect(() => {
    localStorage.setItem('amicus_user_stats', JSON.stringify(userStats));
  }, [userStats]);

  const handleQuizResult = (topic: string, isCorrect: boolean) => {
      setUserStats(prev => {
          const newXP = isCorrect ? prev.xp + 10 : prev.xp;
          const currentTopicScore = prev.topicScores[topic] || 0;
          const newTopicScore = isCorrect ? currentTopicScore + 1 : currentTopicScore - 1;
          
          let newLevel: UserStats['level'] = prev.level;
          if (newXP > 100) newLevel = 'Associate';
          if (newXP > 500) newLevel = 'Senior Counsel';
          if (newXP > 1000) newLevel = 'Partner';

          return {
              ...prev,
              xp: newXP,
              level: newLevel,
              questionsAnswered: prev.questionsAnswered + 1,
              topicScores: {
                  ...prev.topicScores,
                  [topic]: newTopicScore
              }
          };
      });
  };

  // Bookmark State
  const [bookmarks, setBookmarks] = useState<Bookmark[]>(() => {
    try {
        const saved = localStorage.getItem('amicus_bookmarks');
        return saved ? JSON.parse(saved) : [];
    } catch (e) {
        return [];
    }
  });

  useEffect(() => {
    localStorage.setItem('amicus_bookmarks', JSON.stringify(bookmarks));
  }, [bookmarks]);

  const toggleBookmark = (item: Bookmark) => {
    setBookmarks(prev => {
        const exists = prev.find(b => b.id === item.id);
        if (exists) {
            return prev.filter(b => b.id !== item.id);
        } else {
            return [...prev, item];
        }
    });
  };

  const removeBookmark = (id: string) => {
      setBookmarks(prev => prev.filter(b => b.id !== id));
  };

  // Chat State
  const [chatState, setChatState] = useState<ChatState>({
    messages: [],
    isLoading: false,
    error: null,
  });

  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Initialize
  useEffect(() => {
    // Pick a random fact
    const fact = LEGAL_FACTS[Math.floor(Math.random() * LEGAL_FACTS.length)];
    setDailyFact(fact);

    // Check localStorage for disclaimer acceptance
    const accepted = localStorage.getItem('amicus_disclaimer_accepted');
    if (accepted === 'true') {
        setShowDisclaimer(false);
        // Check for first time tour
        const tourTaken = localStorage.getItem('amicus_tour_taken');
        if (!tourTaken) {
            setShowTour(true);
        }
    }
  }, []);

  const handleDisclaimerAccept = () => {
      localStorage.setItem('amicus_disclaimer_accepted', 'true');
      setShowDisclaimer(false);
      setShowTour(true); // Always show tour on first accept
  };

  const handleTourClose = () => {
      localStorage.setItem('amicus_tour_taken', 'true');
      setShowTour(false);
  };

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [chatState.messages]);

  const handleSend = async (message: string) => {
    if (!message.trim()) return;

    // Switch to chat view if not already there
    if (currentView !== 'chat') {
        setCurrentView('chat');
    }

    const userMessage: Message = {
      id: Date.now().toString(),
      role: Role.USER,
      content: message,
      timestamp: new Date(),
    };

    setChatState((prev) => ({
      ...prev,
      messages: [...prev.messages, userMessage],
      isLoading: true,
      error: null,
    }));
    setInputValue('');

    try {
      const stream = sendMessageStream(message, tutorMode, userStats);
      
      const modelMessageId = (Date.now() + 1).toString();
      let modelContent = "";

      for await (const chunk of stream) {
        modelContent = chunk.text;
        setChatState((prev) => {
          const newMessages = [...prev.messages];
          // Check if the last message is from model and has the same ID (streaming update)
          const lastMsg = newMessages[newMessages.length - 1];
          
          if (lastMsg && lastMsg.role === Role.MODEL && lastMsg.id === modelMessageId) {
             lastMsg.content = modelContent;
             lastMsg.groundingSources = chunk.groundingSources;
             return { ...prev, messages: newMessages };
          } else {
             // New message from model
             return {
                 ...prev,
                 messages: [...newMessages, {
                     id: modelMessageId,
                     role: Role.MODEL,
                     content: modelContent,
                     isStreaming: true,
                     groundingSources: chunk.groundingSources,
                     timestamp: new Date()
                 }]
             };
          }
        });
      }

      // Finalize message (remove streaming flag)
      setChatState(prev => {
          const newMessages = [...prev.messages];
          const lastMsg = newMessages[newMessages.length - 1];
          if (lastMsg && lastMsg.role === Role.MODEL) {
              lastMsg.isStreaming = false;
          }
          return { ...prev, messages: newMessages, isLoading: false };
      });

    } catch (error) {
      setChatState((prev) => ({
        ...prev,
        isLoading: false,
        error: "An error occurred. Please try again.",
      }));
    }
  };

  const recognitionRef = useRef<any>(null);

  const handleVoiceInput = () => {
    if (isListening) {
      if (recognitionRef.current) {
        recognitionRef.current.stop();
        setIsListening(false);
      }
      return;
    }

    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (SpeechRecognition) {
      const recognition = new SpeechRecognition();
      recognitionRef.current = recognition;
      recognition.continuous = false;
      recognition.lang = 'en-US';
      recognition.interimResults = false;

      recognition.onstart = () => {
        setIsListening(true);
      };

      recognition.onresult = (event: any) => {
        const transcript = event.results[0][0].transcript;
        setInputValue(transcript);
        
        // Voice Command: "Send message" or "Send it"
        if (transcript.toLowerCase().includes('send message') || transcript.toLowerCase().includes('send it')) {
           const cleanText = transcript.replace(/send message/i, '').replace(/send it/i, '').trim();
           if (cleanText) {
               handleSend(cleanText);
           }
        }
      };

      recognition.onerror = (event: any) => {
        console.error("Speech recognition error", event.error);
        setIsListening(false);
        alert("Microphone access blocked or not available.");
      };

      recognition.onend = () => {
        setIsListening(false);
      };

      recognition.start();
    } else {
      alert("Voice input is not supported in this browser.");
    }
  };

  const handleClearChat = () => {
      resetChat();
      setChatState({ messages: [], isLoading: false, error: null });
      localStorage.removeItem('amicus_chat_history'); // Clear persistence
  };

  // Keyboard Shortcut: Ctrl+K to Focus Input
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
        if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
            e.preventDefault();
            const input = document.getElementById('main-chat-input');
            const search = document.getElementById('library-search-input');
            if (currentView === 'explorer' && search) {
                search.focus();
            } else if (input) {
                input.focus();
            }
        }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [currentView]);


  return (
    <div className={`flex h-full ${getTextSizeClass()}`}>
      
      {showDisclaimer && <DisclaimerModal onAccept={handleDisclaimerAccept} />}
      <TourModal isOpen={showTour} onClose={handleTourClose} />

      <Sidebar 
         onClear={handleClearChat} 
         isOpen={sidebarOpen} 
         toggleSidebar={() => setSidebarOpen(!sidebarOpen)}
         currentView={currentView}
         onChangeView={setCurrentView}
         textSize={textSize}
         onTextSizeChange={setTextSize}
         userStats={userStats}
         voicePreference={voicePreference}
         onVoiceChange={handleVoiceChange}
      />

      <main className="flex-1 flex flex-col h-full relative overflow-hidden bg-[#e7e5e0]">
        
        {/* Mobile Header */}
        <div className="md:hidden h-16 bg-[#1c1917] border-b border-stone-800 flex items-center justify-between px-4 shrink-0 z-10 shadow-md">
            <div className="flex items-center gap-2">
                <span className="text-amber-600">
                    <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 6l3 1m0 0l-3 9a5.002 5.002 0 006.001 0M6 7l3 9M6 7l6-2m6 2l3-1m-3 1l-3 9a5.002 5.002 0 006.001 0M18 7l3 9m-3-9l-6-2m0-2v2m0 16V5m0 16H9m3 0h3" />
                    </svg>
                </span>
                <span className="text-stone-100 font-serif font-bold text-lg">The People's Law</span>
            </div>
            <button onClick={() => setSidebarOpen(true)} className="text-stone-400 p-2">
                <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
                </svg>
            </button>
        </div>

        {/* View Routing */}
        {currentView === 'chat' ? (
             <div className="flex-1 overflow-y-auto p-4 md:p-8 scroll-smooth" style={{ paddingBottom: '160px' }}>
                <div className="max-w-3xl mx-auto">
                    {chatState.messages.length === 0 ? (
                        <div className="flex flex-col items-center justify-center min-h-[60vh] text-center animate-fade-in space-y-8">
                            
                            <div className="mb-4 relative">
                                <div className="absolute inset-0 bg-amber-500 blur-3xl opacity-10 rounded-full"></div>
                                <h2 className="relative text-lg font-serif italic text-stone-500 mb-4 opacity-80">"The most sacred of the duties of a government is to do equal and impartial justice to all its citizens." — Thomas Jefferson</h2>
                                <svg className="w-24 h-24 text-stone-800 relative z-10" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={0.8} d="M3 6l3 1m0 0l-3 9a5.002 5.002 0 006.001 0M6 7l3 9M6 7l6-2m6 2l3-1m-3 1l-3 9a5.002 5.002 0 006.001 0M18 7l3 9m-3-9l-6-2m0-2v2m0 16V5m0 16H9m3 0h3" />
                                </svg>
                            </div>

                            <div>
                                <h1 className="text-4xl md:text-5xl font-serif font-bold text-stone-900 mb-3 tracking-tight">The People's Law</h1>
                                <p className="text-stone-500 text-lg md:text-xl font-light">The Civics Operating System for US Law & Rights.</p>
                            </div>

                            {dailyFact && (
                                <div className="bg-white/60 p-4 rounded-xl border border-stone-200/50 max-w-lg shadow-sm backdrop-blur-sm">
                                    <span className="text-[10px] font-bold uppercase tracking-widest text-amber-700 block mb-1">Legal Fact of the Day</span>
                                    <p className="text-stone-700 text-sm font-serif italic">{dailyFact}</p>
                                </div>
                            )}

                            <div className="grid grid-cols-1 md:grid-cols-2 gap-3 w-full max-w-2xl mt-8">
                                {INITIAL_QUESTIONS.map((q) => (
                                    <button
                                        key={q.id}
                                        onClick={() => handleSend(q.prompt)}
                                        className="text-left p-4 rounded-xl bg-white border border-stone-200 hover:border-amber-400 hover:shadow-md transition-all group"
                                    >
                                        <div className="font-bold text-stone-800 group-hover:text-amber-800 mb-1">{q.title}</div>
                                        <div className="text-sm text-stone-500">{q.subtitle}</div>
                                    </button>
                                ))}
                            </div>
                        </div>
                    ) : (
                        <div className="space-y-6 pb-4">
                            {chatState.messages.map((msg) => (
                                <MessageBubble key={msg.id} message={msg} voicePreference={voicePreference} />
                            ))}
                            <div ref={messagesEndRef} />
                        </div>
                    )}
                </div>
             </div>
        ) : currentView === 'explorer' ? (
             <CaseLawExplorer onSelectCase={handleSend} bookmarks={bookmarks} onToggleBookmark={toggleBookmark} />
        ) : currentView === 'learning' ? (
             <LearningPath 
                completedTopics={new Set()} 
                onToggleComplete={() => {}} 
                onStartTopic={handleSend} 
             />
        ) : currentView === 'quiz' ? (
             <QuizMode userStats={userStats} onQuizResult={handleQuizResult} />
        ) : currentView === 'police_guide' ? (
             <PoliceEncounterGuide onGenerateAdvice={handleSend} />
        ) : currentView === 'know_rights' ? (
             <KnowYourRights onSelectTopic={handleSend} />
        ) : currentView === 'glossary' ? (
             <Glossary onSelectTerm={handleSend} bookmarks={bookmarks} onToggleBookmark={toggleBookmark} />
        ) : currentView === 'civics' ? (
             <CivicsGuide onAsk={handleSend} />
        ) : currentView === 'drafting' ? (
             <DraftingLab onSelectTemplate={handleSend} />
        ) : currentView === 'scotus' ? (
             <ScotusDocket onSelectCase={handleSend} bookmarks={bookmarks} onToggleBookmark={toggleBookmark} />
        ) : currentView === 'state_laws' ? (
             <StateLaws onSelectStateTopic={handleSend} />
        ) : currentView === 'founding_docs' ? (
             <FoundingDocuments onSelectDoc={handleSend} bookmarks={bookmarks} onToggleBookmark={toggleBookmark} />
        ) : currentView === 'briefcase' ? (
             <Briefcase bookmarks={bookmarks} onRemove={removeBookmark} onSelect={handleSend} />
        ) : currentView === 'educator' ? (
             <EducatorMode onSelectAction={handleSend} />
        ) : currentView === 'tribute' ? (
             <Tribute onSelectPrompt={handleSend} />
        ) : currentView === 'jury' ? (
             <JurySimulator onSelectAction={handleSend} />
        ) : currentView === 'deployment' ? (
             <DeploymentGuide />
        ) : currentView === 'global_map' ? (
             <GlobalRightsMap onSelectRegion={handleSend} />
        ) : currentView === 'debate_dojo' ? (
             <DebateDojo onSelectAction={handleSend} />
        ) : currentView === 'common_law' ? (
             <CommonLawGuide onSelectAction={handleSend} />
        ) : null}

        {/* Floating Input Area (Chat Only) */}
        {currentView === 'chat' && (
             <div className="absolute bottom-0 left-0 right-0 p-4 md:p-6 bg-gradient-to-t from-[#e7e5e0] via-[#e7e5e0] to-transparent pt-20">
                <div className="max-w-3xl mx-auto relative animate-slide-up">
                    
                    {/* Tutor Mode Toggle */}
                    <div className="absolute -top-10 left-0 flex items-center gap-2">
                        <span className={`text-xs font-bold uppercase tracking-wide ${tutorMode === 'socratic' ? 'text-purple-700' : 'text-stone-500'}`}>
                            {tutorMode === 'socratic' ? 'Tutor Mode Active' : 'Tutor Mode Off'}
                        </span>
                        <button 
                            onClick={() => {
                                const newMode = tutorMode === 'standard' ? 'socratic' : 'standard';
                                setTutorMode(newMode);
                                resetChat(); // Reset context when switching modes
                            }}
                            className={`w-10 h-5 rounded-full relative transition-colors duration-300 ${tutorMode === 'socratic' ? 'bg-purple-600' : 'bg-stone-300'}`}
                        >
                            <div className={`absolute top-1 left-1 w-3 h-3 bg-white rounded-full transition-transform duration-300 shadow-sm ${tutorMode === 'socratic' ? 'translate-x-5' : 'translate-x-0'}`} />
                        </button>
                    </div>

                    <div className="relative bg-white shadow-2xl rounded-[2rem] flex items-center p-2 border border-stone-200 transition-all focus-within:ring-4 focus-within:ring-amber-500/20 focus-within:border-amber-500/50">
                        <textarea
                            id="main-chat-input"
                            value={inputValue}
                            onChange={(e) => setInputValue(e.target.value)}
                            onKeyDown={(e) => {
                                if (e.key === 'Enter' && !e.shiftKey) {
                                    e.preventDefault();
                                    handleSend(inputValue);
                                }
                            }}
                            placeholder="Ask The People's Law..."
                            className="w-full pl-6 py-3 bg-transparent border-none focus:ring-0 text-stone-800 placeholder-stone-400 resize-none h-[52px] leading-[28px] max-h-[120px] scrollbar-hide text-lg"
                        />
                        
                        <div className="flex items-center gap-2 pr-2">
                            {/* Voice Button */}
                            <button
                                onClick={handleVoiceInput}
                                className={`p-3 rounded-full transition-all duration-300 ${isListening ? 'bg-red-500 text-white animate-pulse shadow-red-200' : 'bg-stone-100 text-stone-400 hover:bg-stone-200 hover:text-stone-600'}`}
                                title="Use Voice Input"
                            >
                                {isListening ? (
                                    <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z" /></svg>
                                ) : (
                                    <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z" /></svg>
                                )}
                            </button>

                            {/* Send Button */}
                            <button
                                onClick={() => handleSend(inputValue)}
                                disabled={!inputValue.trim() || chatState.isLoading}
                                className={`p-3 rounded-full transition-all duration-300 shadow-md flex items-center justify-center ${
                                    !inputValue.trim() || chatState.isLoading 
                                    ? 'bg-stone-200 text-stone-400 cursor-not-allowed' 
                                    : 'bg-stone-900 text-white hover:bg-amber-600 hover:scale-105 active:scale-95'
                                }`}
                            >
                                {chatState.isLoading ? (
                                    <svg className="w-5 h-5 animate-spin" fill="none" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg>
                                ) : (
                                    <svg className="w-5 h-5 translate-x-0.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8" />
                                    </svg>
                                )}
                            </button>
                        </div>
                    </div>
                    
                    {/* Add shortcut hint */}
                    <div className="absolute right-6 -bottom-6 text-[10px] text-stone-400 font-medium hidden md:block opacity-60">
                        Press <span className="font-bold">Ctrl+K</span> to focus
                    </div>
                </div>
             </div>
        )}

        {/* Global Action Button (For Mobile View Switching) */}
        {currentView !== 'chat' && (
             <button 
                onClick={() => setCurrentView('chat')}
                className="md:hidden fixed bottom-6 right-6 w-14 h-14 bg-stone-900 text-white rounded-full shadow-2xl flex items-center justify-center z-40 hover:scale-105 transition-transform"
             >
                <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z" />
                </svg>
             </button>
        )}

      </main>
    </div>
  );
}