
# The People's Law - Civics Operating System

**The People's Law** is an AI-powered legal assistant and civics education platform designed to democratize access to the United States legal system. It serves as a comprehensive guide to the US Constitution, Case Law, and Civil Rights, powered by Google's Gemini AI.

## 🚀 Mission
To provide an accessible, empowering, and accurate "Civics Operating System" for the public. The application bridges the gap between complex legal statutes and everyday citizens through plain English explanations, analogies, and interactive tools.

## ✨ Key Features

*   **Legal Library:** Full text and analysis of the US Constitution, Bill of Rights, and Landmark Supreme Court Cases.
*   **Active Tutor Mode:** Socratic method AI interaction to teach legal concepts rather than just providing answers.
*   **Tools for Citizens:**
    *   **Police Encounters Guide:** State-specific rights and scripts for interactions with law enforcement.
    *   **Drafting Lab:** Templates for FOIA requests, demand letters, and basic contracts.
    *   **Courtroom Simulator:** Interactive educational scenarios to understand the judicial process.
*   **Privacy First:** All chat history and bookmarks are stored locally on the user's device.

## 🛠️ Technology Stack

*   **Frontend:** React (Vite), TypeScript
*   **Styling:** Tailwind CSS
*   **AI Integration:** Google Gemini API (`gemini-2.5-flash`) with Search Grounding
*   **Audio:** Web Audio API for TTS (Text-to-Speech)

## 💻 Installation & Local Development

1.  **Install Dependencies:**
    ```bash
    npm install
    ```

2.  **Configure Environment:**
    Create a `.env` file in the root directory and add your Google Gemini API key:
    ```
    API_KEY=your_api_key_here
    ```

3.  **Start Development Server:**
    ```bash
    npm run dev
    ```

## 🌍 How to Deploy (Launch to the Public)

The easiest way to publish this app for free is using **Vercel**.

1.  **Create a GitHub Repository:**
    *   Go to GitHub.com and create a new repository (e.g., `the-peoples-law`).
    *   Upload all these files to it.

2.  **Deploy on Vercel:**
    *   Go to [Vercel.com](https://vercel.com) and Sign Up (you can use your GitHub account).
    *   Click **"Add New..."** -> **"Project"**.
    *   Select your `the-peoples-law` repository.

3.  **Configure API Key (Crucial):**
    *   On the Vercel deploy screen, look for **"Environment Variables"**.
    *   Add a new variable:
        *   **Name:** `API_KEY`
        *   **Value:** `[Paste your Google Gemini API Key here]`
    *   Click **Deploy**.

4.  **Final Polish:**
    *   Once deployed, Vercel will give you a domain (e.g., `the-peoples-law.vercel.app`).
    *   Update the `shareUrl` in `components/Sidebar.tsx` with this new link so sharing works correctly.

## ⚖️ Legal Disclaimer
This software is for educational purposes only. It uses artificial intelligence to provide information and should not be considered a substitute for professional legal advice from a licensed attorney.

*Powered by Google Gemini*
