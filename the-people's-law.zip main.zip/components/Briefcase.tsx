import React from 'react';
import { Bookmark } from '../types';

interface BriefcaseProps {
  bookmarks: Bookmark[];
  onRemove: (id: string) => void;
  onSelect: (prompt: string) => void;
}

export const Briefcase: React.FC<BriefcaseProps> = ({ bookmarks, onRemove, onSelect }) => {
  if (bookmarks.length === 0) {
    return (
      <div className="flex flex-col h-full overflow-y-auto animate-fade-in bg-[#f5f4f1] pb-12">
        <div className="max-w-4xl mx-auto w-full p-4 md:p-12 flex flex-col items-center justify-center min-h-[50vh] text-center">
            <div className="w-20 h-20 bg-stone-200 rounded-full flex items-center justify-center mb-6 text-stone-400">
                <svg className="w-10 h-10" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M5 5a2 2 0 012-2h10a2 2 0 012 2v16l-7-3.5L5 21V5z" />
                </svg>
            </div>
            <h2 className="text-2xl font-serif font-bold text-stone-800 mb-2">My Briefcase is Empty</h2>
            <p className="text-stone-500 max-w-md">
                Pin important cases, terms, or statutes here for quick access later. Look for the bookmark icon <span className="inline-block p-1 bg-stone-200 rounded"><svg className="w-3 h-3 inline" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 5a2 2 0 012-2h10a2 2 0 012 2v16l-7-3.5L5 21V5z" /></svg></span> throughout the library.
            </p>
        </div>
      </div>
    );
  }

  const grouped = {
      case: bookmarks.filter(b => b.type === 'case'),
      term: bookmarks.filter(b => b.type === 'term'),
      statute: bookmarks.filter(b => b.type === 'statute'),
      doc: bookmarks.filter(b => b.type === 'doc'),
  };

  return (
    <div className="flex flex-col h-full overflow-y-auto animate-fade-in bg-[#f5f4f1] pb-12">
      <div className="max-w-4xl mx-auto w-full p-4 md:p-12">
         
         <div className="text-center mb-10">
           <div className="inline-flex items-center justify-center p-4 bg-stone-800 rounded-full mb-6 shadow-sm ring-1 ring-stone-900">
              <svg className="w-10 h-10 text-stone-100" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M21 13.255A23.931 23.931 0 0112 15c-3.183 0-6.22-.62-9-1.745M16 6V4a2 2 0 00-2-2h-4a2 2 0 00-2 2v2m4 6h.01M5 20h14a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
              </svg>
           </div>
           <h1 className="text-3xl md:text-5xl font-serif font-bold text-stone-900 mb-4">My Briefcase</h1>
           <p className="text-stone-600 max-w-xl mx-auto text-lg mb-8">
              Your personal collection of saved legal references.
           </p>
        </div>

        <div className="grid grid-cols-1 gap-8">
            {/* Cases */}
            {grouped.case.length > 0 && (
                <div className="bg-white rounded-xl border border-stone-200 p-6 shadow-sm">
                    <h3 className="text-lg font-bold font-serif text-stone-800 mb-4 flex items-center gap-2 border-b border-stone-100 pb-2">
                        <span className="bg-amber-100 text-amber-800 p-1.5 rounded-lg"><svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 6l3 1m0 0l-3 9a5.002 5.002 0 006.001 0M6 7l3 9M6 7l6-2m6 2l3-1m-3 1l-3 9a5.002 5.002 0 006.001 0M18 7l3 9m-3-9l-6-2m0-2v2m0 16V5m0 16H9m3 0h3" /></svg></span>
                        Saved Cases
                    </h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        {grouped.case.map(item => (
                            <div key={item.id} className="p-4 bg-stone-50 rounded-lg border border-stone-200 hover:border-amber-300 transition-colors group relative">
                                <h4 className="font-bold text-stone-900">{item.title}</h4>
                                {item.subtitle && <p className="text-xs text-stone-500 mt-1">{item.subtitle}</p>}
                                <div className="mt-3 flex gap-2">
                                    <button onClick={() => onSelect(item.prompt)} className="flex-1 text-xs bg-stone-900 text-white px-3 py-1.5 rounded hover:bg-amber-700 transition-colors">Discuss</button>
                                    <button onClick={() => onSelect(`Analyze the case of ${item.title} using formal legal logic (IRAC).`)} className="flex-1 text-xs bg-purple-100 text-purple-700 font-bold px-3 py-1.5 rounded hover:bg-purple-200 transition-colors">Analyze</button>
                                    <button onClick={() => onRemove(item.id)} className="text-xs text-red-400 hover:text-red-600 px-2 py-1.5">Remove</button>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            )}

             {/* Terms */}
            {grouped.term.length > 0 && (
                <div className="bg-white rounded-xl border border-stone-200 p-6 shadow-sm">
                    <h3 className="text-lg font-bold font-serif text-stone-800 mb-4 flex items-center gap-2 border-b border-stone-100 pb-2">
                         <span className="bg-teal-100 text-teal-800 p-1.5 rounded-lg"><svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253" /></svg></span>
                        Glossary Terms
                    </h3>
                    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
                        {grouped.term.map(item => (
                            <div key={item.id} className="p-4 bg-stone-50 rounded-lg border border-stone-200 hover:border-teal-300 transition-colors">
                                <h4 className="font-bold text-stone-900">{item.title}</h4>
                                <div className="mt-3 flex gap-2 justify-between items-center">
                                    <button onClick={() => onSelect(item.prompt)} className="text-xs font-bold text-teal-700 hover:underline">Define</button>
                                    <button onClick={() => onSelect(`Analyze the concept of ${item.title} in depth.`)} className="text-xs font-bold text-purple-700 hover:underline">Analyze</button>
                                    <button onClick={() => onRemove(item.id)} className="text-stone-400 hover:text-red-500"><svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" /></svg></button>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            )}
            
             {/* Statutes/Docs */}
            {(grouped.statute.length > 0 || grouped.doc.length > 0) && (
                <div className="bg-white rounded-xl border border-stone-200 p-6 shadow-sm">
                    <h3 className="text-lg font-bold font-serif text-stone-800 mb-4 flex items-center gap-2 border-b border-stone-100 pb-2">
                         <span className="bg-indigo-100 text-indigo-800 p-1.5 rounded-lg"><svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" /></svg></span>
                        Statutes & Documents
                    </h3>
                    <div className="space-y-3">
                        {[...grouped.statute, ...grouped.doc].map(item => (
                            <div key={item.id} className="flex items-center justify-between p-3 bg-stone-50 rounded-lg border border-stone-200 hover:bg-indigo-50 hover:border-indigo-200 transition-colors">
                                <div>
                                    <h4 className="font-bold text-stone-900 text-sm">{item.title}</h4>
                                    {item.subtitle && <p className="text-xs text-stone-500">{item.subtitle}</p>}
                                </div>
                                <div className="flex gap-3 items-center">
                                     <button onClick={() => onSelect(item.prompt)} className="text-xs font-bold text-indigo-700 hover:underline">Read</button>
                                     <button onClick={() => onSelect(`Analyze ${item.title} in detail. Focus on its key provisions and impact.`)} className="text-xs font-bold text-purple-700 hover:underline">Analyze</button>
                                    <button onClick={() => onRemove(item.id)} className="text-stone-400 hover:text-red-500"><svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg></button>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            )}

        </div>
      </div>
    </div>
  );
};