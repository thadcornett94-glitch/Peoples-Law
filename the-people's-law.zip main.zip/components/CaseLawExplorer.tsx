import React, { useState, useMemo } from 'react';
import { CASE_LAW_CATEGORIES, US_STATES } from '../constants';
import { Bookmark } from '../types';

interface CaseLawExplorerProps {
  onSelectCase: (prompt: string) => void;
  bookmarks: Bookmark[];
  onToggleBookmark: (item: Bookmark) => void;
}

export const CaseLawExplorer: React.FC<CaseLawExplorerProps> = ({ onSelectCase, bookmarks, onToggleBookmark }) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [activeFilter, setActiveFilter] = useState<string>('all');
  const [showHierarchy, setShowHierarchy] = useState(false);

  // Check if saved
  const isBookmarked = (id: string) => bookmarks.some(b => b.id === id);

  // Filter categories and cases based on search query AND active category filter
  const filteredCategories = useMemo(() => {
    // If we are in the State Constitutions view, we don't return standard case categories
    if (activeFilter === 'states') return [];

    const query = searchQuery.toLowerCase().trim();
    
    // 1. First, filter by Category if one is selected
    let baseCategories = CASE_LAW_CATEGORIES;
    if (activeFilter !== 'all') {
      baseCategories = CASE_LAW_CATEGORIES.filter(c => c.id === activeFilter);
    }

    // 2. If no search query, return the category filtered list
    if (!query) return baseCategories;

    // 3. If search query exists, filter deep inside the remaining categories
    return baseCategories.map(category => {
      // Check if the category title or description matches
      const categoryMatches = category.title.toLowerCase().includes(query) || 
                              category.description.toLowerCase().includes(query);
      
      // Filter individual cases
      const matchingCases = category.cases.filter(c => 
        categoryMatches || 
        c.name.toLowerCase().includes(query) || 
        c.prompt.toLowerCase().includes(query) ||
        (c.summary && c.summary.toLowerCase().includes(query)) ||
        (c.year && c.year.includes(query))
      );

      // Return category with filtered cases
      return {
        ...category,
        cases: matchingCases
      };
    }).filter(category => category.cases.length > 0); // Only show categories that have matching cases
  }, [searchQuery, activeFilter]);

  // Specific logic for State Constitution filtering - strict search match
  const matchedStates = useMemo(() => {
    if (activeFilter !== 'states') return [];
    if (!searchQuery.trim()) return [];
    
    const query = searchQuery.toLowerCase().trim();
    // Return only if the query starts matching a state, or if the user is typing
    return US_STATES.filter(state => state.toLowerCase().includes(query));
  }, [searchQuery, activeFilter]);

  return (
    <div className="flex flex-col h-full overflow-y-auto animate-fade-in bg-[#f5f4f1] pb-12">
      <div className="max-w-6xl mx-auto w-full p-4 md:p-12 relative">
        <header className="mb-10 text-center relative z-0">
            <div className="inline-flex items-center justify-center p-4 bg-amber-100/80 rounded-full mb-6 shadow-sm ring-1 ring-amber-200">
                <svg className="w-10 h-10 text-amber-800" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253" />
                </svg>
            </div>
            <h1 className="text-3xl md:text-5xl font-serif font-bold text-stone-900 mb-4 tracking-tight">Legal Library: Cases & Codes</h1>
            <p className="text-stone-600 max-w-2xl mx-auto text-lg leading-relaxed mb-4">
                Explore the landmark decisions, major statutes, and State Constitutions that shaped the United States legal system.
            </p>

            {/* Quick Guide Toggle */}
            <button 
                onClick={() => setShowHierarchy(!showHierarchy)}
                className="text-amber-700 font-bold text-sm uppercase tracking-wide hover:underline mb-8 flex items-center justify-center gap-1 mx-auto"
            >
                {showHierarchy ? "Hide Legal Sources Guide" : "What is the difference between Statutes & Case Law?"}
                <svg className={`w-4 h-4 transition-transform ${showHierarchy ? 'rotate-180' : ''}`} fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                </svg>
            </button>

            {/* Hierarchy Primer Card */}
            {showHierarchy && (
                <div className="max-w-4xl mx-auto bg-white rounded-xl border border-stone-200 shadow-lg overflow-hidden mb-10 text-left animate-fade-in-up">
                    <div className="bg-stone-50 px-6 py-4 border-b border-stone-200">
                        <h3 className="font-serif font-bold text-lg text-stone-800">Quick Guide: Sources of Law</h3>
                    </div>
                    <div className="p-6 grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div className="p-4 bg-amber-50 rounded-lg border border-amber-100">
                            <div className="font-bold text-amber-800 mb-1 flex items-center gap-2">
                                <span className="text-xs bg-amber-200 px-2 py-0.5 rounded text-amber-900">1. Highest</span>
                                Constitution
                            </div>
                            <p className="text-sm text-stone-700 leading-relaxed">The "Supreme Law of the Land." No law can violate it. Establishes the government structure and fundamental rights (Bill of Rights).</p>
                        </div>
                        <div className="p-4 bg-blue-50 rounded-lg border border-blue-100">
                             <div className="font-bold text-blue-800 mb-1 flex items-center gap-2">
                                <span className="text-xs bg-blue-200 px-2 py-0.5 rounded text-blue-900">2. Legislative</span>
                                Statutes (Codes)
                            </div>
                            <p className="text-sm text-stone-700 leading-relaxed">Written laws passed by Congress (Federal) or Legislatures (State). Examples: The Clean Air Act, Penal Codes.</p>
                        </div>
                         <div className="p-4 bg-emerald-50 rounded-lg border border-emerald-100">
                             <div className="font-bold text-emerald-800 mb-1 flex items-center gap-2">
                                <span className="text-xs bg-emerald-200 px-2 py-0.5 rounded text-emerald-900">3. Administrative</span>
                                Regulations
                            </div>
                            <p className="text-sm text-stone-700 leading-relaxed">Detailed rules created by executive agencies (like the EPA or FDA) to enforce statutes.</p>
                        </div>
                        <div className="p-4 bg-stone-100 rounded-lg border border-stone-200">
                             <div className="font-bold text-stone-800 mb-1 flex items-center gap-2">
                                <span className="text-xs bg-stone-300 px-2 py-0.5 rounded text-stone-900">4. Judicial</span>
                                Case Law
                            </div>
                            <p className="text-sm text-stone-700 leading-relaxed">Court decisions that interpret the above laws. Courts follow <em>stare decisis</em> (precedent) to ensure consistency.</p>
                        </div>
                    </div>
                </div>
            )}

            {/* Enhanced Category Filter Chips */}
            <div className="sticky top-0 z-20 bg-[#f5f4f1] py-4 transition-all">
                <div className="flex flex-wrap justify-center gap-2 max-w-4xl mx-auto mb-6">
                   <button
                      onClick={() => { setActiveFilter('all'); setSearchQuery(''); }}
                      className={`px-4 py-1.5 rounded-full text-sm font-medium transition-all duration-200 border ${
                        activeFilter === 'all'
                          ? 'bg-stone-800 text-white border-stone-800 shadow-md transform scale-105'
                          : 'bg-white text-stone-600 border-stone-300 hover:border-amber-500 hover:text-amber-700'
                      }`}
                   >
                      All Categories
                   </button>
                   
                   {/* Prominent State Constitution Filter */}
                   <button
                      onClick={() => { setActiveFilter('states'); setSearchQuery(''); }}
                      className={`px-4 py-1.5 rounded-full text-sm font-medium transition-all duration-200 border flex items-center gap-2 ${
                        activeFilter === 'states'
                          ? 'bg-amber-700 text-white border-amber-700 shadow-md transform scale-105 ring-2 ring-amber-200'
                          : 'bg-white text-stone-600 border-stone-300 hover:border-amber-500 hover:text-amber-700'
                      }`}
                   >
                      <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3.055 11H5a2 2 0 012 2v1a2 2 0 002 2 2 2 0 012 2v2.945M8 3.935V5.5A2.5 2.5 0 0010.5 8h.5a2 2 0 012 2 2 2 0 104 0 2 2 0 012-2h1.064M15 20.488V18a2 2 0 012-2h3.064M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                      </svg>
                      State Constitutions
                   </button>
    
                   {CASE_LAW_CATEGORIES.map((cat) => (
                     <button
                        key={cat.id}
                        onClick={() => { setActiveFilter(cat.id); setSearchQuery(''); }}
                        className={`px-4 py-1.5 rounded-full text-sm font-medium transition-all duration-200 border ${
                          activeFilter === cat.id
                            ? 'bg-amber-700 text-white border-amber-700 shadow-md transform scale-105'
                            : 'bg-white text-stone-600 border-stone-300 hover:border-amber-500 hover:text-amber-700'
                        }`}
                     >
                        {cat.title}
                     </button>
                   ))}
                </div>
    
                {/* Redesigned Search Bar - Floating Command Style */}
                <div className="max-w-xl mx-auto relative">
                    <div className="relative bg-white shadow-2xl rounded-full flex items-center border border-stone-200 transition-all focus-within:ring-4 focus-within:ring-amber-500/20 focus-within:border-amber-500/50">
                        <div className="pl-6 text-stone-400">
                             {activeFilter === 'states' ? (
                                <svg className="w-6 h-6 text-amber-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                   <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
                                   <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
                                </svg>
                             ) : (
                                 <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                                </svg>
                             )}
                        </div>
                        <input
                            type="text"
                            id="library-search-input"
                            className="block w-full px-4 py-4 bg-transparent border-none focus:ring-0 text-xl text-stone-800 placeholder-stone-400 font-medium"
                            placeholder={activeFilter === 'states' ? "Start typing your State..." : "Search legal cases..."}
                            value={searchQuery}
                            onChange={(e) => setSearchQuery(e.target.value)}
                            autoFocus={activeFilter === 'states'}
                        />
                         {searchQuery ? (
                            <button 
                                onClick={() => setSearchQuery('')}
                                className="mr-3 p-2 bg-stone-100 rounded-full text-stone-500 hover:bg-stone-200 hover:text-stone-800 transition-colors"
                            >
                                <svg className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                                </svg>
                            </button>
                        ) : (
                            <div className="mr-4 hidden md:flex items-center gap-1 pointer-events-none">
                                <kbd className="hidden sm:inline-block border border-stone-200 bg-stone-50 px-2 py-0.5 rounded text-xs font-bold text-stone-400 shadow-sm">Ctrl</kbd>
                                <span className="text-stone-300 text-xs">+</span>
                                <kbd className="hidden sm:inline-block border border-stone-200 bg-stone-50 px-2 py-0.5 rounded text-xs font-bold text-stone-400 shadow-sm">K</kbd>
                            </div>
                        )}
                    </div>
                </div>
            </div>
        </header>

        {/* State Constitution View - Clean Search Interaction */}
        {activeFilter === 'states' && (
           <div className="animate-fade-in-up">
              {!searchQuery ? (
                 <div className="flex flex-col items-center justify-center py-12 opacity-60">
                    <p className="text-stone-400 text-xl font-serif italic mb-2">Begin typing to find a State Constitution...</p>
                 </div>
              ) : matchedStates.length === 0 ? (
                 <div className="text-center py-12 opacity-75">
                    <p className="text-stone-500 text-lg">No state found matching "{searchQuery}".</p>
                 </div>
              ) : (
                <div className="max-w-2xl mx-auto space-y-4">
                   {matchedStates.map(state => (
                      <div key={state} className="bg-white rounded-xl border border-stone-200 p-6 shadow-md hover:shadow-lg hover:border-amber-400 transition-all duration-200 group flex items-center justify-between">
                          <div>
                            <h3 className="text-2xl font-serif font-bold text-stone-800 group-hover:text-amber-800 transition-colors">{state}</h3>
                            <p className="text-sm text-stone-500 mt-1">Explore the {state} State Constitution</p>
                          </div>
                          <div className="flex gap-2">
                              <button
                                 onClick={() => onSelectCase(`Analyze the legal structure and State Constitution of ${state}. What are its unique features compared to the Federal Constitution?`)}
                                 className="py-2.5 px-4 bg-purple-100 text-purple-800 rounded-lg text-sm font-bold uppercase tracking-wider transition-colors hover:bg-purple-200"
                              >
                                 Analyze
                              </button>
                              <button
                                 onClick={() => onSelectCase(`Tell me about the ${state} State Constitution. When was it adopted, and what are its unique features compared to the US Constitution?`)}
                                 className="py-2.5 px-6 bg-stone-900 text-white rounded-lg text-sm font-bold uppercase tracking-wider transition-colors hover:bg-amber-700 flex items-center gap-2"
                              >
                                 Research
                                 <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14 5l7 7m0 0l-7 7m7-7H3" />
                                 </svg>
                              </button>
                          </div>
                      </div>
                   ))}
                </div>
              )}
           </div>
        )}

        {/* Standard Case Law View */}
        {activeFilter !== 'states' && (
          filteredCategories.length === 0 ? (
             <div className="text-center py-16 opacity-75 animate-fade-in-up">
                <div className="inline-flex items-center justify-center p-4 bg-stone-100 rounded-full mb-3">
                    <svg className="w-6 h-6 text-stone-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.172 16.172a4 4 0 015.656 0M9 10h.01M15 10h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                </div>
                <p className="text-stone-500 text-lg">No cases found matching your criteria.</p>
                <button 
                    onClick={() => { setSearchQuery(''); setActiveFilter('all'); }}
                    className="mt-4 text-amber-700 hover:text-amber-800 font-medium text-sm underline underline-offset-2"
                >
                    Clear filters
                </button>
             </div>
          ) : (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 animate-fade-in-up">
                {filteredCategories.map((category) => (
                    <div key={category.id} className="bg-white rounded-2xl border border-stone-200 shadow-sm overflow-hidden flex flex-col hover:shadow-lg transition-shadow duration-300">
                        {/* Card Header */}
                        <div className="bg-stone-50/80 px-6 py-4 border-b border-stone-100 flex items-center justify-between backdrop-blur-sm">
                            <h2 className="text-xl font-serif font-bold text-stone-800">{category.title}</h2>
                            <span className="text-[10px] font-bold uppercase tracking-wider text-stone-500 bg-stone-200 px-2 py-1 rounded-md">
                                {category.cases.length} {category.cases.length === 1 ? 'Item' : 'Items'}
                            </span>
                        </div>
                        
                        <div className="p-6 flex-1 flex flex-col">
                            <p className="text-sm text-stone-500 mb-6 italic leading-relaxed">{category.description}</p>
                            
                            {/* Scrollable Case/Statute List */}
                            <div className="space-y-4 max-h-[350px] overflow-y-auto pr-2 custom-scrollbar">
                                {category.cases.map((c: any, idx: number) => {
                                    const saved = isBookmarked(c.name);
                                    return (
                                        <div 
                                            key={idx}
                                            className="group relative bg-white border border-stone-100 rounded-xl p-4 hover:border-amber-200 hover:bg-amber-50/30 transition-all duration-200"
                                        >
                                            <div className="flex justify-between items-start gap-4 mb-2">
                                                <div className="flex-1">
                                                    <h3 className="font-bold text-stone-800 group-hover:text-amber-900 transition-colors">{c.name}</h3>
                                                    {c.year && (
                                                        <span className={`inline-block mt-1 text-xs font-medium px-1.5 py-0.5 rounded border ${c.year === 'Concept' ? 'bg-indigo-50 text-indigo-700 border-indigo-100' : 'bg-stone-100 text-stone-500 border-stone-200'}`}>
                                                            {c.year}
                                                        </span>
                                                    )}
                                                </div>
                                                <div className="flex items-center gap-2">
                                                     {/* Bookmark Button */}
                                                    <button
                                                        onClick={(e) => {
                                                            e.stopPropagation();
                                                            onToggleBookmark({
                                                                id: c.name,
                                                                type: 'case',
                                                                title: c.name,
                                                                prompt: c.prompt,
                                                                subtitle: c.year,
                                                                timestamp: Date.now()
                                                            });
                                                        }}
                                                        className={`p-1.5 rounded-lg transition-all ${saved ? 'text-amber-600 bg-amber-100' : 'text-stone-300 hover:text-amber-500 hover:bg-amber-50'}`}
                                                        title={saved ? "Remove from Briefcase" : "Save to Briefcase"}
                                                    >
                                                        <svg className="w-5 h-5" fill={saved ? "currentColor" : "none"} viewBox="0 0 24 24" stroke="currentColor">
                                                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 5a2 2 0 012-2h10a2 2 0 012 2v16l-7-3.5L5 21V5z" />
                                                        </svg>
                                                    </button>

                                                    <button 
                                                        onClick={() => onSelectCase(`Perform a detailed legal analysis of ${c.name} (${c.year}). Include the Issue, Rule, Analysis, and Conclusion (IRAC) if applicable, or the historical significance.`)}
                                                        className="opacity-0 group-hover:opacity-100 transition-opacity text-xs font-bold text-purple-700 uppercase tracking-wider bg-purple-100 px-2 py-1 rounded-lg hover:bg-purple-200 whitespace-nowrap"
                                                    >
                                                        Analyze
                                                    </button>

                                                    <button 
                                                        onClick={() => onSelectCase(c.prompt)}
                                                        className="opacity-0 group-hover:opacity-100 transition-opacity text-xs font-bold text-amber-700 uppercase tracking-wider flex items-center gap-1 bg-amber-100 px-2 py-1 rounded-lg hover:bg-amber-200 whitespace-nowrap"
                                                    >
                                                        Discuss
                                                        <svg className="w-3 h-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14 5l7 7m0 0l-7 7m7-7H3" />
                                                        </svg>
                                                    </button>
                                                </div>
                                            </div>
                                            
                                            {c.summary && (
                                                <div className="mt-3 bg-stone-50 p-3 rounded-lg border border-stone-100">
                                                    <span className="text-[10px] font-bold uppercase tracking-wider text-stone-400 mb-1 block">Plain English Summary</span>
                                                    <p className="text-sm text-stone-700 leading-relaxed">
                                                        {c.summary}
                                                    </p>
                                                </div>
                                            )}
                                        </div>
                                    );
                                })}
                            </div>
                        </div>
                    </div>
                ))}
            </div>
          )
        )}
      </div>
    </div>
  );
};