import React, { useState } from 'react';

interface CivicsGuideProps {
  onAsk: (prompt: string) => void;
}

export const CivicsGuide: React.FC<CivicsGuideProps> = ({ onAsk }) => {
  const [activeTab, setActiveTab] = useState<'levels' | 'oversight'>('levels');

  return (
    <div className="flex flex-col h-full overflow-y-auto animate-fade-in bg-[#f5f4f1] pb-12">
      <div className="max-w-5xl mx-auto w-full p-4 md:p-12">
        
        {/* Header */}
        <div className="text-center mb-10">
           <div className="inline-flex items-center justify-center p-4 bg-sky-100/80 rounded-full mb-6 shadow-sm ring-1 ring-sky-200">
              <svg className="w-10 h-10 text-sky-800" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                 <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" />
              </svg>
           </div>
           <h1 className="text-3xl md:text-5xl font-serif font-bold text-stone-900 mb-4">Civics & Oversight</h1>
           <p className="text-stone-600 max-w-2xl mx-auto text-lg mb-8">
              Understanding how your government works and your rights to hold it accountable.
           </p>

           <div className="flex justify-center gap-4 mb-8">
              <button
                 onClick={() => setActiveTab('levels')}
                 className={`px-6 py-2 rounded-full font-bold text-sm uppercase tracking-wide transition-all ${
                    activeTab === 'levels' 
                    ? 'bg-stone-800 text-white shadow-md' 
                    : 'bg-white text-stone-500 border border-stone-200 hover:bg-stone-50'
                 }`}
              >
                 Levels of Government
              </button>
              <button
                 onClick={() => setActiveTab('oversight')}
                 className={`px-6 py-2 rounded-full font-bold text-sm uppercase tracking-wide transition-all ${
                    activeTab === 'oversight' 
                    ? 'bg-amber-700 text-white shadow-md' 
                    : 'bg-white text-stone-500 border border-stone-200 hover:bg-stone-50'
                 }`}
              >
                 Your Oversight Rights
              </button>
           </div>
        </div>

        {activeTab === 'levels' && (
           <div className="space-y-8 animate-fade-in-up">
              {/* Federal */}
              <div className="bg-white p-8 rounded-2xl border border-stone-200 shadow-sm relative">
                 <div className="flex items-center justify-between mb-4">
                     <div className="flex items-center gap-4">
                        <span className="bg-blue-100 text-blue-800 px-3 py-1 rounded text-xs font-bold uppercase tracking-wider">National</span>
                        <h2 className="text-2xl font-serif font-bold text-stone-800">Federal Government</h2>
                     </div>
                     <button 
                        onClick={() => onAsk("Analyze the structure and enumerated powers of the Federal Government versus the States. Use the 'Layer Cake vs Marble Cake' analogy for Federalism.")}
                        className="text-xs font-bold text-purple-700 bg-purple-50 px-3 py-1.5 rounded-lg hover:bg-purple-100 transition-colors uppercase tracking-wider hidden sm:block"
                     >
                        Analyze Powers
                     </button>
                 </div>
                 <p className="text-stone-600 leading-relaxed mb-6">
                    Based in Washington D.C., it handles issues that affect the entire country.
                 </p>
                 <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                    <div className="p-4 bg-stone-50 rounded-xl">
                       <strong className="block text-stone-900 mb-1">Defense & Foreign Policy</strong>
                       <span className="text-stone-500">Military, Treaties, Ambassadors.</span>
                    </div>
                    <div className="p-4 bg-stone-50 rounded-xl">
                       <strong className="block text-stone-900 mb-1">Currency & Trade</strong>
                       <span className="text-stone-500">Printing money, Interstate Commerce.</span>
                    </div>
                    <div className="p-4 bg-stone-50 rounded-xl">
                       <strong className="block text-stone-900 mb-1">Civil Rights</strong>
                       <span className="text-stone-500">Enforcing Constitutional protections.</span>
                    </div>
                 </div>
              </div>

              {/* State */}
              <div className="bg-white p-8 rounded-2xl border border-stone-200 shadow-sm relative">
                 <div className="flex items-center justify-between mb-4">
                     <div className="flex items-center gap-4">
                        <span className="bg-green-100 text-green-800 px-3 py-1 rounded text-xs font-bold uppercase tracking-wider">Regional</span>
                        <h2 className="text-2xl font-serif font-bold text-stone-800">State Government</h2>
                     </div>
                     <button 
                        onClick={() => onAsk("Analyze the powers reserved to the States under the 10th Amendment. Use an analogy to explain the 'Police Power' of states.")}
                        className="text-xs font-bold text-purple-700 bg-purple-50 px-3 py-1.5 rounded-lg hover:bg-purple-100 transition-colors uppercase tracking-wider hidden sm:block"
                     >
                        Analyze Powers
                     </button>
                 </div>
                 <p className="text-stone-600 leading-relaxed mb-6">
                    Based in your State Capital (e.g., Sacramento, Austin), it holds broadly shared powers under the 10th Amendment.
                 </p>
                 <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                    <div className="p-4 bg-stone-50 rounded-xl">
                       <strong className="block text-stone-900 mb-1">Criminal Law</strong>
                       <span className="text-stone-500">Most crimes (theft, murder) are state laws.</span>
                    </div>
                    <div className="p-4 bg-stone-50 rounded-xl">
                       <strong className="block text-stone-900 mb-1">Education & Health</strong>
                       <span className="text-stone-500">Funding schools, Medicaid, Hospitals.</span>
                    </div>
                    <div className="p-4 bg-stone-50 rounded-xl">
                       <strong className="block text-stone-900 mb-1">Licenses</strong>
                       <span className="text-stone-500">Drivers licenses, Bar exams, Medical boards.</span>
                    </div>
                 </div>
              </div>

              {/* Local */}
              <div className="bg-stone-800 text-white p-8 rounded-2xl shadow-xl relative overflow-hidden">
                 <div className="absolute top-0 right-0 p-12 opacity-5">
                    <svg className="w-64 h-64" fill="currentColor" viewBox="0 0 24 24"><path d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" /></svg>
                 </div>
                 <div className="relative z-10">
                     <div className="flex items-center gap-4 mb-4">
                        <span className="bg-amber-600 text-white px-3 py-1 rounded text-xs font-bold uppercase tracking-wider">Closest to You</span>
                        <h2 className="text-2xl font-serif font-bold">Local Government</h2>
                     </div>
                     <p className="text-stone-300 leading-relaxed mb-6">
                        City Councils, County Boards, and School Districts. These impact your daily life the most.
                     </p>
                     <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                        <div className="p-4 bg-stone-700 rounded-xl border border-stone-600">
                           <strong className="block text-white mb-1">Zoning & Housing</strong>
                           <span className="text-stone-400">Where homes/businesses can be built.</span>
                        </div>
                        <div className="p-4 bg-stone-700 rounded-xl border border-stone-600">
                           <strong className="block text-white mb-1">Police & Fire</strong>
                           <span className="text-stone-400">Local law enforcement budgets/policy.</span>
                        </div>
                        <div className="p-4 bg-stone-700 rounded-xl border border-stone-600">
                           <strong className="block text-white mb-1">Utilities</strong>
                           <span className="text-stone-400">Water, trash, potholes, parks.</span>
                        </div>
                     </div>
                     <button 
                        onClick={() => onAsk("Explain how I can impact my Local Government. How do City Council meetings work, and what is 'Public Comment'?")}
                        className="mt-6 w-full py-3 bg-white text-stone-900 font-bold rounded-lg hover:bg-amber-500 hover:text-white transition-colors uppercase tracking-widest text-xs"
                     >
                        How to Get Involved
                     </button>
                 </div>
              </div>
           </div>
        )}

        {activeTab === 'oversight' && (
            <div className="space-y-6 animate-fade-in-up">
                <div className="p-6 bg-amber-50 border border-amber-100 rounded-2xl mb-8">
                    <h2 className="text-xl font-serif font-bold text-amber-900 mb-2">The "Fourth Branch": The Citizen</h2>
                    <p className="text-amber-800 text-sm leading-relaxed">
                        Democracy requires sunlight. You have specific legal rights to watch your government, read their emails, and sit in their meetings.
                    </p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {/* Sunshine Laws */}
                    <div className="bg-white p-6 rounded-2xl border border-stone-200 shadow-sm hover:shadow-md transition-all group">
                        <div className="flex items-center gap-3 mb-4">
                            <div className="p-2 bg-yellow-100 rounded-lg text-yellow-700 group-hover:bg-yellow-500 group-hover:text-white transition-colors">
                                <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 3v1m0 16v1m9-9h-1M4 12H3m15.364 6.364l-.707-.707M6.343 6.343l-.707-.707m12.728 0l-.707.707M6.343 17.657l-.707.707M16 12a4 4 0 11-8 0 4 4 0 018 0z" /></svg>
                            </div>
                            <h3 className="font-bold text-stone-800 text-lg">Sunshine Laws</h3>
                        </div>
                        <p className="text-stone-600 text-sm mb-4">
                            (Open Meetings Acts). Government business must be done in public. You have the right to attend City Council and School Board meetings.
                        </p>
                        <button 
                            onClick={() => onAsk("Explain 'Sunshine Laws' (Open Meetings Acts). What rights do I have to attend government meetings, and what can they discuss in 'Closed Session'?")}
                            className="text-xs font-bold text-yellow-700 uppercase tracking-wide hover:underline"
                        >
                            Learn Your Rights &rarr;
                        </button>
                    </div>

                    {/* FOIA */}
                    <div className="bg-white p-6 rounded-2xl border border-stone-200 shadow-sm hover:shadow-md transition-all group">
                        <div className="flex items-center gap-3 mb-4">
                            <div className="p-2 bg-blue-100 rounded-lg text-blue-700 group-hover:bg-blue-600 group-hover:text-white transition-colors">
                                <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" /></svg>
                            </div>
                            <h3 className="font-bold text-stone-800 text-lg">Public Records (FOIA)</h3>
                        </div>
                        <p className="text-stone-600 text-sm mb-4">
                            You have the right to request documents, emails, and budgets from the government. "The People have a right to know."
                        </p>
                        <button 
                            onClick={() => onAsk("Explain the Freedom of Information Act (FOIA) and state Public Records Acts. How do I request documents from my local government?")}
                            className="text-xs font-bold text-blue-700 uppercase tracking-wide hover:underline"
                        >
                            How to Request Records &rarr;
                        </button>
                    </div>

                    {/* Budget */}
                    <div className="bg-white p-6 rounded-2xl border border-stone-200 shadow-sm hover:shadow-md transition-all group">
                        <div className="flex items-center gap-3 mb-4">
                            <div className="p-2 bg-green-100 rounded-lg text-green-700 group-hover:bg-green-600 group-hover:text-white transition-colors">
                                <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
                            </div>
                            <h3 className="font-bold text-stone-800 text-lg">Budget Watchdog</h3>
                        </div>
                        <p className="text-stone-600 text-sm mb-4">
                            Taxpayer money is your money. You have the right to see exactly how it is spent, from police equipment to park benches.
                        </p>
                        <button 
                            onClick={() => onAsk("How can a citizen audit or review their local government budget? Explain how to find out where tax money is being spent.")}
                            className="text-xs font-bold text-green-700 uppercase tracking-wide hover:underline"
                        >
                            Follow the Money &rarr;
                        </button>
                    </div>

                    {/* Voting */}
                    <div className="bg-white p-6 rounded-2xl border border-stone-200 shadow-sm hover:shadow-md transition-all group">
                        <div className="flex items-center gap-3 mb-4">
                            <div className="p-2 bg-purple-100 rounded-lg text-purple-700 group-hover:bg-purple-600 group-hover:text-white transition-colors">
                                <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 10l7-7m0 0l7 7m-7-7v18" /></svg>
                            </div>
                            <h3 className="font-bold text-stone-800 text-lg">Recall & Referendum</h3>
                        </div>
                        <p className="text-stone-600 text-sm mb-4">
                            In many states, citizens can bypass the legislature to pass laws directly (Referendum) or remove officials (Recall).
                        </p>
                        <button 
                            onClick={() => onAsk("Explain the powers of Initiative, Referendum, and Recall. How can citizens pass laws directly or remove politicians?")}
                            className="text-xs font-bold text-purple-700 uppercase tracking-wide hover:underline"
                        >
                            Direct Democracy Powers &rarr;
                        </button>
                    </div>
                </div>
            </div>
        )}

      </div>
    </div>
  );
};