import React from 'react';

interface CommonLawGuideProps {
  onSelectAction: (prompt: string) => void;
}

export const CommonLawGuide: React.FC<CommonLawGuideProps> = ({ onSelectAction }) => {
  return (
    <div className="flex flex-col h-full overflow-y-auto animate-fade-in bg-[#f5f4f1] pb-12">
      <div className="max-w-5xl mx-auto w-full p-4 md:p-12">
        
        <div className="text-center mb-10">
           <div className="inline-flex items-center justify-center p-4 bg-stone-800 rounded-full mb-6 shadow-xl ring-4 ring-stone-300">
              <svg className="w-12 h-12 text-stone-100" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253" />
              </svg>
           </div>
           <h1 className="text-4xl md:text-5xl font-serif font-bold text-stone-900 mb-6 tracking-tight">Understanding Common Law</h1>
           <p className="text-stone-600 max-w-2xl mx-auto text-xl leading-relaxed font-serif italic">
              "The life of the law has not been logic: it has been experience." — Oliver Wendell Holmes Jr.
           </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-12">
            {/* Concept Card */}
            <div className="bg-white rounded-2xl shadow-md border border-stone-200 p-8">
                <div className="flex items-center gap-3 mb-4">
                    <div className="p-2 bg-amber-100 rounded-lg text-amber-800">
                        <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10" /></svg>
                    </div>
                    <h2 className="text-2xl font-serif font-bold text-stone-900">What is Common Law?</h2>
                </div>
                <p className="text-stone-600 leading-relaxed mb-6">
                    Common Law is law developed by judges through decisions of courts, rather than through legislative statutes or executive action. It originated in England and forms the basis of the US legal system (except Louisiana).
                </p>
                <div className="bg-stone-50 p-6 rounded-xl border border-stone-200">
                    <h3 className="font-bold text-stone-800 mb-2 uppercase tracking-wider text-xs">The Core Principle</h3>
                    <strong className="block text-xl text-amber-800 font-serif mb-2">Stare Decisis</strong>
                    <p className="text-sm text-stone-600">
                        Latin for "to stand by things decided." It means courts must look to past decisions (precedents) to guide future ones. This ensures consistency and predictability.
                    </p>
                </div>
            </div>

            {/* Analogy Card */}
            <div className="bg-stone-800 text-stone-100 rounded-2xl shadow-xl p-8 relative overflow-hidden">
                <div className="absolute top-0 right-0 w-32 h-32 bg-amber-600 rounded-full blur-3xl opacity-20 -mr-16 -mt-16"></div>
                <h2 className="text-2xl font-serif font-bold mb-6 flex items-center gap-3">
                    <svg className="w-6 h-6 text-amber-500" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z" /></svg>
                    The "Chain Novel" Analogy
                </h2>
                <p className="text-lg text-stone-300 leading-relaxed mb-6">
                    Imagine a long novel written by many different authors, one chapter at a time.
                </p>
                <ul className="space-y-4 text-sm text-stone-300">
                    <li className="flex gap-3">
                        <span className="font-bold text-amber-500 shrink-0">1.</span>
                        <span>The first author writes Chapter 1 (The First Case). They set the scene.</span>
                    </li>
                    <li className="flex gap-3">
                        <span className="font-bold text-amber-500 shrink-0">2.</span>
                        <span>The next author (The Next Judge) must write Chapter 2. They cannot just write whatever they want; they must follow the plot and characters established in Chapter 1.</span>
                    </li>
                    <li className="flex gap-3">
                        <span className="font-bold text-amber-500 shrink-0">3.</span>
                        <span>If they change the genre suddenly (ignore precedent), the story breaks. To make the story work, they must interpret what came before and extend it logically.</span>
                    </li>
                </ul>
            </div>
        </div>

        {/* Comparison Section */}
        <div className="bg-white rounded-2xl shadow-lg border border-stone-200 overflow-hidden mb-12">
            <div className="bg-stone-100 px-8 py-4 border-b border-stone-200">
                <h2 className="text-xl font-serif font-bold text-stone-800">Statutory Law vs. Common Law</h2>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 divide-y md:divide-y-0 md:divide-x divide-stone-200">
                <div className="p-8">
                    <div className="flex items-center gap-3 mb-4">
                        <span className="p-2 bg-blue-100 text-blue-700 rounded-lg">
                            <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253" /></svg>
                        </span>
                        <h3 className="font-bold text-lg text-blue-900">Statutory Law</h3>
                    </div>
                    <p className="text-stone-600 mb-4 text-sm">Created by the Legislature (Congress/State). It is written down in codes.</p>
                    <div className="bg-blue-50 p-4 rounded-lg border border-blue-100">
                        <strong className="text-blue-800 text-xs uppercase tracking-wide block mb-1">Real-World Analogy</strong>
                        <p className="text-blue-900 font-medium">The Rulebook</p>
                        <p className="text-blue-800/80 text-sm mt-1">Like the official written rules of Football (holding is a 10-yard penalty). It is prescriptive and forward-looking.</p>
                    </div>
                </div>
                <div className="p-8">
                    <div className="flex items-center gap-3 mb-4">
                        <span className="p-2 bg-amber-100 text-amber-700 rounded-lg">
                            <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 6l3 1m0 0l-3 9a5.002 5.002 0 006.001 0M6 7l3 9M6 7l6-2m6 2l3-1m-3 1l-3 9a5.002 5.002 0 006.001 0M18 7l3 9m-3-9l-6-2m0-2v2m0 16V5m0 16H9m3 0h3" /></svg>
                        </span>
                        <h3 className="font-bold text-lg text-amber-900">Common Law</h3>
                    </div>
                    <p className="text-stone-600 mb-4 text-sm">Created by Judges through opinions. It interprets statutes or fills gaps where no statute exists.</p>
                    <div className="bg-amber-50 p-4 rounded-lg border border-amber-100">
                        <strong className="text-amber-800 text-xs uppercase tracking-wide block mb-1">Real-World Analogy</strong>
                        <p className="text-amber-900 font-medium">The Instant Replay</p>
                        <p className="text-amber-800/80 text-sm mt-1">Like when a referee decides what "a catch" is during a game. That decision sets the standard for all future catches.</p>
                    </div>
                </div>
            </div>
        </div>

        <div className="text-center">
            <button 
                onClick={() => onSelectAction("Explain the relationship between Common Law and Statutory Law. What happens when a Statute contradicts a Common Law precedent? Use an analogy.")}
                className="bg-stone-900 text-white font-bold py-4 px-8 rounded-full hover:bg-stone-700 transition-all shadow-xl hover:shadow-2xl flex items-center gap-2 mx-auto"
            >
                <span>Ask AI to Explain Deeper</span>
                <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" /></svg>
            </button>
        </div>

      </div>
    </div>
  );
};