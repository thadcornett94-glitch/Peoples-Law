import React, { useState } from 'react';
import { DEBATE_PROMPT } from '../constants';

interface DebateDojoProps {
  onSelectAction: (prompt: string) => void;
}

export const DebateDojo: React.FC<DebateDojoProps> = ({ onSelectAction }) => {
  const [topic, setTopic] = useState('');
  const [stance, setStance] = useState('');

  const handleStart = () => {
      if (!topic || !stance) return;
      
      const prompt = DEBATE_PROMPT.replace('{{TOPIC}}', topic) + `\n\nMy opening argument is: "${stance}"`;
      onSelectAction(prompt);
  };

  const topics = [
      "The Death Penalty", 
      "Gun Control (2nd Amendment)", 
      "Free Speech on Social Media", 
      "Term Limits for Congress", 
      "Electoral College vs Popular Vote",
      "Right to Privacy vs National Security",
      "Campaign Finance & Citizens United",
      "Universal Healthcare as a Right",
      "Affirmative Action",
      "Legalization of Drugs"
  ];

  const handleRandomTopic = () => {
      const random = topics[Math.floor(Math.random() * topics.length)];
      setTopic(random);
  };

  return (
    <div className="flex flex-col h-full overflow-y-auto animate-fade-in bg-[#f5f4f1] pb-12">
      <div className="max-w-4xl mx-auto w-full p-4 md:p-12">
        
        <div className="text-center mb-10">
           <div className="inline-flex items-center justify-center p-4 bg-stone-900 rounded-full mb-6 shadow-xl ring-4 ring-red-500">
              <svg className="w-12 h-12 text-red-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M13 10V3L4 14h7v7l9-11h-7z" />
              </svg>
           </div>
           <h1 className="text-4xl md:text-5xl font-serif font-bold text-stone-900 mb-6 tracking-tight">Debate Dojo</h1>
           <p className="text-stone-600 max-w-2xl mx-auto text-xl leading-relaxed font-serif italic">
              "Iron sharpens iron, so one person sharpens another."
           </p>
        </div>

        <div className="bg-white rounded-2xl shadow-xl border border-stone-200 overflow-hidden relative">
            <div className="absolute top-0 left-0 w-full h-2 bg-gradient-to-r from-red-500 to-stone-900"></div>
            
            <div className="p-8 md:p-12">
                <div className="flex items-start gap-4 mb-6 bg-red-50 p-4 rounded-xl border border-red-100">
                    <div className="p-2 bg-red-100 rounded-lg text-red-600 shrink-0">
                        <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
                        </svg>
                    </div>
                    <div>
                        <h3 className="font-bold text-red-900">Warning: Opposing Counsel Mode</h3>
                        <p className="text-sm text-red-800">
                            In this mode, the AI will relentlessly point out logical fallacies and weak points in your argument. Do not take it personally. It is designed to toughen your reasoning.
                        </p>
                    </div>
                </div>

                <div className="space-y-6">
                    <div>
                        <div className="flex justify-between items-center mb-2">
                            <label className="block text-sm font-bold uppercase tracking-wider text-stone-500">1. Choose a Topic</label>
                            <button 
                                onClick={handleRandomTopic}
                                className="text-xs font-bold uppercase tracking-wide text-amber-700 hover:text-amber-900 flex items-center gap-1 transition-colors"
                            >
                                <svg className="w-3 h-3" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" /></svg>
                                Random Topic
                            </button>
                        </div>
                        <div className="flex flex-wrap gap-2 mb-3">
                            {topics.map(t => (
                                <button 
                                    key={t}
                                    onClick={() => setTopic(t)}
                                    className={`px-4 py-2 rounded-full text-xs font-bold uppercase tracking-wide border transition-all ${topic === t ? 'bg-stone-800 text-white border-stone-800 shadow-md' : 'bg-white text-stone-500 border-stone-200 hover:bg-stone-50 hover:border-stone-300'}`}
                                >
                                    {t}
                                </button>
                            ))}
                        </div>
                        <input 
                            type="text" 
                            placeholder="Or type your own topic..." 
                            className="w-full p-4 rounded-xl border border-stone-300 focus:ring-2 focus:ring-red-500 outline-none transition-shadow"
                            value={topic}
                            onChange={(e) => setTopic(e.target.value)}
                        />
                    </div>

                    <div>
                        <label className="block text-sm font-bold uppercase tracking-wider text-stone-500 mb-2">2. Make Your Opening Statement</label>
                        <textarea 
                            className="w-full h-32 p-4 rounded-xl border border-stone-300 focus:ring-2 focus:ring-red-500 outline-none transition-shadow"
                            placeholder="State your position clearly. E.g., 'I believe the Electoral College should be abolished because...'"
                            value={stance}
                            onChange={(e) => setStance(e.target.value)}
                        />
                    </div>

                    <button 
                        onClick={handleStart}
                        disabled={!topic || !stance}
                        className={`w-full py-4 rounded-xl font-bold uppercase tracking-widest text-sm flex items-center justify-center gap-2 transition-all shadow-lg ${!topic || !stance ? 'bg-stone-200 text-stone-400 cursor-not-allowed' : 'bg-red-700 text-white hover:bg-red-800 hover:shadow-xl hover:-translate-y-0.5'}`}
                    >
                        Enter the Ring
                        <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
                        </svg>
                    </button>
                </div>

            </div>
        </div>

      </div>
    </div>
  );
};