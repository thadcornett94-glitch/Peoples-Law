
import React, { useState } from 'react';

export const DeploymentGuide: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'about' | 'safety' | 'terms'>('about');

  return (
    <div className="flex flex-col h-full overflow-y-auto animate-fade-in bg-[#f5f4f1] pb-12">
      <div className="max-w-4xl mx-auto w-full p-4 md:p-12">
        
        <div className="text-center mb-10">
           <div className="inline-flex items-center justify-center p-4 bg-stone-900 rounded-full mb-6 shadow-sm ring-4 ring-stone-200 text-stone-100">
              <svg className="w-10 h-10" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
           </div>
           <h1 className="text-3xl md:text-5xl font-serif font-bold text-stone-900 mb-4">About The People's Law</h1>
           <p className="text-stone-600 max-w-2xl mx-auto text-lg mb-8">
              "The Civics Operating System." Empowering citizens with accessible legal knowledge.
           </p>

           <div className="flex flex-wrap justify-center gap-4 mb-8">
              <button
                 onClick={() => setActiveTab('about')}
                 className={`px-6 py-2 rounded-full font-bold text-sm uppercase tracking-wide transition-all ${
                    activeTab === 'about' 
                    ? 'bg-stone-900 text-white shadow-md' 
                    : 'bg-white text-stone-500 border border-stone-200 hover:bg-stone-50'
                 }`}
              >
                 Our Mission
              </button>
              <button
                 onClick={() => setActiveTab('safety')}
                 className={`px-6 py-2 rounded-full font-bold text-sm uppercase tracking-wide transition-all ${
                    activeTab === 'safety' 
                    ? 'bg-amber-700 text-white shadow-md' 
                    : 'bg-white text-stone-500 border border-stone-200 hover:bg-stone-50'
                 }`}
              >
                 Privacy & Safety
              </button>
              <button
                 onClick={() => setActiveTab('terms')}
                 className={`px-6 py-2 rounded-full font-bold text-sm uppercase tracking-wide transition-all ${
                    activeTab === 'terms' 
                    ? 'bg-blue-800 text-white shadow-md' 
                    : 'bg-white text-stone-500 border border-stone-200 hover:bg-stone-50'
                 }`}
              >
                 Terms of Use
              </button>
           </div>
        </div>

        {activeTab === 'about' && (
            <div className="space-y-8 animate-fade-in">
                <div className="bg-white p-8 rounded-2xl border border-stone-200 shadow-lg">
                    <h2 className="text-2xl font-serif font-bold text-stone-900 mb-4">Democratizing the Law</h2>
                    <p className="text-stone-600 mb-6 leading-relaxed">
                        The law belongs to the people, but too often it is hidden behind expensive lawyers and confusing jargon. 
                        <strong>The People's Law</strong> was built to bridge that gap. 
                    </p>
                    <p className="text-stone-600 mb-6 leading-relaxed">
                        By combining advanced AI with a "Safety First" approach, we provide a free, private, and accessible way for anyone to:
                    </p>
                    <ul className="space-y-3 mb-8">
                        <li className="flex items-center gap-3 text-stone-700">
                            <svg className="w-5 h-5 text-green-600" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" /></svg>
                            Understand their Constitutional Rights.
                        </li>
                        <li className="flex items-center gap-3 text-stone-700">
                            <svg className="w-5 h-5 text-green-600" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" /></svg>
                            Navigate interactions with Police and Government.
                        </li>
                        <li className="flex items-center gap-3 text-stone-700">
                            <svg className="w-5 h-5 text-green-600" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" /></svg>
                            Draft basic legal documents to protect themselves.
                        </li>
                    </ul>
                    
                    <div className="bg-stone-50 p-4 rounded-xl border border-stone-100 flex items-center gap-4">
                        <div className="p-2 bg-white rounded-lg border border-stone-200 shadow-sm">
                             <svg className="w-6 h-6 text-blue-500" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M16 3L19 9L22 3M6 13L12 17L18 13M6 13L3 9L6 5L12 9L18 5L21 9L18 13L12 17L6 13Z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                            </svg>
                        </div>
                        <div>
                            <h4 className="font-bold text-stone-800 text-sm">Powered by Google Gemini</h4>
                            <p className="text-xs text-stone-500">
                                Utilizing advanced AI models grounded in Google Search for real-time legal accuracy.
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        )}

        {activeTab === 'safety' && (
            <div className="space-y-8 animate-fade-in">
                <div className="bg-amber-50 border-l-4 border-amber-500 p-6 rounded-r-xl">
                    <h2 className="text-xl font-bold text-amber-900 mb-2">Your Privacy is Paramount</h2>
                    <p className="text-amber-800">
                        Legal questions are sensitive. We designed this app to respect your privacy by default.
                    </p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="bg-white p-6 rounded-2xl border border-stone-200 shadow-sm">
                        <div className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center text-green-600 mb-4">
                            <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" /></svg>
                        </div>
                        <h3 className="font-bold text-lg text-stone-900 mb-2">Local Data Storage</h3>
                        <p className="text-sm text-stone-600 mb-4">
                            Your "Briefcase" bookmarks, learning progress, and settings are stored <strong>locally on your device</strong> (browser). We do not have a central database of your user profile.
                        </p>
                    </div>

                    <div className="bg-white p-6 rounded-2xl border border-stone-200 shadow-sm">
                        <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center text-blue-600 mb-4">
                            <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13.828 10.172a4 4 0 00-5.656 0l-4 4a4 4 0 105.656 5.656l1.102-1.101m-.758-4.899a4 4 0 005.656 0l4-4a4 4 0 00-5.656-5.656l-1.1 1.1" /></svg>
                        </div>
                        <h3 className="font-bold text-lg text-stone-900 mb-2">No Tracking</h3>
                        <p className="text-sm text-stone-600 mb-4">
                            We do not sell your data. We do not report your queries to law enforcement or government agencies.
                        </p>
                    </div>
                </div>
            </div>
        )}

        {activeTab === 'terms' && (
            <div className="space-y-8 animate-fade-in">
                <div className="bg-white p-8 rounded-2xl border border-stone-200 shadow-sm">
                    <h3 className="font-serif font-bold text-lg text-stone-900 mb-4">Disclaimer of Liability</h3>
                    <ul className="text-sm text-stone-600 list-disc list-inside space-y-3">
                        <li><strong>Not Legal Advice:</strong> This application provides general legal information and education. It is not a substitute for professional legal advice from a qualified attorney licensed in your jurisdiction.</li>
                        <li><strong>Accuracy:</strong> While we use advanced AI with grounding technology, laws change frequently and AI can make errors. Always verify citations with official sources (courts, legislatures).</li>
                        <li><strong>No Attorney-Client Relationship:</strong> Using this app does not create an attorney-client relationship. Communications are not privileged.</li>
                    </ul>
                </div>
                
                <div className="bg-stone-50 p-6 rounded-2xl border border-stone-200 text-center">
                    <p className="text-xs text-stone-400 font-medium">
                        The US Constitution and Federal Case Law are in the Public Domain.
                        <br/>
                        &copy; {new Date().getFullYear()} The People's Law. All Rights Reserved.
                    </p>
                </div>
            </div>
        )}

      </div>
    </div>
  );
};
