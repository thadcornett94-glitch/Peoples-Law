import React from 'react';

interface DisclaimerModalProps {
  onAccept: () => void;
}

export const DisclaimerModal: React.FC<DisclaimerModalProps> = ({ onAccept }) => {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-900/80 backdrop-blur-sm animate-fade-in">
      <div className="bg-white rounded-2xl shadow-2xl max-w-lg w-full border border-stone-200 overflow-hidden transform transition-all scale-100">
        <div className="p-6 md:p-8">
          <div className="flex items-center gap-3 mb-5 text-amber-700">
            <div className="p-2 bg-amber-50 rounded-full">
              <svg className="w-8 h-8" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
              </svg>
            </div>
            <h2 className="text-2xl font-serif font-bold text-stone-900">Legal Disclaimer</h2>
          </div>
          
          <div className="space-y-4 text-stone-600 leading-relaxed text-sm md:text-base border-t border-b border-stone-100 py-4">
            <p>
              <strong className="text-stone-800">The People's Law is an AI-powered educational tool</strong> designed to assist with legal research and understanding. 
            </p>
            <p>
              This application <span className="font-semibold text-red-700 bg-red-50 px-1 rounded">does not provide legal advice</span>. 
            </p>
            
            <p className="bg-emerald-50 p-3 rounded-lg border border-emerald-100 text-emerald-800 text-xs md:text-sm">
                <strong>Privacy & Liberty Assurance:</strong> Researching the law is a fundamental right. 
                Inquiring about legal statutes, criminal codes, or government powers is treated as a protected educational activity. 
                This tool does not report queries to outside entities or law enforcement.
            </p>

            <p className="bg-stone-50 p-3 rounded-lg border border-stone-200 text-stone-700 text-xs md:text-sm">
                <strong>Citation Warning:</strong> AI-generated citations, case numbers, and statute codes can occasionally be inaccurate. 
                <br/><br/>
                Always verify specific case law and statute references against official repositories such as <a href="https://www.congress.gov" target="_blank" className="underline text-amber-700">Congress.gov</a>, <a href="https://www.law.cornell.edu" target="_blank" className="underline text-amber-700">Cornell LII</a>, or official court records before relying on them.
            </p>
            <p>
              It is not a substitute for professional legal counsel. You should not rely on this information to make legal decisions. Always consult with a qualified attorney.
            </p>
          </div>

          <div className="mt-8 flex flex-col sm:flex-row gap-3">
             <button 
               onClick={onAccept}
               className="flex-1 bg-stone-800 hover:bg-stone-700 text-white font-medium py-3.5 px-4 rounded-xl transition-all shadow-md active:scale-95 flex items-center justify-center gap-2 group"
             >
               <span>I Understand & Agree</span>
               <svg className="w-4 h-4 group-hover:translate-x-1 transition-transform" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                 <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14 5l7 7m0 0l-7 7m7-7H3" />
               </svg>
             </button>
          </div>
        </div>
        <div className="bg-stone-50 px-6 py-3 border-t border-stone-100 text-center">
            <p className="text-[10px] text-stone-400 uppercase tracking-widest font-semibold">Educational Use Only • Privacy Respected</p>
        </div>
      </div>
    </div>
  );
};