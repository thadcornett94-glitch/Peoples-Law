import React, { useState } from 'react';
import { DRAFTING_TEMPLATES, PUBLIC_RECORD_TYPES, CONTRACT_REVIEW_PROMPT, IRAC_PROMPT, ARGUMENT_PROMPT, CITATION_PROMPT, PETITION_PROMPT } from '../constants';

interface DraftingLabProps {
  onSelectTemplate: (prompt: string) => void;
}

export const DraftingLab: React.FC<DraftingLabProps> = ({ onSelectTemplate }) => {
  const [activeTab, setActiveTab] = useState<'draft' | 'review' | 'analysis' | 'search' | 'petition'>('draft');
  const [reviewText, setReviewText] = useState('');
  const [analysisText, setAnalysisText] = useState('');
  const [citationText, setCitationText] = useState('');
  const [petitionText, setPetitionText] = useState('');

  const handleReview = () => {
      if (!reviewText.trim()) return;
      const prompt = CONTRACT_REVIEW_PROMPT.replace('{{TEXT}}', reviewText);
      onSelectTemplate(prompt);
  };

  const handleIRAC = () => {
      if (!analysisText.trim()) return;
      const prompt = IRAC_PROMPT.replace('{{TEXT}}', analysisText);
      onSelectTemplate(prompt);
  };

  const handleArgument = () => {
      if (!analysisText.trim()) return;
      const prompt = ARGUMENT_PROMPT.replace('{{TEXT}}', analysisText);
      onSelectTemplate(prompt);
  };

  const handleCitation = () => {
      if (!citationText.trim()) return;
      const prompt = CITATION_PROMPT.replace('{{TEXT}}', citationText);
      onSelectTemplate(prompt);
  };
  
  const handlePetition = () => {
      if (!petitionText.trim()) return;
      const prompt = PETITION_PROMPT.replace('{{TEXT}}', petitionText);
      onSelectTemplate(prompt);
  };

  return (
    <div className="flex flex-col h-full overflow-y-auto animate-fade-in bg-[#f5f4f1] pb-12">
      <div className="max-w-5xl mx-auto w-full p-4 md:p-12">
        
        <div className="text-center mb-10">
           <div className="inline-flex items-center justify-center p-4 bg-slate-100/80 rounded-full mb-6 shadow-sm ring-1 ring-slate-200">
              <svg className="w-10 h-10 text-slate-800" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
              </svg>
           </div>
           <h1 className="text-3xl md:text-5xl font-serif font-bold text-stone-900 mb-4">Legal Document Center</h1>
           <p className="text-stone-600 max-w-2xl mx-auto text-lg mb-8">
              Create drafts, analyze arguments, review contracts, or find public records.
           </p>

           <div className="flex flex-wrap justify-center gap-2 mb-8">
              <button
                 onClick={() => setActiveTab('draft')}
                 className={`px-4 py-2 rounded-full font-bold text-xs uppercase tracking-wide transition-all ${
                    activeTab === 'draft' 
                    ? 'bg-stone-800 text-white shadow-md' 
                    : 'bg-white text-stone-500 border border-stone-200 hover:bg-stone-50'
                 }`}
              >
                 Draft
              </button>
              <button
                 onClick={() => setActiveTab('analysis')}
                 className={`px-4 py-2 rounded-full font-bold text-xs uppercase tracking-wide transition-all ${
                    activeTab === 'analysis' 
                    ? 'bg-purple-800 text-white shadow-md' 
                    : 'bg-white text-stone-500 border border-stone-200 hover:bg-stone-50'
                 }`}
              >
                 Analyze & Logic
              </button>
              <button
                 onClick={() => setActiveTab('review')}
                 className={`px-4 py-2 rounded-full font-bold text-xs uppercase tracking-wide transition-all ${
                    activeTab === 'review' 
                    ? 'bg-amber-700 text-white shadow-md' 
                    : 'bg-white text-stone-500 border border-stone-200 hover:bg-stone-50'
                 }`}
              >
                 Review Contract
              </button>
              <button
                 onClick={() => setActiveTab('petition')}
                 className={`px-4 py-2 rounded-full font-bold text-xs uppercase tracking-wide transition-all ${
                    activeTab === 'petition' 
                    ? 'bg-red-700 text-white shadow-md' 
                    : 'bg-white text-stone-500 border border-stone-200 hover:bg-stone-50'
                 }`}
              >
                 Petition Gov
              </button>
              <button
                 onClick={() => setActiveTab('search')}
                 className={`px-4 py-2 rounded-full font-bold text-xs uppercase tracking-wide transition-all ${
                    activeTab === 'search' 
                    ? 'bg-blue-700 text-white shadow-md' 
                    : 'bg-white text-stone-500 border border-stone-200 hover:bg-stone-50'
                 }`}
              >
                 Records
              </button>
           </div>
        </div>

        {activeTab === 'draft' && (
            <div className="animate-fade-in">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {DRAFTING_TEMPLATES.map((template) => (
                        <div key={template.id} className="bg-white rounded-2xl border border-stone-200 p-6 hover:shadow-lg hover:border-amber-300 transition-all duration-200 group">
                            <div className="flex justify-between items-start mb-4">
                                <div className={`text-xs font-bold uppercase tracking-wider px-2 py-1 rounded ${template.difficulty === 'Beginner' ? 'bg-green-100 text-green-800' : 'bg-amber-100 text-amber-800'}`}>
                                    {template.difficulty}
                                </div>
                                <svg className="w-6 h-6 text-stone-300 group-hover:text-amber-500 transition-colors" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" />
                                </svg>
                            </div>
                            <h3 className="text-xl font-bold font-serif text-stone-900 mb-2 group-hover:text-amber-800 transition-colors">
                                {template.title}
                            </h3>
                            <p className="text-stone-600 mb-6 min-h-[3rem]">
                                {template.description}
                            </p>
                            <button 
                                onClick={() => onSelectTemplate(template.prompt)}
                                className="w-full py-3 bg-stone-100 text-stone-700 font-bold rounded-lg hover:bg-stone-900 hover:text-white transition-all flex items-center justify-center gap-2"
                            >
                                Start Drafting
                                <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14 5l7 7m0 0l-7 7m7-7H3" />
                                </svg>
                            </button>
                        </div>
                    ))}
                </div>
                <div className="mt-12 bg-amber-50 rounded-xl p-6 border border-amber-100 text-center">
                    <h4 className="font-bold text-amber-900 mb-2">Note on Legal Documents</h4>
                    <p className="text-sm text-amber-800">
                        These templates are starting points. Always review generated documents carefully. 
                        For legally binding contracts or court filings, consult a qualified attorney in your jurisdiction.
                    </p>
                </div>
            </div>
        )}

        {activeTab === 'analysis' && (
             <div className="animate-fade-in space-y-8">
                 
                 {/* Logic Tools */}
                 <div className="bg-white rounded-2xl border border-stone-200 shadow-md p-8">
                     <div className="flex items-center gap-4 mb-6">
                         <div className="p-3 bg-purple-100 rounded-xl text-purple-700">
                            <svg className="w-8 h-8" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19.428 15.428a2 2 0 00-1.022-.547l-2.387-.477a6 6 0 00-3.86.517l-.318.158a6 6 0 01-3.86.517L6.05 15.21a2 2 0 00-1.806.547M8 4h8l-1 1v5.172a2 2 0 00.586 1.414l5 5c1.26 1.26.367 3.414-1.415 3.414H4.828c-1.782 0-2.674-2.154-1.414-3.414l5-5A2 2 0 009 10.172V5L8 4z" />
                            </svg>
                         </div>
                         <div>
                            <h2 className="text-2xl font-serif font-bold text-stone-900">Legal Logic & Reasoning</h2>
                            <p className="text-stone-500">Analyze fact patterns using standard legal methods.</p>
                         </div>
                     </div>

                     <textarea 
                        className="w-full h-40 p-4 border border-stone-300 rounded-xl focus:ring-2 focus:ring-purple-500 focus:border-transparent mb-6 text-stone-800 placeholder-stone-400"
                        placeholder="Paste a fact pattern or legal position here (e.g. 'Police stopped me because my taillight was broken, then searched my trunk without consent...')"
                        value={analysisText}
                        onChange={(e) => setAnalysisText(e.target.value)}
                     />

                     <div className="flex flex-col md:flex-row gap-4">
                         <button 
                            onClick={handleIRAC}
                            disabled={!analysisText.trim()}
                            className={`flex-1 py-3 rounded-xl font-bold uppercase tracking-wider transition-all shadow-md flex items-center justify-center gap-2 ${
                                !analysisText.trim() 
                                ? 'bg-stone-200 text-stone-400 cursor-not-allowed'
                                : 'bg-stone-900 text-white hover:bg-purple-800 active:scale-95'
                            }`}
                         >
                            <span>Generate IRAC Memo</span>
                            <span className="text-[10px] opacity-70 font-normal normal-case">(Issue, Rule, Analysis, Conclusion)</span>
                         </button>

                         <button 
                            onClick={handleArgument}
                            disabled={!analysisText.trim()}
                            className={`flex-1 py-3 rounded-xl font-bold uppercase tracking-wider transition-all shadow-md flex items-center justify-center gap-2 ${
                                !analysisText.trim() 
                                ? 'bg-stone-200 text-stone-400 cursor-not-allowed'
                                : 'bg-white border-2 border-purple-800 text-purple-800 hover:bg-purple-50 active:scale-95'
                            }`}
                         >
                            <span>Build Arguments</span>
                            <span className="text-[10px] opacity-70 font-normal normal-case">(Pro & Con)</span>
                         </button>
                         
                         <button 
                            onClick={() => {
                                if (!analysisText.trim()) return;
                                onSelectTemplate(`Create a text-based Visual Logic Map (using ASCII art or a structured flowchart) to visualize the legal argument for: "${analysisText}". Show the connection between Premises and Conclusion.`);
                            }}
                            disabled={!analysisText.trim()}
                            className={`flex-1 py-3 rounded-xl font-bold uppercase tracking-wider transition-all shadow-md flex items-center justify-center gap-2 ${
                                !analysisText.trim() 
                                ? 'bg-stone-200 text-stone-400 cursor-not-allowed'
                                : 'bg-purple-100 text-purple-900 hover:bg-purple-200 active:scale-95'
                            }`}
                         >
                            <span>Logic Map</span>
                            <span className="text-[10px] opacity-70 font-normal normal-case">(Visual Flow)</span>
                         </button>
                     </div>
                 </div>

                 {/* Citation Helper */}
                 <div className="bg-white rounded-2xl border border-stone-200 shadow-md p-8">
                     <div className="flex items-center gap-4 mb-6">
                         <div className="p-3 bg-blue-100 rounded-xl text-blue-700">
                            <svg className="w-8 h-8" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253" />
                            </svg>
                         </div>
                         <div>
                            <h2 className="text-2xl font-serif font-bold text-stone-900">Citation Formatter</h2>
                            <p className="text-stone-500">Convert case names or statutes into Bluebook style citations.</p>
                         </div>
                     </div>
                     
                     <div className="flex gap-3">
                        <input 
                            type="text"
                            className="flex-1 p-4 border border-stone-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent text-stone-800 placeholder-stone-400"
                            placeholder="e.g. Roe v Wade 1973"
                            value={citationText}
                            onChange={(e) => setCitationText(e.target.value)}
                        />
                        <button 
                            onClick={handleCitation}
                            disabled={!citationText.trim()}
                            className={`px-6 rounded-xl font-bold uppercase tracking-wider transition-all shadow-md ${
                                !citationText.trim() 
                                ? 'bg-stone-200 text-stone-400 cursor-not-allowed'
                                : 'bg-blue-700 text-white hover:bg-blue-800'
                            }`}
                         >
                            Format
                         </button>
                     </div>
                 </div>

             </div>
        )}

        {activeTab === 'petition' && (
             <div className="animate-fade-in bg-white rounded-2xl border border-stone-200 shadow-md p-8">
                 <div className="flex items-center gap-4 mb-6">
                     <div className="p-3 bg-red-100 rounded-xl text-red-700">
                        <svg className="w-8 h-8" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 5.882V19.24a1.76 1.76 0 01-3.417.592l-2.147-6.15M18 13a3 3 0 100-6M5.436 13.683A4.001 4.001 0 017 6h1.832c4.1 0 7.625-1.234 9.168-3v14c-1.543-1.766-5.067-3-9.168-3H7a3.988 3.988 0 01-1.564-.317z" />
                        </svg>
                     </div>
                     <div>
                        <h2 className="text-2xl font-serif font-bold text-stone-900">Petition the Government</h2>
                        <p className="text-stone-500">Exercise your First Amendment right to a Redress of Grievances.</p>
                     </div>
                 </div>

                 <p className="text-stone-600 mb-6 text-sm">
                    Describe the issue you want to solve (e.g., "Potholes on Main St", "State Funding for Arts", "Federal Privacy Laws"). 
                    The People's Law AI will identify the correct government body and draft a formal petition letter.
                 </p>

                 <textarea 
                    className="w-full h-64 p-4 border border-stone-300 rounded-xl focus:ring-2 focus:ring-red-500 focus:border-transparent mb-6 text-stone-800 placeholder-stone-400"
                    placeholder="Describe your grievance here..."
                    value={petitionText}
                    onChange={(e) => setPetitionText(e.target.value)}
                 />

                 <div className="flex justify-between items-center">
                     <p className="text-xs text-stone-400 italic">This tool helps you communicate with representatives.</p>
                     <button 
                        onClick={handlePetition}
                        disabled={!petitionText.trim()}
                        className={`px-8 py-3 rounded-xl font-bold uppercase tracking-wider transition-all shadow-md flex items-center gap-2 ${
                            !petitionText.trim() 
                            ? 'bg-stone-200 text-stone-400 cursor-not-allowed'
                            : 'bg-red-700 text-white hover:bg-red-800 active:scale-95'
                        }`}
                     >
                        Draft Petition
                        <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z" />
                        </svg>
                     </button>
                 </div>
             </div>
        )}

        {activeTab === 'review' && (
             <div className="animate-fade-in bg-white rounded-2xl border border-stone-200 shadow-md p-8">
                 <div className="flex items-center gap-4 mb-6">
                     <div className="p-3 bg-amber-100 rounded-xl text-amber-700">
                        <svg className="w-8 h-8" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                        </svg>
                     </div>
                     <div>
                        <h2 className="text-2xl font-serif font-bold text-stone-900">Contract Analysis</h2>
                        <p className="text-stone-500">Paste a lease, waiver, or contract to check for red flags and risky terms.</p>
                     </div>
                 </div>

                 <textarea 
                    className="w-full h-64 p-4 border border-stone-300 rounded-xl focus:ring-2 focus:ring-amber-500 focus:border-transparent mb-6 text-stone-800 placeholder-stone-400"
                    placeholder="Paste the document text here..."
                    value={reviewText}
                    onChange={(e) => setReviewText(e.target.value)}
                 />

                 <div className="flex justify-between items-center">
                     <p className="text-xs text-stone-400 italic">The People's Law AI is not a lawyer. This is for informational purposes only.</p>
                     <button 
                        onClick={handleReview}
                        disabled={!reviewText.trim()}
                        className={`px-8 py-3 rounded-xl font-bold uppercase tracking-wider transition-all shadow-md flex items-center gap-2 ${
                            !reviewText.trim() 
                            ? 'bg-stone-200 text-stone-400 cursor-not-allowed'
                            : 'bg-amber-700 text-white hover:bg-amber-800 active:scale-95'
                        }`}
                     >
                        Analyze for Risks
                        <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" />
                        </svg>
                     </button>
                 </div>
             </div>
        )}

        {activeTab === 'search' && (
            <div className="animate-fade-in">
                 <div className="p-6 bg-blue-50 rounded-2xl border border-blue-100 mb-8">
                    <h2 className="text-xl font-serif font-bold text-blue-900 mb-2">Finding Public Records</h2>
                    <p className="text-blue-800 leading-relaxed text-sm">
                       Most legal documents in the US are public record. However, they are stored across thousands of different county, state, and federal databases. 
                       Select a category below, and The People's Law AI will guide you on exactly where and how to search for them in your specific area.
                    </p>
                 </div>

                 <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {PUBLIC_RECORD_TYPES.map((record) => (
                        <div key={record.id} className="bg-white rounded-xl border border-stone-200 p-6 hover:shadow-lg hover:border-blue-300 transition-all duration-200 group">
                            <div className="flex items-center gap-3 mb-4">
                                <div className="p-2 bg-blue-50 text-blue-600 rounded-lg group-hover:bg-blue-600 group-hover:text-white transition-colors">
                                    <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                                    </svg>
                                </div>
                                <h3 className="font-serif font-bold text-stone-800 group-hover:text-blue-800">{record.title}</h3>
                            </div>
                            <p className="text-stone-500 text-sm mb-6 min-h-[3rem]">
                                {record.description}
                            </p>
                            <button 
                                onClick={() => onSelectTemplate(record.prompt)}
                                className="w-full py-2.5 border border-stone-200 text-stone-600 font-bold rounded-lg hover:bg-blue-600 hover:text-white hover:border-blue-600 transition-all flex items-center justify-center gap-2 text-sm uppercase tracking-wide"
                            >
                                Guide Me
                            </button>
                        </div>
                    ))}
                 </div>
            </div>
        )}

      </div>
    </div>
  );
};