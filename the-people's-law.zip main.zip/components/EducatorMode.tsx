
import React, { useState } from 'react';

interface EducatorModeProps {
  onSelectAction: (prompt: string) => void;
}

export const EducatorMode: React.FC<EducatorModeProps> = ({ onSelectAction }) => {
  const [activeTab, setActiveTab] = useState<'tools' | 'curriculum' | 'study'>('tools');
  const [gradeLevel, setGradeLevel] = useState<string>('High School');
  const [topic, setTopic] = useState<string>('');

  // Curriculum Builder State
  const [courseTitle, setCourseTitle] = useState('');
  const [duration, setDuration] = useState('4 Weeks');
  const [standards, setStandards] = useState('');

  const tools = [
    {
      id: 'lesson',
      title: 'Lesson Plan Generator',
      description: 'Create a structured 45-minute lesson plan with learning objectives and activities.',
      icon: (
        <svg className="w-8 h-8 text-emerald-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
           <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-3 7h3m-3 4h3m-6-4h.01M9 16h.01" />
        </svg>
      )
    },
    {
      id: 'differentiation',
      title: 'Smart Differentiation',
      description: 'Rewrite a complex legal text or concept into 3 different reading levels (5th, 8th, 12th) for diverse learners.',
      icon: (
        <svg className="w-8 h-8 text-orange-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
           <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M3 4h13M3 8h9m-9 4h6m4 0l4-4m0 0l4 4m-4-4v12" />
        </svg>
      )
    },
    {
      id: 'worksheet',
      title: 'Worksheet Wizard',
      description: 'Generate a printable worksheet with Fill-in-the-Blank, Matching, or Short Answer questions (plus Answer Key).',
      icon: (
        <svg className="w-8 h-8 text-teal-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
           <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
        </svg>
      )
    },
    {
      id: 'rubric',
      title: 'Rubric Architect',
      description: 'Build a grading rubric for essays, debates, or projects with specific criteria.',
      icon: (
        <svg className="w-8 h-8 text-indigo-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
           <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-6 9l2 2 4-4" />
        </svg>
      )
    },
    {
      id: 'debate',
      title: 'Debate Topic Builder',
      description: 'Generate a balanced topic with arguments for both sides to spark classroom discussion.',
      icon: (
        <svg className="w-8 h-8 text-blue-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
           <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M17 8h2a2 2 0 012 2v6a2 2 0 01-2 2h-2v4l-4-4H9a1.994 1.994 0 01-1.414-.586m0 0L11 14h4a2 2 0 002-2V6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2v4l.586-.586z" />
        </svg>
      )
    },
    {
      id: 'bellringer',
      title: 'Bell Ringer / Exit Ticket',
      description: 'Quick 5-minute start-of-class questions or end-of-class reflection prompts.',
      icon: (
        <svg className="w-8 h-8 text-rose-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
           <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
        </svg>
      )
    }
  ];

  const handleAction = (type: string) => {
    if (!topic.trim()) return;

    let prompt = '';
    switch (type) {
      case 'lesson':
        prompt = `Create a 45-minute lesson plan for ${gradeLevel} students about: "${topic}". Include Learning Objectives, Key Vocabulary, a Main Activity, and Discussion Questions. Use analogies to explain complex concepts.`;
        break;
      case 'debate':
        prompt = `Create a classroom debate topic for ${gradeLevel} students based on: "${topic}". Provide a clear resolution statement, 3 strong arguments for the Affirmative side, and 3 strong arguments for the Negative side.`;
        break;
      case 'differentiation':
        prompt = `Act as a reading specialist. Take the legal concept or text regarding "${topic}" and explain it in three distinct versions for differentiation:
        1. **Elementary Level (5th Grade):** Simple language, sports/game analogies.
        2. **Middle School Level (8th Grade):** Moderate complexity, relatable teen scenarios.
        3. **High School/AP Level (12th Grade):** Technical but clear, focusing on constitutional precedent.
        
        Format clearly with headers.`;
        break;
      case 'worksheet':
        prompt = `Create a 1-page worksheet for ${gradeLevel} students about "${topic}".
        Include:
        1. **5 Fill-in-the-blank questions** (with a word bank).
        2. **5 Matching questions** (Term to Definition).
        3. **2 Short Answer critical thinking questions**.
        
        **Teacher's Answer Key** (Provide this at the very bottom).`;
        break;
      case 'rubric':
        prompt = `Create a grading rubric (in a Markdown Table) for a student assignment on "${topic}" for ${gradeLevel} students.
        Criteria to include: Legal Accuracy, Use of Evidence, Clarity of Argument, and formatting.
        Scale: 1 (Needs Improvement) to 4 (Exceeds Expectations).`;
        break;
      case 'bellringer':
        prompt = `Generate 3 "Bell Ringer" (Start of class) discussion questions and 3 "Exit Ticket" (End of class) reflection prompts for a lesson on "${topic}". Geared towards ${gradeLevel}.`;
        break;
    }
    onSelectAction(prompt);
  };

  const handleGenerateCurriculum = () => {
      if (!courseTitle.trim()) return;

      const prompt = `
      Act as an expert curriculum designer for ${gradeLevel}.
      Create a detailed ${duration} syllabus for a course titled: "${courseTitle}".
      
      Context/Standards: ${standards || 'General Civics Standards'}

      For EACH WEEK, provide:
      1. **Theme/Topic**
      2. **Learning Objectives** (What will students be able to do?)
      3. **Key Legal Concepts** (Vocabulary)
      4. **Primary Source Readings** (Specific Case Law or Statutes appropriate for ${gradeLevel})
      5. **Active Learning Activity** (Simulation, Mock Trial, or Debate)

      Format this as a structured course outline using Markdown.
      `;
      onSelectAction(prompt);
  };

  const handleStudyGroup = (type: string) => {
      if (!topic.trim()) return;
      
      let prompt = '';
      if (type === 'battle') {
          prompt = `Generate a "Group Quiz Battle" about "${topic}". Create 5 challenging multiple-choice questions designed for a study group to solve together. After the questions, provide the answers and detailed explanations.`;
      } else if (type === 'roleplay') {
          prompt = `Create a legal roleplay scenario for a study group about "${topic}". Assign roles (e.g., Judge, Plaintiff, Defendant, Witness). Describe the facts of the case and give each role a secret objective or piece of information.`;
      } else if (type === 'flashcards') {
          prompt = `Generate a set of 10 study flashcards for "${topic}". Format them as Term: Definition. Focus on key legal vocabulary and landmark cases.`;
      }
      onSelectAction(prompt);
  };

  return (
    <div className="flex flex-col h-full overflow-y-auto animate-fade-in bg-[#f5f4f1] pb-12">
      <div className="max-w-4xl mx-auto w-full p-4 md:p-12">
        
        <div className="text-center mb-10">
           <div className="inline-flex items-center justify-center p-4 bg-emerald-100/80 rounded-full mb-6 shadow-sm ring-1 ring-emerald-200">
              <svg className="w-10 h-10 text-emerald-800" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z" />
              </svg>
           </div>
           <h1 className="text-3xl md:text-5xl font-serif font-bold text-stone-900 mb-4">Educators & Groups</h1>
           <p className="text-stone-600 max-w-2xl mx-auto text-lg mb-8">
              Tools designed for teachers, study groups, and classrooms to make US Law accessible and engaging.
           </p>

           {/* Tab Nav */}
           <div className="flex flex-wrap justify-center gap-2 md:gap-4 mb-8">
              <button
                 onClick={() => setActiveTab('tools')}
                 className={`px-4 md:px-6 py-2 rounded-full font-bold text-xs md:text-sm uppercase tracking-wide transition-all ${
                    activeTab === 'tools' 
                    ? 'bg-stone-800 text-white shadow-md' 
                    : 'bg-white text-stone-500 border border-stone-200 hover:bg-stone-50'
                 }`}
              >
                 Teacher Utilities
              </button>
              <button
                 onClick={() => setActiveTab('curriculum')}
                 className={`px-4 md:px-6 py-2 rounded-full font-bold text-xs md:text-sm uppercase tracking-wide transition-all ${
                    activeTab === 'curriculum' 
                    ? 'bg-emerald-700 text-white shadow-md' 
                    : 'bg-white text-stone-500 border border-stone-200 hover:bg-stone-50'
                 }`}
              >
                 Curriculum Builder
              </button>
              <button
                 onClick={() => setActiveTab('study')}
                 className={`px-4 md:px-6 py-2 rounded-full font-bold text-xs md:text-sm uppercase tracking-wide transition-all ${
                    activeTab === 'study' 
                    ? 'bg-indigo-700 text-white shadow-md' 
                    : 'bg-white text-stone-500 border border-stone-200 hover:bg-stone-50'
                 }`}
              >
                 Study Groups
              </button>
           </div>
        </div>

        {activeTab === 'tools' && (
            <div className="animate-fade-in">
                {/* Configuration Bar */}
                <div className="bg-white p-6 rounded-2xl border border-stone-200 shadow-sm mb-8 flex flex-col md:flex-row gap-4 items-center">
                    <div className="flex-1 w-full">
                        <label className="block text-xs font-bold uppercase tracking-wider text-stone-500 mb-2">Target Audience</label>
                        <select 
                            value={gradeLevel}
                            onChange={(e) => setGradeLevel(e.target.value)}
                            className="w-full p-3 rounded-lg border border-stone-200 bg-stone-50 text-stone-800 font-medium focus:ring-2 focus:ring-emerald-500 outline-none"
                        >
                            <option>Middle School (Grades 6-8)</option>
                            <option>High School (Grades 9-12)</option>
                            <option>College / Undergrad</option>
                            <option>Law Student</option>
                        </select>
                    </div>
                    <div className="flex-[2] w-full">
                        <label className="block text-xs font-bold uppercase tracking-wider text-stone-500 mb-2">Topic or Concept</label>
                        <input 
                            type="text" 
                            value={topic}
                            onChange={(e) => setTopic(e.target.value)}
                            placeholder="e.g. The 4th Amendment, Freedom of Speech, Marbury v. Madison"
                            className="w-full p-3 rounded-lg border border-stone-200 text-stone-800 placeholder-stone-400 focus:ring-2 focus:ring-emerald-500 outline-none"
                        />
                    </div>
                </div>

                {/* Tools Grid */}
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {tools.map(tool => (
                        <button
                            key={tool.id}
                            onClick={() => handleAction(tool.id)}
                            disabled={!topic.trim()}
                            className={`bg-white p-6 rounded-xl border border-stone-200 text-left transition-all duration-200 group flex flex-col h-full ${!topic.trim() ? 'opacity-60 cursor-not-allowed' : 'hover:shadow-lg hover:-translate-y-1 hover:border-emerald-300'}`}
                        >
                            <div className="bg-stone-50 p-3 rounded-full w-fit mb-4 group-hover:bg-white group-hover:shadow-sm transition-colors">
                                {tool.icon}
                            </div>
                            <h3 className="text-lg font-serif font-bold text-stone-800 mb-2 group-hover:text-emerald-800">{tool.title}</h3>
                            <p className="text-sm text-stone-500 leading-relaxed mb-4 flex-1">
                                {tool.description}
                            </p>
                            <div className={`mt-auto text-xs font-bold uppercase tracking-wide flex items-center gap-1 ${!topic.trim() ? 'text-stone-300' : 'text-emerald-600 group-hover:text-emerald-700'}`}>
                                Generate
                                <svg className="w-3 h-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14 5l7 7m0 0l-7 7m7-7H3" />
                                </svg>
                            </div>
                        </button>
                    ))}
                </div>
            </div>
        )}

        {activeTab === 'curriculum' && (
            <div className="animate-fade-in bg-white rounded-2xl border border-stone-200 shadow-md p-8">
                <div className="flex items-center gap-4 mb-6">
                     <div className="p-3 bg-emerald-100 rounded-xl text-emerald-700">
                        <svg className="w-8 h-8" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" />
                        </svg>
                     </div>
                     <div>
                        <h2 className="text-2xl font-serif font-bold text-stone-900">Curriculum Designer</h2>
                        <p className="text-stone-500">Design comprehensive course syllabi tailored to your students.</p>
                     </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                    <div>
                        <label className="block text-xs font-bold uppercase tracking-wider text-stone-500 mb-2">Course Title</label>
                        <input 
                            type="text" 
                            value={courseTitle}
                            onChange={(e) => setCourseTitle(e.target.value)}
                            placeholder="e.g. Constitutional Law 101"
                            className="w-full p-3 rounded-lg border border-stone-200 text-stone-800 focus:ring-2 focus:ring-emerald-500 outline-none"
                        />
                    </div>
                    <div>
                        <label className="block text-xs font-bold uppercase tracking-wider text-stone-500 mb-2">Grade Level</label>
                        <select 
                            value={gradeLevel}
                            onChange={(e) => setGradeLevel(e.target.value)}
                            className="w-full p-3 rounded-lg border border-stone-200 bg-stone-50 text-stone-800 focus:ring-2 focus:ring-emerald-500 outline-none"
                        >
                            <option>Middle School</option>
                            <option>High School</option>
                            <option>Advanced Placement (AP)</option>
                            <option>Undergraduate</option>
                        </select>
                    </div>
                    <div>
                        <label className="block text-xs font-bold uppercase tracking-wider text-stone-500 mb-2">Duration</label>
                        <select 
                            value={duration}
                            onChange={(e) => setDuration(e.target.value)}
                            className="w-full p-3 rounded-lg border border-stone-200 bg-stone-50 text-stone-800 focus:ring-2 focus:ring-emerald-500 outline-none"
                        >
                            <option>1 Week Unit</option>
                            <option>4 Weeks</option>
                            <option>8 Weeks (Quarter)</option>
                            <option>1 Semester</option>
                        </select>
                    </div>
                    <div>
                        <label className="block text-xs font-bold uppercase tracking-wider text-stone-500 mb-2">Standards/Focus (Optional)</label>
                        <input 
                            type="text" 
                            value={standards}
                            onChange={(e) => setStandards(e.target.value)}
                            placeholder="e.g. Common Core, State Civics Standards"
                            className="w-full p-3 rounded-lg border border-stone-200 text-stone-800 focus:ring-2 focus:ring-emerald-500 outline-none"
                        />
                    </div>
                </div>

                <button 
                    onClick={handleGenerateCurriculum}
                    disabled={!courseTitle.trim()}
                    className={`w-full py-4 rounded-xl font-bold uppercase tracking-widest text-sm flex items-center justify-center gap-2 transition-all shadow-lg ${!courseTitle.trim() ? 'bg-stone-200 text-stone-400 cursor-not-allowed' : 'bg-emerald-700 text-white hover:bg-emerald-800 hover:shadow-xl hover:-translate-y-0.5'}`}
                >
                    Generate Full Syllabus
                    <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z" />
                    </svg>
                </button>
            </div>
        )}

        {activeTab === 'study' && (
            <div className="animate-fade-in space-y-8">
                <div className="bg-indigo-50 border border-indigo-100 p-6 rounded-2xl flex items-center gap-4">
                    <div className="bg-indigo-100 p-3 rounded-full text-indigo-600 shrink-0">
                        <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" />
                        </svg>
                    </div>
                    <div>
                        <h2 className="text-xl font-serif font-bold text-indigo-900">Study Group Tools</h2>
                        <p className="text-indigo-800 text-sm">Collaborative learning resources for law students and study partners.</p>
                    </div>
                </div>

                <div className="bg-white p-6 rounded-2xl border border-stone-200 shadow-sm">
                    <label className="block text-xs font-bold uppercase tracking-wider text-stone-500 mb-2">Study Topic</label>
                    <input 
                        type="text" 
                        value={topic}
                        onChange={(e) => setTopic(e.target.value)}
                        placeholder="e.g. Torts, Criminal Procedure, The Federalist Papers"
                        className="w-full p-4 rounded-xl border border-stone-200 text-lg text-stone-800 focus:ring-2 focus:ring-indigo-500 outline-none mb-6"
                    />

                    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                        <button 
                            onClick={() => handleStudyGroup('battle')}
                            disabled={!topic.trim()}
                            className={`p-6 rounded-xl border-2 text-left transition-all group ${!topic.trim() ? 'opacity-50 cursor-not-allowed border-stone-100 bg-stone-50' : 'border-indigo-100 bg-white hover:border-indigo-400 hover:shadow-md'}`}
                        >
                            <h3 className="font-bold text-indigo-900 mb-1 group-hover:text-indigo-700">Group Quiz Battle</h3>
                            <p className="text-xs text-stone-500 mb-3">5 hard questions for the group to solve together.</p>
                            <span className="text-xs font-bold uppercase tracking-wide text-indigo-600">Start Battle &rarr;</span>
                        </button>

                        <button 
                            onClick={() => handleStudyGroup('roleplay')}
                            disabled={!topic.trim()}
                            className={`p-6 rounded-xl border-2 text-left transition-all group ${!topic.trim() ? 'opacity-50 cursor-not-allowed border-stone-100 bg-stone-50' : 'border-purple-100 bg-white hover:border-purple-400 hover:shadow-md'}`}
                        >
                            <h3 className="font-bold text-purple-900 mb-1 group-hover:text-purple-700">Roleplay Scenario</h3>
                            <p className="text-xs text-stone-500 mb-3">Assign roles (Judge, Plaintiff) for a mock argument.</p>
                            <span className="text-xs font-bold uppercase tracking-wide text-purple-600">Generate Roles &rarr;</span>
                        </button>

                        <button 
                            onClick={() => handleStudyGroup('flashcards')}
                            disabled={!topic.trim()}
                            className={`p-6 rounded-xl border-2 text-left transition-all group ${!topic.trim() ? 'opacity-50 cursor-not-allowed border-stone-100 bg-stone-50' : 'border-amber-100 bg-white hover:border-amber-400 hover:shadow-md'}`}
                        >
                            <h3 className="font-bold text-amber-900 mb-1 group-hover:text-amber-700">Flashcard Maker</h3>
                            <p className="text-xs text-stone-500 mb-3">Generate a list of key terms and definitions.</p>
                            <span className="text-xs font-bold uppercase tracking-wide text-amber-600">Create Cards &rarr;</span>
                        </button>
                    </div>
                </div>
            </div>
        )}

      </div>
    </div>
  );
};
