import React from 'react';

interface GlobalRightsMapProps {
  onSelectRegion: (prompt: string) => void;
}

export const GlobalRightsMap: React.FC<GlobalRightsMapProps> = ({ onSelectRegion }) => {
  const regions = [
    { id: 'na', name: 'North America', path: "M 20 20 L 80 20 L 80 60 L 60 90 L 20 90 Z", labelX: 45, labelY: 45, prompt: "Compare the legal system of the United States (Common Law, Constitution) with Canada and Mexico. Focus on the differences in Civil Rights protections." },
    { id: 'sa', name: 'South America', path: "M 65 95 L 90 95 L 85 140 L 60 120 Z", labelX: 75, labelY: 110, prompt: "Explain the legal systems of South America (Civil Law tradition). How do their constitutions compare to the US Constitution regarding social rights?" },
    { id: 'eu', name: 'Europe', path: "M 110 25 L 160 25 L 150 60 L 100 50 Z", labelX: 130, labelY: 45, prompt: "Compare the European Union legal framework (GDPR, Human Rights) with US Law. Explain the difference between Civil Law (Codes) and US Common Law." },
    { id: 'af', name: 'Africa', path: "M 105 65 L 160 65 L 150 130 L 115 130 Z", labelX: 135, labelY: 90, prompt: "Overview of legal systems in Africa, highlighting the mix of Customary Law, Civil Law, and Common Law. How do human rights charters there compare to the US Bill of Rights?" },
    { id: 'as', name: 'Asia', path: "M 170 20 L 260 20 L 250 100 L 165 70 Z", labelX: 200, labelY: 50, prompt: "Compare major Asian legal systems (China, Japan, India) with the US legal system. Focus on the concept of 'Rule of Law' and individual vs collective rights." },
    { id: 'au', name: 'Australia', path: "M 210 110 L 250 110 L 245 140 L 205 130 Z", labelX: 230, labelY: 125, prompt: "Compare the Australian legal system with the US. Discuss why Australia does not have a Bill of Rights in their constitution and how that impacts citizens." }
  ];

  return (
    <div className="flex flex-col h-full overflow-y-auto animate-fade-in bg-[#f5f4f1] pb-12">
      <div className="max-w-6xl mx-auto w-full p-4 md:p-12">
        
        <div className="text-center mb-10">
           <div className="inline-flex items-center justify-center p-4 bg-blue-900 rounded-full mb-6 shadow-xl ring-4 ring-blue-200">
              <svg className="w-12 h-12 text-blue-100" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M3.055 11H5a2 2 0 012 2v1a2 2 0 002 2 2 2 0 012 2v2.945M8 3.935V5.5A2.5 2.5 0 0010.5 8h.5a2 2 0 012 2 2 2 0 104 0 2 2 0 012-2h1.064M15 20.488V18a2 2 0 012-2h3.064M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
           </div>
           <h1 className="text-4xl md:text-5xl font-serif font-bold text-stone-900 mb-6 tracking-tight">Global Rights Atlas</h1>
           <p className="text-stone-600 max-w-2xl mx-auto text-xl leading-relaxed font-serif italic">
              "Injustice anywhere is a threat to justice everywhere."
           </p>
        </div>

        <div className="bg-white rounded-3xl shadow-xl border border-stone-200 p-8 overflow-hidden relative">
            <div className="absolute top-0 left-0 w-full h-2 bg-gradient-to-r from-blue-400 to-indigo-600"></div>
            
            <p className="text-center text-stone-500 mb-8">
                Click on a region to compare its Legal System and Human Rights framework with the United States.
            </p>

            <div className="w-full aspect-[2/1] bg-blue-50 rounded-2xl relative overflow-hidden border border-blue-100 shadow-inner">
                {/* Abstract World Map SVG */}
                <svg viewBox="0 0 280 160" className="w-full h-full">
                    {regions.map((region) => (
                        <g 
                            key={region.id} 
                            onClick={() => onSelectRegion(region.prompt)}
                            className="cursor-pointer group hover:opacity-90 transition-opacity"
                        >
                            <path 
                                d={region.path} 
                                fill="#d6d3d1" 
                                stroke="white" 
                                strokeWidth="2" 
                                className="group-hover:fill-indigo-500 transition-colors duration-300"
                            />
                            <text 
                                x={region.labelX} 
                                y={region.labelY} 
                                textAnchor="middle" 
                                className="text-[6px] font-bold fill-stone-600 group-hover:fill-white pointer-events-none uppercase tracking-wider"
                            >
                                {region.name}
                            </text>
                        </g>
                    ))}
                </svg>
            </div>

            <div className="mt-8 grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="p-4 bg-stone-50 rounded-xl border border-stone-100">
                    <h3 className="font-bold text-stone-800 mb-2">Common Law</h3>
                    <p className="text-xs text-stone-600">US, UK, Canada, Australia. Based on judicial precedent (Case Law).</p>
                </div>
                <div className="p-4 bg-stone-50 rounded-xl border border-stone-100">
                    <h3 className="font-bold text-stone-800 mb-2">Civil Law</h3>
                    <p className="text-xs text-stone-600">Europe, South America. Based on written codes and statutes.</p>
                </div>
                <div className="p-4 bg-stone-50 rounded-xl border border-stone-100">
                    <h3 className="font-bold text-stone-800 mb-2">Religious/Customary</h3>
                    <p className="text-xs text-stone-600">Parts of Middle East, Africa, Asia. Based on religious texts or local tradition.</p>
                </div>
            </div>

        </div>

      </div>
    </div>
  );
};