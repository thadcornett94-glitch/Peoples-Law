import React, { useState, useMemo } from 'react';
import { GLOSSARY_TERMS } from '../constants';
import { Bookmark } from '../types';

interface GlossaryProps {
  onSelectTerm: (prompt: string) => void;
  bookmarks: Bookmark[];
  onToggleBookmark: (item: Bookmark) => void;
}

export const Glossary: React.FC<GlossaryProps> = ({ onSelectTerm, bookmarks, onToggleBookmark }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');

  const categories = ['All', 'Source of Law', 'Concept', 'Procedure', 'People'];

  const filteredTerms = useMemo(() => {
    return GLOSSARY_TERMS.filter(term => {
      const matchesSearch = term.term.toLowerCase().includes(searchTerm.toLowerCase()) || 
                            term.definition.toLowerCase().includes(searchTerm.toLowerCase());
      const matchesCategory = selectedCategory === 'All' || term.category === selectedCategory;
      return matchesSearch && matchesCategory;
    });
  }, [searchTerm, selectedCategory]);

  const isBookmarked = (id: string) => bookmarks.some(b => b.id === id);

  return (
    <div className="flex flex-col h-full overflow-y-auto animate-fade-in bg-[#f5f4f1] pb-12">
      <div className="max-w-5xl mx-auto w-full p-4 md:p-12">
        
        {/* Header */}
        <div className="text-center mb-10">
           <div className="inline-flex items-center justify-center p-4 bg-teal-100/80 rounded-full mb-6 shadow-sm ring-1 ring-teal-200">
              <svg className="w-10 h-10 text-teal-800" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253" />
              </svg>
           </div>
           <h1 className="text-3xl md:text-5xl font-serif font-bold text-stone-900 mb-4">Legal Glossary</h1>
           <p className="text-stone-600 max-w-2xl mx-auto text-lg mb-8">
              A comprehensive guide to legal terminology, sources of law, and definitions.
           </p>
        </div>

        {/* Sources of Law Comparison - Educational Feature */}
        <div className="mb-12 bg-white rounded-2xl border border-stone-200 shadow-md overflow-hidden">
            <div className="bg-stone-50 px-6 py-4 border-b border-stone-100">
                <h3 className="font-serif font-bold text-lg text-stone-800">Hierarchy of Authority</h3>
            </div>
            <div className="p-6 grid grid-cols-1 md:grid-cols-4 gap-4 text-center">
                 <div className="p-4 bg-amber-50 rounded-xl border border-amber-100">
                     <span className="block text-xs font-bold uppercase tracking-wider text-amber-800 mb-1">Highest</span>
                     <strong className="block text-stone-900 font-serif text-lg">Constitution</strong>
                 </div>
                 <div className="hidden md:flex items-center justify-center text-stone-300">
                     <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 8l4 4m0 0l-4 4m4-4H3" /></svg>
                 </div>
                 <div className="p-4 bg-blue-50 rounded-xl border border-blue-100">
                     <span className="block text-xs font-bold uppercase tracking-wider text-blue-800 mb-1">Legislative</span>
                     <strong className="block text-stone-900 font-serif text-lg">Statutes</strong>
                 </div>
                 <div className="hidden md:flex items-center justify-center text-stone-300">
                     <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 8l4 4m0 0l-4 4m4-4H3" /></svg>
                 </div>
                 <div className="p-4 bg-purple-50 rounded-xl border border-purple-100">
                     <span className="block text-xs font-bold uppercase tracking-wider text-purple-800 mb-1">Judicial</span>
                     <strong className="block text-stone-900 font-serif text-lg">Case Law</strong>
                 </div>
                 <div className="hidden md:flex items-center justify-center text-stone-300">
                     <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 8l4 4m0 0l-4 4m4-4H3" /></svg>
                 </div>
                 <div className="p-4 bg-stone-100 rounded-xl border border-stone-200">
                     <span className="block text-xs font-bold uppercase tracking-wider text-stone-500 mb-1">Executive</span>
                     <strong className="block text-stone-900 font-serif text-lg">Regulations</strong>
                 </div>
            </div>
        </div>

        {/* Search & Filter */}
        <div className="flex flex-col md:flex-row gap-4 mb-8 items-center">
            <div className="relative flex-1 w-full">
                <input 
                    type="text" 
                    placeholder="Search for a term..." 
                    className="w-full pl-12 pr-4 py-3 rounded-xl border border-stone-200 shadow-sm focus:ring-2 focus:ring-teal-500 focus:border-transparent outline-none"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                />
                <div className="absolute left-4 top-3.5 text-stone-400">
                    <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                    </svg>
                </div>
            </div>
            
            <div className="flex gap-2 overflow-x-auto pb-2 w-full md:w-auto no-scrollbar">
                {categories.map(cat => (
                    <button
                        key={cat}
                        onClick={() => setSelectedCategory(cat)}
                        className={`px-4 py-2 rounded-full text-xs font-bold uppercase tracking-wide whitespace-nowrap transition-colors ${
                            selectedCategory === cat 
                            ? 'bg-teal-700 text-white' 
                            : 'bg-white border border-stone-200 text-stone-500 hover:bg-stone-50'
                        }`}
                    >
                        {cat}
                    </button>
                ))}
            </div>
        </div>

        {/* Terms Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {filteredTerms.length > 0 ? (
                filteredTerms.map((term) => {
                    const saved = isBookmarked(term.id);
                    return (
                        <div key={term.id} className="bg-white rounded-xl border border-stone-200 p-6 hover:shadow-lg hover:border-teal-300 transition-all duration-200 group flex flex-col h-full">
                            <div className="flex justify-between items-start mb-2">
                                <span className={`text-[10px] font-bold uppercase tracking-wider px-2 py-1 rounded ${
                                    term.category === 'Source of Law' ? 'bg-blue-50 text-blue-700' :
                                    term.category === 'Procedure' ? 'bg-purple-50 text-purple-700' :
                                    term.category === 'People' ? 'bg-orange-50 text-orange-700' :
                                    'bg-stone-100 text-stone-600'
                                }`}>
                                    {term.category}
                                </span>
                                {/* Bookmark Button */}
                                <button
                                    onClick={(e) => {
                                        e.stopPropagation();
                                        onToggleBookmark({
                                            id: term.id,
                                            type: 'term',
                                            title: term.term,
                                            prompt: term.prompt,
                                            subtitle: term.category,
                                            timestamp: Date.now()
                                        });
                                    }}
                                    className={`p-1.5 rounded-lg transition-all ${saved ? 'text-amber-600 bg-amber-100' : 'text-stone-300 hover:text-amber-500 hover:bg-amber-50'}`}
                                    title={saved ? "Remove from Briefcase" : "Save to Briefcase"}
                                >
                                    <svg className="w-5 h-5" fill={saved ? "currentColor" : "none"} viewBox="0 0 24 24" stroke="currentColor">
                                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 5a2 2 0 012-2h10a2 2 0 012 2v16l-7-3.5L5 21V5z" />
                                    </svg>
                                </button>
                            </div>
                            
                            <h3 className="text-xl font-serif font-bold text-stone-900 mb-3 group-hover:text-teal-800 transition-colors">
                                {term.term}
                            </h3>
                            <p className="text-stone-600 text-sm leading-relaxed mb-6 flex-1">
                                {term.definition}
                            </p>
                            
                            <div className="flex gap-2 mt-auto">
                                <button 
                                    onClick={() => onSelectTerm(`Analyze the legal term "${term.term}" in depth. Discuss its historical origin, application in modern law, and any relevant landmark cases.`)}
                                    className="flex-1 py-2.5 bg-purple-50 text-purple-700 font-bold text-xs uppercase tracking-wider rounded-lg hover:bg-purple-100 transition-all flex items-center justify-center"
                                >
                                    Deep Analysis
                                </button>
                                <button 
                                    onClick={() => onSelectTerm(term.prompt)}
                                    className="flex-1 py-2.5 bg-stone-100 text-stone-600 font-bold text-xs uppercase tracking-wider rounded-lg hover:bg-teal-700 hover:text-white transition-all flex items-center justify-center gap-2"
                                >
                                    Explain
                                    <svg className="w-3 h-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z" />
                                    </svg>
                                </button>
                            </div>
                        </div>
                    );
                })
            ) : (
                <div className="col-span-full text-center py-12">
                    <p className="text-stone-400 font-serif italic text-lg">No terms found matching "{searchTerm}"</p>
                </div>
            )}
        </div>

      </div>
    </div>
  );
};