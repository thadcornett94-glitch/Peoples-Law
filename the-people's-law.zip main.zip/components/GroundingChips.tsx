import React from 'react';
import { GroundingSource } from '../types';

interface GroundingChipsProps {
  sources: GroundingSource[];
}

export const GroundingChips: React.FC<GroundingChipsProps> = ({ sources }) => {
  if (!sources || sources.length === 0) return null;

  return (
    <div className="mt-3 pt-3 border-t border-stone-200">
      <p className="text-xs font-semibold text-stone-500 uppercase tracking-wider mb-2">Sources & Citations</p>
      <div className="flex flex-wrap gap-2">
        {sources.map((source, idx) => (
          <a
            key={`${source.uri}-${idx}`}
            href={source.uri}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center px-2.5 py-1.5 rounded-md text-xs font-medium bg-stone-100 text-stone-700 hover:bg-stone-200 hover:text-stone-900 transition-colors duration-200 border border-stone-200 truncate max-w-xs"
            title={source.title}
          >
            <svg className="w-3 h-3 mr-1.5 text-stone-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13.828 10.172a4 4 0 00-5.656 0l-4 4a4 4 0 105.656 5.656l1.102-1.101m-.758-4.899a4 4 0 005.656 0l4-4a4 4 0 00-5.656-5.656l-1.1 1.1" />
            </svg>
            <span className="truncate max-w-[150px]">{source.title}</span>
          </a>
        ))}
      </div>
      <p className="text-[10px] text-stone-400 mt-1.5 italic">
          * Verify case citations and statutes with official records.
      </p>
    </div>
  );
};