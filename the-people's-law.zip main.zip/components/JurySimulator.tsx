
import React, { useState } from 'react';

interface JurySimulatorProps {
  onSelectAction: (prompt: string) => void;
}

export const JurySimulator: React.FC<JurySimulatorProps> = ({ onSelectAction }) => {
  const [activeRole, setActiveRole] = useState<string>('juror');
  const [activeScenario, setActiveScenario] = useState<string>('murder');

  const roles = [
    { 
        id: 'juror', 
        title: 'The Juror', 
        desc: 'Listen to the facts, weigh the evidence, and deliver the verdict. The fate of the accused is in your hands.', 
        icon: (
            <svg className="w-8 h-8" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M3 6l3 1m0 0l-3 9a5.002 5.002 0 006.001 0M6 7l3 9M6 7l6-2m6 2l3-1m-3 1l-3 9a5.002 5.002 0 006.001 0M18 7l3 9m-3-9l-6-2m0-2v2m0 16V5m0 16H9m3 0h3" />
            </svg>
        ),
        color: 'bg-stone-800'
    },
    { 
        id: 'defense', 
        title: 'Defense Attorney', 
        desc: 'Your client is innocent (or at least, they need to look it). Poke holes in the story, cross-examine witnesses, and create Reasonable Doubt.', 
        icon: (
            <svg className="w-8 h-8" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
            </svg>
        ),
        color: 'bg-blue-700'
    },
    { 
        id: 'prosecutor', 
        title: 'The Prosecutor', 
        desc: 'You represent the People. Your job is to present the evidence, call witnesses, and convince the jury of guilt Beyond a Reasonable Doubt.', 
        icon: (
            <svg className="w-8 h-8" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M17.657 18.657A8 8 0 016.343 7.343S7 9 9 10c0-2 .5-5 2.986-7C14 5 16.09 5.777 17.656 7.343A7.975 7.975 0 0120 13a7.975 7.975 0 01-2.343 5.657z" />
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9.879 16.121A3 3 0 1012.015 11L11 14H9c0 .768.293 1.536.879 2.121z" />
            </svg>
        ),
        color: 'bg-red-700'
    },
    { 
        id: 'judge', 
        title: 'The Judge', 
        desc: 'Maintain order in the court. Rule on objections (Sustained/Overruled), instruct the jury on the law, and ensure a fair trial.', 
        icon: (
            <svg className="w-8 h-8" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
            </svg>
        ),
        color: 'bg-purple-800'
    }
  ];

  const scenarios = [
      { id: 'murder', title: 'High-Stakes Murder', desc: 'A wealthy CEO found dead. A jealous business partner. No weapon found. Circumstantial evidence.', badge: 'Criminal' },
      { id: 'rights', title: 'Civil Rights / Protest', desc: 'A protestor arrested for "disturbing the peace". Is it Free Speech or Incitement to Riot?', badge: 'Constitutional' },
      { id: 'espionage', title: 'Corporate Espionage', desc: 'Stolen trade secrets, a whistleblower, and a billion-dollar lawsuit. Who is lying?', badge: 'Civil' },
      { id: 'selfdefense', title: 'Self-Defense Case', desc: 'A home invasion gone wrong. The homeowner shot the intruder as they were fleeing. Justified?', badge: 'Criminal' }
  ];

  const startSimulation = () => {
      let prompt = "";

      if (activeRole === 'juror') {
          prompt = `
          Act as a Jury Simulator Game Master.
          Scenario: ${scenarios.find(s => s.id === activeScenario)?.title}.
          
          I am a Juror. 
          1. Start by describing the defendant and the charges.
          2. Present the Opening Statements for both sides briefly.
          3. Present 3 key pieces of evidence (one physical, one witness, one surprise).
          4. Ask me to render a verdict (Guilty/Not Guilty).
          5. After my verdict, reveal the "truth" of what actually happened.
          `;
      } else if (activeRole === 'defense') {
          prompt = `
          Act as an Interactive Courtroom Text Adventure Game.
          I am the Defense Attorney. 
          Case: ${scenarios.find(s => s.id === activeScenario)?.title}.
          
          Start the scene in the courtroom. The Prosecutor is examining a key witness who is damaging my client's case.
          Describe what the witness says.
          Then, give me 3 options for how to react (e.g., "Object to Hearsay", "Cross-Examine aggressively", "Present contradictory evidence").
          
          Wait for my choice, then continue the drama based on my decision. Keep it tense and legally grounded.
          `;
      } else if (activeRole === 'prosecutor') {
          prompt = `
          Act as an Interactive Courtroom Text Adventure Game.
          I am the Prosecutor.
          Case: ${scenarios.find(s => s.id === activeScenario)?.title}.
          
          My goal is to convict. I am giving my Closing Argument to the jury.
          Describe the weary jury.
          Give me 3 strategies for my closing argument (e.g., "Appeal to Emotion", "Focus on the Forensic Facts", "Attack the Defendant's Character").
          
          Wait for my choice, generate the speech, and then tell me the Jury's reaction.
          `;
      } else if (activeRole === 'judge') {
          prompt = `
          Act as an Interactive Courtroom Text Adventure Game.
          I am the Judge.
          Case: ${scenarios.find(s => s.id === activeScenario)?.title}.
          
          Start the scene. The Defense Attorney and Prosecutor are getting into a heated argument over a piece of surprise evidence.
          The Defense Attorney shouts "Objection! This violates the Fourth Amendment!"
          
          Ask me to rule: "Sustained" or "Overruled".
          Explain the legal consequence of my ruling and how it changes the trial.
          `;
      }

      onSelectAction(prompt);
  };

  return (
    <div className="flex flex-col h-full overflow-y-auto animate-fade-in bg-[#f5f4f1] pb-12">
      <div className="max-w-5xl mx-auto w-full p-4 md:p-12">
        
        <div className="text-center mb-10">
           <div className="inline-flex items-center justify-center p-4 bg-stone-900 rounded-full mb-6 shadow-xl ring-4 ring-stone-300">
              <svg className="w-12 h-12 text-stone-100" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M3 6l3 1m0 0l-3 9a5.002 5.002 0 006.001 0M6 7l3 9M6 7l6-2m6 2l3-1m-3 1l-3 9a5.002 5.002 0 006.001 0M18 7l3 9m-3-9l-6-2m0-2v2m0 16V5m0 16H9m3 0h3" />
              </svg>
           </div>
           <h1 className="text-4xl md:text-5xl font-serif font-bold text-stone-900 mb-4 tracking-tight">Courtroom Simulator</h1>
           <p className="text-stone-600 max-w-2xl mx-auto text-xl leading-relaxed font-serif italic">
              "The jury system is the hand of the people on the scales of justice."
           </p>
        </div>

        <div className="bg-white rounded-2xl shadow-xl border border-stone-200 overflow-hidden relative">
            <div className="absolute top-0 left-0 w-full h-2 bg-gradient-to-r from-stone-500 to-stone-900"></div>
            
            <div className="p-8 md:p-12">
                
                {/* 1. Select Role */}
                <div className="mb-12">
                    <h2 className="text-sm font-bold uppercase tracking-wider text-stone-400 mb-4 flex items-center gap-2">
                        <span className="bg-stone-100 text-stone-600 w-6 h-6 rounded-full flex items-center justify-center text-xs">1</span>
                        Choose Your Role
                    </h2>
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                        {roles.map((role) => (
                            <button 
                                key={role.id}
                                onClick={() => setActiveRole(role.id)}
                                className={`relative p-6 rounded-xl border-2 text-left transition-all duration-300 group flex flex-col h-full ${
                                    activeRole === role.id 
                                    ? `border-stone-800 ring-2 ring-stone-200 bg-stone-50` 
                                    : 'border-stone-200 bg-white hover:border-stone-400 hover:shadow-md'
                                }`}
                            >
                                <div className={`mb-4 p-3 rounded-full w-fit text-white ${activeRole === role.id ? 'bg-stone-800' : 'bg-stone-300 group-hover:bg-stone-400'}`}>
                                    {React.cloneElement(role.icon as React.ReactElement, { className: "w-6 h-6" })}
                                </div>
                                <h3 className={`font-serif font-bold text-lg mb-2 ${activeRole === role.id ? 'text-stone-900' : 'text-stone-700'}`}>
                                    {role.title}
                                </h3>
                                <p className="text-xs text-stone-500 leading-relaxed">
                                    {role.desc}
                                </p>
                                {activeRole === role.id && (
                                    <div className="absolute top-4 right-4 text-emerald-500">
                                        <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24"><path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"/></svg>
                                    </div>
                                )}
                            </button>
                        ))}
                    </div>
                </div>

                {/* 2. Select Case */}
                <div className="mb-12">
                    <h2 className="text-sm font-bold uppercase tracking-wider text-stone-400 mb-4 flex items-center gap-2">
                        <span className="bg-stone-100 text-stone-600 w-6 h-6 rounded-full flex items-center justify-center text-xs">2</span>
                        Select Case Docket
                    </h2>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        {scenarios.map((sc) => (
                            <button
                                key={sc.id}
                                onClick={() => setActiveScenario(sc.id)}
                                className={`flex items-center gap-4 p-4 rounded-xl border transition-all ${
                                    activeScenario === sc.id 
                                    ? 'bg-amber-50 border-amber-500 shadow-sm' 
                                    : 'bg-white border-stone-200 hover:border-amber-300'
                                }`}
                            >
                                <div className={`shrink-0 w-12 h-12 rounded-lg flex items-center justify-center font-bold text-lg ${
                                    activeScenario === sc.id ? 'bg-amber-200 text-amber-800' : 'bg-stone-100 text-stone-400'
                                }`}>
                                    {sc.title.charAt(0)}
                                </div>
                                <div className="text-left">
                                    <h3 className={`font-bold ${activeScenario === sc.id ? 'text-amber-900' : 'text-stone-700'}`}>{sc.title}</h3>
                                    <p className="text-xs text-stone-500">{sc.desc}</p>
                                </div>
                                <span className={`ml-auto text-[10px] font-bold uppercase px-2 py-1 rounded border ${
                                    activeScenario === sc.id ? 'bg-white border-amber-200 text-amber-800' : 'bg-stone-50 border-stone-200 text-stone-400'
                                }`}>
                                    {sc.badge}
                                </span>
                            </button>
                        ))}
                    </div>
                </div>

                <div className="flex justify-center">
                    <button 
                        onClick={startSimulation}
                        className="px-10 py-5 bg-stone-900 text-white font-bold uppercase tracking-widest text-sm rounded-xl hover:bg-amber-700 transition-all shadow-xl hover:shadow-2xl transform hover:-translate-y-1 flex items-center gap-3"
                    >
                        <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z" />
                        </svg>
                        Enter The Courtroom
                    </button>
                </div>
                
                <p className="text-center text-xs text-stone-400 mt-6 italic">
                    Simulation powered by AI. Scenarios are fictional but based on real legal principles.
                </p>
            </div>
            
            <div className="bg-stone-100 px-8 py-4 border-t border-stone-200 flex justify-between items-center text-xs text-stone-500 font-mono uppercase">
                <span>Docket #2024-{activeScenario.toUpperCase()}</span>
                <span>Role: {activeRole.toUpperCase()}</span>
            </div>
        </div>

      </div>
    </div>
  );
};
