import React, { useState } from 'react';

interface KnowYourRightsProps {
  onSelectTopic: (prompt: string) => void;
}

export const KnowYourRights: React.FC<KnowYourRightsProps> = ({ onSelectTopic }) => {
  const [activeCategory, setActiveCategory] = useState<string | null>(null);

  const categories = [
    {
      id: 'protest',
      title: 'Protest & Assembly',
      icon: (
        <svg className="w-8 h-8 text-red-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M11 5.882V19.24a1.76 1.76 0 01-3.417.592l-2.147-6.15M18 13a3 3 0 100-6M5.436 13.683A4.001 4.001 0 017 6h1.832c4.1 0 7.625-1.234 9.168-3v14c-1.543-1.766-5.067-3-9.168-3H7a3.988 3.988 0 01-1.564-.317z" />
        </svg>
      ),
      description: "Rights during demonstrations, filming police, and free speech zones.",
      keyPoints: [
        "You have the right to protest in public spaces (sidewalks, parks).",
        "You can photograph or video police in public.",
        "Police cannot delete your photos without a warrant.",
        "You cannot block traffic or building entrances without a permit."
      ],
      script: "I am exercising my First Amendment right to assemble. Am I being detained or am I free to go?",
      prompt: "Explain my rights during a protest. Can police confiscate my phone? What are reasonable 'Time, Place, and Manner' restrictions?"
    },
    {
      id: 'digital',
      title: 'Digital Privacy',
      icon: (
        <svg className="w-8 h-8 text-blue-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M12 18h.01M8 21h8a2 2 0 002-2V5a2 2 0 00-2-2H8a2 2 0 00-2 2v14a2 2 0 002 2z" />
        </svg>
      ),
      description: "Phone searches, passwords, border crossings, and social media.",
      keyPoints: [
        "Police generally need a warrant to search your phone.",
        "You generally cannot be forced to give up a passcode (5th Amendment).",
        "Biometrics (Fingerprint/FaceID) have weaker legal protections than passcodes.",
        "Border agents have broader search powers than regular police."
      ],
      script: "I do not consent to a search of my device. I would like to speak to an attorney.",
      prompt: "Explain my digital privacy rights regarding my smartphone. Can police force me to unlock it with my face or fingerprint? How does this differ at a border crossing?"
    },
    {
      id: 'workplace',
      title: 'Workplace Rights',
      icon: (
        <svg className="w-8 h-8 text-emerald-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M21 13.255A23.931 23.931 0 0112 15c-3.183 0-6.22-.62-9-1.745M16 6V4a2 2 0 00-2-2h-4a2 2 0 00-2 2v2m4 6h.01M5 20h14a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
        </svg>
      ),
      description: "Discrimination, wages, unions, and harassment.",
      keyPoints: [
        "You have the right to discuss your wages with coworkers.",
        "You cannot be fired for discriminatory reasons (Race, Religion, Gender, etc.).",
        "You have the right to organize or join a union.",
        "Employers must provide reasonable accommodations for disabilities."
      ],
      script: "I believe I am being subjected to a hostile work environment. I am documenting this conversation.",
      prompt: "Explain my workplace rights regarding wage discussions and unionizing. What constitutes a 'Hostile Work Environment' under federal law?"
    },
    {
      id: 'housing',
      title: 'Housing & Tenants',
      icon: (
        <svg className="w-8 h-8 text-amber-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6" />
        </svg>
      ),
      description: "Evictions, landlord entry, repairs, and deposits.",
      keyPoints: [
        "Landlords usually must give notice (e.g., 24hrs) before entering.",
        "You cannot be evicted without a court order (Self-help eviction is illegal).",
        "You have a right to a habitable home (heat, water, safety).",
        "Security deposits must be returned within a specific timeframe."
      ],
      script: "I require 24-hour notice before you enter my apartment, as required by law.",
      prompt: "Explain tenant rights regarding landlord entry and 'implied warranty of habitability'. What can I do if my landlord refuses to make essential repairs?"
    },
    {
      id: 'consumer',
      title: 'Consumer Rights',
      icon: (
        <svg className="w-8 h-8 text-pink-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
        </svg>
      ),
      description: "Debt collection, scams, and 'Lemon Laws'.",
      keyPoints: [
        "Debt collectors cannot harass you or call at unreasonable times.",
        "You have the right to dispute a debt and demand verification.",
        "You have 3 days to cancel certain contracts (Cooling-off Rule).",
        "Lemon Laws protect you if you buy a defective vehicle."
      ],
      script: "I am disputing this debt. Under the FDCPA, please send me validation of the debt in writing.",
      prompt: "Explain my rights under the Fair Debt Collection Practices Act (FDCPA). What can I do if a debt collector is harassing me? Also explain the 'Cooling-off Rule' for contracts."
    },
    {
      id: 'medical',
      title: 'Medical Rights',
      icon: (
        <svg className="w-8 h-8 text-cyan-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M19.428 15.428a2 2 0 00-1.022-.547l-2.387-.477a6 6 0 00-3.86.517l-.318.158a6 6 0 01-3.86.517L6.05 15.21a2 2 0 00-1.806.547M8 4h8l-1 1v5.172a2 2 0 00.586 1.414l5 5c1.26 1.26.367 3.414-1.415 3.414H4.828c-1.782 0-2.674-2.154-1.414-3.414l5-5A2 2 0 009 10.172V5L8 4z" />
        </svg>
      ),
      description: "HIPAA, medical records, and informed consent.",
      keyPoints: [
        "You have the right to see and get a copy of your medical records.",
        "Doctors cannot share your info without consent (HIPAA), with exceptions.",
        "You have the right to Informed Consent before any procedure.",
        "You have the right to an interpreter."
      ],
      script: "I am requesting a full copy of my medical records under HIPAA. I do not consent to sharing this info.",
      prompt: "Explain my rights under HIPAA regarding my medical records. Can I be charged for copies? What is 'Informed Consent' and when is it required?"
    },
    {
      id: 'immigration',
      title: 'Immigration (ICE)',
      icon: (
        <svg className="w-8 h-8 text-purple-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M3.055 11H5a2 2 0 012 2v1a2 2 0 002 2 2 2 0 012 2v2.945M8 3.935V5.5A2.5 2.5 0 0010.5 8h.5a2 2 0 012 2 2 2 0 104 0 2 2 0 012-2h1.064M15 20.488V18a2 2 0 012-2h3.064M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
        </svg>
      ),
      description: "Rights regardless of status, warrants, and silence.",
      keyPoints: [
        "You have rights regardless of your immigration status.",
        "Do not open your door to ICE unless they show a JUDICIAL warrant signed by a judge.",
        "Administrative warrants (form I-200, I-205) do not allow them to enter your home.",
        "You have the right to remain silent."
      ],
      script: "I do not consent to a search. Show me a judicial warrant signed by a judge through the window.",
      prompt: "Explain the difference between a Judicial Warrant and an Administrative Warrant regarding ICE agents entering a home. What are my rights if I am undocumented?"
    },
    {
      id: 'voting',
      title: 'Voting Rights',
      icon: (
        <svg className="w-8 h-8 text-stone-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
        </svg>
      ),
      description: "Registration, ID laws, and accessibility.",
      keyPoints: [
        "If you are in line when polls close, you have the right to vote.",
        "You have the right to a provisional ballot if your name isn't on the list.",
        "Voter intimidation is illegal.",
        "Voters with disabilities have the right to assistance."
      ],
      script: "I am a registered voter and I have the right to cast a provisional ballot.",
      prompt: "Explain my voting rights if I am challenged at the polls. What is a provisional ballot and when should I use one?"
    }
  ];

  return (
    <div className="flex flex-col h-full overflow-y-auto animate-fade-in bg-[#f5f4f1] pb-12">
      <div className="max-w-5xl mx-auto w-full p-4 md:p-12">
        
        <div className="text-center mb-10">
           <div className="inline-flex items-center justify-center p-4 bg-teal-100/80 rounded-full mb-6 shadow-sm ring-1 ring-teal-200">
              <svg className="w-10 h-10 text-teal-800" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
              </svg>
           </div>
           <h1 className="text-3xl md:text-5xl font-serif font-bold text-stone-900 mb-4">Know Your Rights</h1>
           <p className="text-stone-600 max-w-2xl mx-auto text-lg mb-8">
              A comprehensive library of your civil liberties in various situations. Click a topic to learn more.
           </p>
        </div>

        {/* Category Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {categories.map((cat) => (
                <button
                    key={cat.id}
                    onClick={() => setActiveCategory(cat.id === activeCategory ? null : cat.id)}
                    className={`text-left transition-all duration-300 group rounded-2xl border ${
                        activeCategory === cat.id 
                        ? 'bg-white border-teal-500 shadow-xl ring-2 ring-teal-100 transform scale-[1.02]' 
                        : 'bg-white border-stone-200 hover:border-teal-300 hover:shadow-lg'
                    }`}
                >
                    <div className="p-6">
                        <div className="flex items-center gap-4 mb-4">
                            <div className={`p-3 rounded-full transition-colors ${activeCategory === cat.id ? 'bg-teal-50' : 'bg-stone-50 group-hover:bg-teal-50'}`}>
                                {cat.icon}
                            </div>
                            <h3 className="text-xl font-serif font-bold text-stone-800 group-hover:text-teal-900">{cat.title}</h3>
                        </div>
                        <p className="text-stone-500 text-sm leading-relaxed mb-4">
                            {cat.description}
                        </p>
                        
                        {/* Expanded Content */}
                        {activeCategory === cat.id && (
                            <div className="mt-6 pt-6 border-t border-stone-100 animate-fade-in">
                                <h4 className="text-xs font-bold uppercase tracking-widest text-stone-400 mb-3">Key Rights</h4>
                                <ul className="space-y-2 mb-6">
                                    {cat.keyPoints.map((point, i) => (
                                        <li key={i} className="flex items-start gap-2 text-sm text-stone-700">
                                            <svg className="w-4 h-4 text-teal-500 mt-0.5 shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                                            </svg>
                                            {point}
                                        </li>
                                    ))}
                                </ul>

                                <div className="bg-stone-50 p-4 rounded-xl border border-stone-200 mb-6">
                                    <h4 className="text-xs font-bold uppercase tracking-widest text-stone-400 mb-2">What to Say (Script)</h4>
                                    <p className="font-serif italic text-stone-800 text-lg leading-relaxed">"{cat.script}"</p>
                                </div>

                                <button 
                                    onClick={(e) => {
                                        e.stopPropagation();
                                        onSelectTopic(cat.prompt);
                                    }}
                                    className="w-full py-3 bg-stone-900 text-white font-bold rounded-lg uppercase tracking-wider text-xs hover:bg-teal-700 transition-colors shadow-md flex items-center justify-center gap-2"
                                >
                                    Ask AI for Advice
                                    <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14 5l7 7m0 0l-7 7m7-7H3" />
                                    </svg>
                                </button>
                            </div>
                        )}
                        
                        {/* Expand hint */}
                        {activeCategory !== cat.id && (
                            <div className="text-teal-600 text-xs font-bold uppercase tracking-wide flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                                View Details
                                <svg className="w-3 h-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                                </svg>
                            </div>
                        )}
                    </div>
                </button>
            ))}
        </div>

      </div>
    </div>
  );
};