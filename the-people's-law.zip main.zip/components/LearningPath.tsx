import React, { useState, useMemo, useEffect } from 'react';
import { LEARNING_CURRICULUM } from '../constants';
import { LearningModule } from '../types';
import { generateCustomCurriculum } from '../services/geminiService';

interface LearningPathProps {
  completedTopics: Set<string>;
  onToggleComplete: (id: string) => void;
  onStartTopic: (prompt: string) => void;
}

export const LearningPath: React.FC<LearningPathProps> = ({ completedTopics, onToggleComplete, onStartTopic }) => {
  
  // State for Custom Modules
  const [customModules, setCustomModules] = useState<LearningModule[]>(() => {
    try {
        const saved = localStorage.getItem('amicus_custom_modules');
        return saved ? JSON.parse(saved) : [];
    } catch (e) {
        return [];
    }
  });

  const [customGoal, setCustomGoal] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [generationError, setGenerationError] = useState<string | null>(null);

  // Combine Default + Custom Modules
  const allModules = useMemo(() => {
      return [...LEARNING_CURRICULUM, ...customModules];
  }, [customModules]);

  // Save custom modules when updated
  useEffect(() => {
    localStorage.setItem('amicus_custom_modules', JSON.stringify(customModules));
  }, [customModules]);
  
  // Calculate total progress
  const progressStats = useMemo(() => {
    let total = 0;
    let completed = 0;
    allModules.forEach(mod => {
      mod.topics.forEach(topic => {
        total++;
        if (completedTopics.has(topic.id)) completed++;
      });
    });
    return { total, completed, percentage: total === 0 ? 0 : Math.round((completed / total) * 100) };
  }, [completedTopics, allModules]);

  const handleGenerateCurriculum = async () => {
      if (!customGoal.trim()) return;
      
      setIsGenerating(true);
      setGenerationError(null);

      try {
          const newModule = await generateCustomCurriculum(customGoal);
          if (newModule) {
              setCustomModules(prev => [...prev, newModule]);
              setCustomGoal('');
          } else {
              setGenerationError("Could not generate curriculum. Please try a different topic.");
          }
      } catch (e) {
          setGenerationError("An error occurred. Please try again.");
      } finally {
          setIsGenerating(false);
      }
  };

  const removeModule = (moduleId: string) => {
      setCustomModules(prev => prev.filter(m => m.id !== moduleId));
  };

  return (
    <div className="flex flex-col h-full overflow-y-auto animate-fade-in bg-[#f5f4f1] pb-12">
       <div className="max-w-4xl mx-auto w-full p-4 md:p-12">
          
          {/* Header Section */}
          <div className="text-center mb-10">
             <div className="inline-flex items-center justify-center p-4 bg-emerald-100/80 rounded-full mb-6 shadow-sm ring-1 ring-emerald-200">
                <svg className="w-10 h-10 text-emerald-800" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                   <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253" />
                </svg>
             </div>
             <h1 className="text-3xl md:text-4xl font-serif font-bold text-stone-900 mb-3">My Learning Path</h1>
             <p className="text-stone-600 max-w-xl mx-auto text-lg mb-8">
                Master the law with a structured curriculum or generate a custom plan tailored to your interests.
             </p>

             {/* Overall Progress Bar */}
             <div className="max-w-md mx-auto bg-stone-200 rounded-full h-4 relative overflow-hidden shadow-inner">
                <div 
                  className="absolute top-0 left-0 h-full bg-gradient-to-r from-emerald-600 to-emerald-400 transition-all duration-1000 ease-out"
                  style={{ width: `${progressStats.percentage}%` }}
                />
             </div>
             <p className="text-xs font-bold uppercase tracking-widest text-emerald-800 mt-3">
                {progressStats.completed} / {progressStats.total} Topics Completed ({progressStats.percentage}%)
             </p>
          </div>

          {/* Custom Curriculum Generator */}
          <div className="bg-white rounded-2xl border border-stone-200 shadow-md p-6 mb-12 animate-fade-in-up">
              <div className="flex items-center gap-3 mb-4">
                  <div className="bg-amber-100 p-2 rounded-lg text-amber-700">
                      <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
                      </svg>
                  </div>
                  <h2 className="text-xl font-serif font-bold text-stone-900">Design Your Own Path</h2>
              </div>
              <p className="text-stone-500 text-sm mb-4 leading-relaxed">
                  Want to learn about something specific like "Intellectual Property", "Immigration Law", or "Tenant Rights"? 
                  Amicus will generate a custom lesson plan for you.
              </p>
              
              <div className="flex flex-col md:flex-row gap-3">
                  <input 
                    type="text" 
                    value={customGoal}
                    onChange={(e) => setCustomGoal(e.target.value)}
                    placeholder="E.g., Understanding Copyright Law..."
                    className="flex-1 px-4 py-3 rounded-xl border border-stone-300 focus:ring-2 focus:ring-amber-500 focus:border-transparent outline-none"
                    disabled={isGenerating}
                  />
                  <button 
                    onClick={handleGenerateCurriculum}
                    disabled={isGenerating || !customGoal.trim()}
                    className={`px-6 py-3 rounded-xl font-bold uppercase tracking-wider text-sm flex items-center justify-center gap-2 transition-all ${
                        isGenerating 
                        ? 'bg-stone-200 text-stone-400 cursor-not-allowed' 
                        : 'bg-amber-700 text-white hover:bg-amber-800 shadow-md'
                    }`}
                  >
                      {isGenerating ? (
                          <>
                            <svg className="w-4 h-4 animate-spin" fill="none" viewBox="0 0 24 24">
                                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                            </svg>
                            Creating...
                          </>
                      ) : (
                          <>Generate Plan</>
                      )}
                  </button>
              </div>
              {generationError && (
                  <p className="text-red-600 text-xs mt-3 font-medium">{generationError}</p>
              )}
          </div>

          {/* Modules List */}
          <div className="space-y-8">
             {allModules.map((module, modIdx) => (
                <div key={module.id} className={`bg-white rounded-2xl border shadow-sm overflow-hidden animate-fade-in-up ${module.id.startsWith('custom') ? 'border-amber-200' : 'border-stone-200'}`} style={{ animationDelay: `${modIdx * 100}ms` }}>
                   <div className={`px-6 py-4 border-b flex items-center justify-between ${module.id.startsWith('custom') ? 'bg-amber-50/50 border-amber-100' : 'bg-stone-50 border-stone-100'}`}>
                      <div className="flex items-center gap-3">
                          <h2 className={`text-lg font-serif font-bold ${module.id.startsWith('custom') ? 'text-amber-900' : 'text-stone-800'}`}>{module.title}</h2>
                          {module.id.startsWith('custom') && (
                              <span className="text-[10px] bg-amber-200 text-amber-800 px-2 py-0.5 rounded font-bold uppercase tracking-wide">Custom</span>
                          )}
                      </div>
                      <div className="flex items-center gap-4">
                          <span className="text-xs text-stone-500 font-medium hidden sm:inline-block">{module.description}</span>
                          {module.id.startsWith('custom') && (
                              <button 
                                onClick={() => removeModule(module.id)}
                                className="text-red-400 hover:text-red-600 transition-colors"
                                title="Delete Module"
                              >
                                  <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                                  </svg>
                              </button>
                          )}
                      </div>
                   </div>
                   <div className="divide-y divide-stone-100">
                      {module.topics.map((topic) => {
                         const isCompleted = completedTopics.has(topic.id);
                         return (
                            <div key={topic.id} className={`p-4 md:p-6 transition-colors hover:bg-stone-50 flex flex-col md:flex-row md:items-center gap-4 ${isCompleted ? 'bg-emerald-50/30' : ''}`}>
                               {/* Checkbox Area */}
                               <div className="flex-shrink-0">
                                  <button 
                                    onClick={() => onToggleComplete(topic.id)}
                                    className={`w-8 h-8 rounded-full border-2 flex items-center justify-center transition-all ${
                                       isCompleted 
                                         ? 'bg-emerald-500 border-emerald-500 text-white shadow-sm scale-110' 
                                         : 'border-stone-300 text-transparent hover:border-emerald-400'
                                    }`}
                                    title={isCompleted ? "Mark as incomplete" : "Mark as complete"}
                                  >
                                     <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
                                     </svg>
                                  </button>
                               </div>

                               {/* Content Area */}
                               <div className="flex-1">
                                  <div className="flex items-center gap-3 mb-1">
                                    <h3 className={`font-bold text-stone-800 text-base ${isCompleted ? 'line-through text-stone-400' : ''}`}>
                                       {topic.title}
                                    </h3>
                                    <span className="text-[10px] font-bold uppercase tracking-wider text-stone-400 bg-stone-100 px-2 py-0.5 rounded">
                                       {topic.duration}
                                    </span>
                                  </div>
                                  <p className="text-sm text-stone-500">{topic.description}</p>
                               </div>

                               {/* Action Button */}
                               <div className="flex-shrink-0 mt-2 md:mt-0">
                                  <button
                                     onClick={() => onStartTopic(topic.prompt)}
                                     className="w-full md:w-auto px-4 py-2 rounded-lg text-xs font-bold uppercase tracking-wider bg-stone-800 text-white hover:bg-amber-700 transition-colors shadow-sm flex items-center justify-center gap-2"
                                  >
                                     Start Lesson
                                     <svg className="w-3 h-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14 5l7 7m0 0l-7 7m7-7H3" />
                                     </svg>
                                  </button>
                               </div>
                            </div>
                         );
                      })}
                   </div>
                </div>
             ))}
          </div>
       </div>
    </div>
  );
};