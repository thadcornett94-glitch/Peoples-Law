import React, { useState, useRef, useEffect } from 'react';
import { Message, Role } from '../types';
import { GroundingChips } from './GroundingChips';
import { generateSpeech } from '../services/geminiService';

declare const html2canvas: any;

interface MessageBubbleProps {
  message: Message;
  voicePreference: string;
}

export const MessageBubble: React.FC<MessageBubbleProps> = ({ message, voicePreference }) => {
  const isUser = message.role === Role.USER;
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [isLoadingAudio, setIsLoadingAudio] = useState(false);
  const [isCopied, setIsCopied] = useState(false);
  const [isSnapshotting, setIsSnapshotting] = useState(false);
  
  // Audio Playback Refs
  const audioContextRef = useRef<AudioContext | null>(null);
  const audioSourceRef = useRef<AudioBufferSourceNode | null>(null);
  const bubbleRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    return () => {
      // Cleanup audio on unmount
      if (audioSourceRef.current) {
        audioSourceRef.current.stop();
      }
      if (audioContextRef.current) {
        audioContextRef.current.close();
      }
    };
  }, []);

  const handleSpeak = async () => {
    if (isSpeaking) {
      if (audioSourceRef.current) {
        audioSourceRef.current.stop();
        audioSourceRef.current = null;
      }
      setIsSpeaking(false);
      return;
    }

    setIsLoadingAudio(true);

    try {
      // 1. Generate Speech
      const base64Audio = await generateSpeech(message.content, voicePreference);
      if (!base64Audio) throw new Error("Failed to generate audio");

      // 2. Decode Base64 to ArrayBuffer
      const binaryString = window.atob(base64Audio);
      const len = binaryString.length;
      const bytes = new Uint8Array(len);
      for (let i = 0; i < len; i++) {
        bytes[i] = binaryString.charCodeAt(i);
      }
      
      // 3. Init AudioContext
      if (!audioContextRef.current) {
        // Try to specify sample rate, but fallback if browser overrides
        const AudioCtor = (window.AudioContext || (window as any).webkitAudioContext);
        audioContextRef.current = new AudioCtor();
      }
      
      // Resume context if suspended (browser policy)
      if (audioContextRef.current.state === 'suspended') {
        await audioContextRef.current.resume();
      }

      // 4. Manually Decode Raw PCM 16-bit to AudioBuffer
      // The API returns raw PCM 16-bit, 24kHz, Mono.
      // We cannot use decodeAudioData because there is no WAV header.
      
      // Ensure the buffer is aligned for Int16Array
      const int16Data = new Int16Array(bytes.buffer);
      const sampleRate = 24000; 
      const channels = 1;
      const frameCount = int16Data.length;
      
      const audioBuffer = audioContextRef.current.createBuffer(channels, frameCount, sampleRate);
      const channelData = audioBuffer.getChannelData(0); // Mono channel

      for (let i = 0; i < frameCount; i++) {
        // Convert PCM16 (-32768 to 32767) to Float32 (-1.0 to 1.0)
        channelData[i] = int16Data[i] / 32768.0;
      }

      // 5. Play
      const source = audioContextRef.current.createBufferSource();
      source.buffer = audioBuffer;
      source.connect(audioContextRef.current.destination);
      
      source.onended = () => {
        setIsSpeaking(false);
        audioSourceRef.current = null;
      };

      source.start(0);
      audioSourceRef.current = source;
      setIsSpeaking(true);

    } catch (error) {
      console.error("Audio Playback Error:", error);
      alert("Could not play audio. Please try again.");
    } finally {
      setIsLoadingAudio(false);
    }
  };

  const handleCopy = () => {
    const textToCopy = message.content;
    
    // Robust Copy Logic
    if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(textToCopy)
            .then(() => {
                setIsCopied(true);
                setTimeout(() => setIsCopied(false), 2000);
            })
            .catch(err => fallbackCopy(textToCopy));
    } else {
        fallbackCopy(textToCopy);
    }
  };

  const fallbackCopy = (text: string) => {
    try {
        const textarea = document.createElement('textarea');
        textarea.value = text;
        document.body.appendChild(textarea);
        textarea.select();
        document.execCommand('copy');
        document.body.removeChild(textarea);
        setIsCopied(true);
        setTimeout(() => setIsCopied(false), 2000);
    } catch (e) {
        console.error("Copy failed", e);
    }
  };

  const handleSnapshot = async () => {
    if (!bubbleRef.current || typeof html2canvas === 'undefined') return;
    setIsSnapshotting(true);
    
    try {
        const canvas = await html2canvas(bubbleRef.current, {
            backgroundColor: isUser ? '#f5f5f4' : '#ffffff',
            scale: 2, // High res
            ignoreElements: (element: any) => element.classList.contains('no-print'), // Hide buttons
            onclone: (clonedDoc: any) => {
                // Add Watermark to clone
                const watermark = clonedDoc.createElement('div');
                watermark.innerHTML = `
                  <div style="position: absolute; bottom: 10px; right: 20px; text-align: right; opacity: 0.7;">
                    <p style="font-family: serif; font-weight: bold; color: #78350f; font-size: 14px; margin: 0;">The People's Law AI</p>
                    <p style="font-family: sans-serif; color: #a8a29e; font-size: 10px; margin: 0;">Powered by Google Gemini</p>
                  </div>
                `;
                const bubble = clonedDoc.getElementById(`bubble-${message.id}`);
                if (bubble) {
                    bubble.style.position = 'relative';
                    bubble.style.paddingBottom = '40px'; 
                    bubble.appendChild(watermark);
                }
            }
        });

        const image = canvas.toDataURL("image/png");
        const link = document.createElement('a');
        link.href = image;
        link.download = `ThePeoplesLaw_Advice_${Date.now()}.png`;
        link.click();
    } catch (e) {
        console.error("Snapshot failed", e);
    } finally {
        setIsSnapshotting(false);
    }
  };

  // Markdown Formatter
  const formatContent = (text: string) => {
    if (!text) return null;
    
    // Split by lines to handle block elements
    return text.split('\n').map((line, index) => {
      // Headers
      if (line.startsWith('### ')) {
        return <h3 key={index} className="text-lg font-serif font-bold text-stone-800 mt-4 mb-2">{line.replace('### ', '')}</h3>;
      }
      
      // Blockquotes
      if (line.trim().startsWith('> ')) {
          return (
              <blockquote key={index} className="border-l-4 border-amber-500 pl-4 py-2 my-3 bg-stone-50 text-stone-600 italic rounded-r-lg">
                  {line.replace(/^>\s+/, '')}
              </blockquote>
          );
      }
      
      // List items (unordered)
      if (line.trim().startsWith('- ') || line.trim().startsWith('* ')) {
        const content = line.replace(/^[-*]\s+/, '');
        return (
          <li key={index} className="ml-4 list-disc text-stone-700 mb-1 pl-1 marker:text-amber-600">
             {parseInlineFormatting(content)}
          </li>
        );
      }

      // Standard Paragraph
      if (!line.trim()) return <div key={index} className="h-2"></div>;

      return <p key={index} className="mb-2 text-stone-700 leading-relaxed">{parseInlineFormatting(line)}</p>;
    });
  };

  // Helper for inline bolding
  const parseInlineFormatting = (text: string) => {
      const parts = text.split(/(\*\*.*?\*\*)/g);
      return parts.map((part, i) => {
          if (part.startsWith('**') && part.endsWith('**')) {
              return <strong key={i} className="font-bold text-stone-900">{part.slice(2, -2)}</strong>;
          }
          return part;
      });
  };

  return (
    <div className={`flex w-full mb-6 ${isUser ? 'justify-end' : 'justify-start'}`}>
      {!isUser && (
        <div className="w-8 h-8 rounded-full bg-stone-200 border border-stone-300 flex items-center justify-center mr-3 shrink-0 mt-1 shadow-sm">
           <svg className="w-5 h-5 text-stone-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M3 6l3 1m0 0l-3 9a5.002 5.002 0 006.001 0M6 7l3 9M6 7l6-2m6 2l3-1m-3 1l-3 9a5.002 5.002 0 006.001 0M18 7l3 9m-3-9l-6-2m0-2v2m0 16V5m0 16H9m3 0h3" />
           </svg>
        </div>
      )}
      
      <div 
        id={`bubble-${message.id}`}
        ref={bubbleRef}
        className={`
          max-w-[85%] md:max-w-2xl p-5 rounded-2xl shadow-sm relative group
          ${isUser 
            ? 'bg-[#fafaf9] text-stone-800 border border-stone-200' 
            : 'bg-white text-stone-800 border border-stone-200 shadow-md'
          }
        `}
      >
        {/* Header / Name */}
        {!isUser && (
           <div className="flex items-center gap-2 mb-3 border-b border-stone-100 pb-2">
               <span className="text-xs font-bold uppercase tracking-widest text-amber-800">The People's Law AI</span>
               {message.isStreaming && <span className="w-2 h-2 bg-amber-50 rounded-full animate-pulse"></span>}
           </div>
        )}

        <div className={`prose prose-stone max-w-none ${isUser ? 'text-stone-700' : ''}`}>
           {isUser ? <p>{message.content}</p> : formatContent(message.content)}
        </div>

        {/* Citations */}
        {!isUser && !message.isStreaming && message.groundingSources && message.groundingSources.length > 0 && (
          <GroundingChips sources={message.groundingSources} />
        )}

        {/* Action Bar (Only for AI messages when not streaming) */}
        {!isUser && !message.isStreaming && (
            <div className="flex items-center gap-3 mt-4 pt-3 border-t border-stone-100 no-print">
                {/* Audio Button */}
                <button 
                    onClick={handleSpeak}
                    disabled={isLoadingAudio}
                    className={`flex items-center gap-1.5 text-xs font-bold uppercase tracking-wider transition-colors ${isSpeaking ? 'text-red-500' : 'text-stone-400 hover:text-amber-700'}`}
                    title="Read Aloud"
                >
                    {isLoadingAudio ? (
                        <svg className="w-4 h-4 animate-spin" fill="none" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg>
                    ) : isSpeaking ? (
                        <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 12a9 9 0 11-18 0 9 9 0 0118 0zM9 10a1 1 0 011-1h4a1 1 0 011 1v4a1 1 0 01-1 1h-4a1 1 0 01-1-1v-4z" /></svg>
                    ) : (
                        <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15.536 8.464a5 5 0 010 7.072m2.828-9.9a9 9 0 010 12.728M5.586 15H4a1 1 0 01-1-1v-4a1 1 0 011-1h1.586l4.707-4.707C10.923 3.663 12 4.109 12 5v14c0 .891-1.077 1.337-1.707.707L5.586 15z" /></svg>
                    )}
                    {isSpeaking ? 'Stop' : 'Listen'}
                </button>

                {/* Copy Button */}
                <button 
                    onClick={handleCopy}
                    className={`flex items-center gap-1.5 text-xs font-bold uppercase tracking-wider transition-colors ${isCopied ? 'text-green-600' : 'text-stone-400 hover:text-stone-700'}`}
                    title="Copy Text"
                >
                     {isCopied ? (
                        <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" /></svg>
                     ) : (
                        <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z" /></svg>
                     )}
                     {isCopied ? 'Copied' : 'Copy'}
                </button>

                {/* Snapshot Button */}
                <button 
                    onClick={handleSnapshot}
                    disabled={isSnapshotting}
                    className="flex items-center gap-1.5 text-xs font-bold uppercase tracking-wider text-stone-400 hover:text-stone-700 transition-colors"
                    title="Save as Image"
                >
                    {isSnapshotting ? (
                       <svg className="w-4 h-4 animate-pulse" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" /></svg>
                    ) : (
                       <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 9a2 2 0 012-2h.93a2 2 0 001.664-.89l.812-1.22A2 2 0 0110.07 4h3.86a2 2 0 011.664.89l.812 1.22A2 2 0 0018.07 7H19a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V9z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 13a3 3 0 11-6 0 3 3 0 016 0z" /></svg>
                    )}
                    Snapshot
                </button>
            </div>
        )}
      </div>
    </div>
  );
};