import React, { useState } from 'react';
import { US_STATES } from '../constants';

interface PoliceEncounterGuideProps {
  onGenerateAdvice: (prompt: string) => void;
}

export const PoliceEncounterGuide: React.FC<PoliceEncounterGuideProps> = ({ onGenerateAdvice }) => {
  const [selectedState, setSelectedState] = useState('');
  const [selectedScenario, setSelectedScenario] = useState('');
  const [activeTab, setActiveTab] = useState<'scenario' | 'learn'>('scenario');

  const scenarios = [
    {
      id: 'traffic',
      title: 'Traffic Stop',
      description: 'Pulled over while driving.',
      icon: (
        <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
        </svg>
      )
    },
    {
      id: 'street',
      title: 'On the Street',
      description: 'Stopped by police while walking.',
      icon: (
        <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
        </svg>
      )
    },
    {
      id: 'home',
      title: 'At My Home',
      description: 'Police knocking at your door.',
      icon: (
        <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6" />
        </svg>
      )
    },
    {
      id: 'federal',
      title: 'Federal Agents',
      description: 'FBI or ICE at door/workplace.',
      icon: (
        <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
        </svg>
      )
    }
  ];

  const handleGenerate = () => {
    if (!selectedState || !selectedScenario) return;

    let prompt = `I am currently in ${selectedState}. I am experiencing a ${selectedScenario} encounter with law enforcement. 
    
    Please provide:
    1. A clear, respectful script of exactly what to say to assert my rights without escalating.
    2. Whether ${selectedState} is a "Stop and Identify" state and what that legally requires of me in this specific situation.
    3. My rights regarding searches, silence, and warrants (specifically Judicial vs Administrative if relevant).
    
    Emphasize being physically compliant but verbally assertive.`;

    onGenerateAdvice(prompt);
  };

  const learnTopics = [
      {
          title: "Stop & Identify Laws",
          desc: "In many states, if you are lawfully detained (Terry Stop), you MUST identify yourself. In others, you can remain anonymous unless arrested.",
          action: "Explain 'Stop and Identify' statutes. Which states have them, and what specific conditions (like loitering vs detention) trigger the requirement?"
      },
      {
          title: "Terry Stops (Detention)",
          desc: "Police can detain you briefly if they have 'Reasonable Suspicion' a crime is afoot. This is NOT an arrest, but you are not free to leave.",
          action: "Explain a 'Terry Stop' (Terry v. Ohio). What is 'Reasonable Suspicion' vs 'Hunch'? Can they search me during a stop?"
      },
      {
          title: "Lawful vs Unlawful Orders",
          desc: "You must obey 'lawful orders' (e.g., 'Step out of the car'). You can refuse unlawful ones (e.g., 'Unlock your phone'). Knowing the difference is key.",
          action: "Explain the difference between a Lawful Order and an Unlawful Order during a traffic stop. Cite Pennsylvania v. Mimms."
      },
      {
          title: "Consensual Encounters",
          desc: "If you are free to leave, it is consensual. Police often use phrasing to make you *think* you are detained when you aren't.",
          action: "Explain a 'Consensual Encounter' vs a 'Detention'. What phrases do police use to trick people into giving up rights voluntarily?"
      }
  ];

  return (
    <div className="flex flex-col h-full overflow-y-auto animate-fade-in bg-[#f5f4f1] pb-12">
      <div className="max-w-3xl mx-auto w-full p-4 md:p-12">
        
        <div className="text-center mb-10">
          <div className="inline-flex items-center justify-center p-4 bg-red-100/80 rounded-full mb-6 shadow-sm ring-1 ring-red-200">
            <svg className="w-10 h-10 text-red-800" fill="none" viewBox="0 0 24 24" stroke="currentColor">
               <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
            </svg>
          </div>
          <h1 className="text-3xl md:text-5xl font-serif font-bold text-stone-900 mb-4">Police Encounters Guide</h1>
          <p className="text-stone-600 max-w-xl mx-auto text-lg mb-2">
            Real time rights education and Information.
          </p>
          <p className="text-amber-700 font-medium text-sm bg-amber-50 inline-block px-3 py-1 rounded-full border border-amber-200">
             Always be physically compliant, even if you believe the officer is wrong. Argue in court, not on the street.
          </p>

          <div className="flex justify-center gap-4 mt-8">
              <button
                 onClick={() => setActiveTab('scenario')}
                 className={`px-6 py-2 rounded-full font-bold text-sm uppercase tracking-wide transition-all ${
                    activeTab === 'scenario' 
                    ? 'bg-stone-800 text-white shadow-md' 
                    : 'bg-white text-stone-500 border border-stone-200 hover:bg-stone-50'
                 }`}
              >
                 Scenario Generator
              </button>
              <button
                 onClick={() => setActiveTab('learn')}
                 className={`px-6 py-2 rounded-full font-bold text-sm uppercase tracking-wide transition-all ${
                    activeTab === 'learn' 
                    ? 'bg-red-700 text-white shadow-md' 
                    : 'bg-white text-stone-500 border border-stone-200 hover:bg-stone-50'
                 }`}
              >
                 Deep Dive: Laws of the Stop
              </button>
           </div>
        </div>

        {activeTab === 'scenario' && (
            <div className="bg-white rounded-2xl shadow-lg border border-stone-200 overflow-hidden animate-fade-in-up">
            <div className="p-8 space-y-8">
                
                {/* Step 1: State Selection */}
                <div>
                <label className="block text-sm font-bold uppercase tracking-wider text-stone-500 mb-3">
                    1. Select Your Location
                </label>
                <div className="relative">
                    <select 
                    value={selectedState}
                    onChange={(e) => setSelectedState(e.target.value)}
                    className="w-full p-4 pr-10 appearance-none bg-stone-50 border border-stone-300 rounded-xl text-lg font-serif text-stone-900 focus:outline-none focus:ring-2 focus:ring-amber-500 focus:border-transparent transition-all"
                    >
                    <option value="" disabled>Choose a State...</option>
                    {US_STATES.map(state => (
                        <option key={state} value={state}>{state}</option>
                    ))}
                    </select>
                    <div className="absolute inset-y-0 right-0 flex items-center px-4 pointer-events-none text-stone-500">
                    <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                    </svg>
                    </div>
                </div>
                <p className="text-xs text-stone-400 mt-2 italic">
                    Required to determine "Stop and Identify" obligations.
                </p>
                </div>

                {/* Step 2: Scenario Selection */}
                <div>
                <label className="block text-sm font-bold uppercase tracking-wider text-stone-500 mb-3">
                    2. Select Situation
                </label>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                    {scenarios.map((sc) => (
                    <button
                        key={sc.id}
                        onClick={() => setSelectedScenario(sc.id)}
                        className={`
                        p-4 rounded-xl border-2 text-left transition-all duration-200 flex flex-col gap-2 relative
                        ${selectedScenario === sc.id 
                            ? 'border-stone-800 bg-stone-800 text-white shadow-md transform scale-105' 
                            : 'border-stone-200 bg-white text-stone-600 hover:border-amber-400 hover:bg-amber-50'
                        }
                        `}
                    >
                        <div className={`${selectedScenario === sc.id ? 'text-amber-400' : 'text-stone-400'}`}>
                        {sc.icon}
                        </div>
                        <div>
                        <span className="block font-bold text-lg leading-tight mb-1">{sc.title}</span>
                        <span className={`text-xs ${selectedScenario === sc.id ? 'text-stone-400' : 'text-stone-400'}`}>{sc.description}</span>
                        </div>
                    </button>
                    ))}
                </div>
                </div>

                {/* Step 3: Action */}
                <div className="pt-4">
                <button
                    onClick={handleGenerate}
                    disabled={!selectedState || !selectedScenario}
                    className={`
                    w-full py-4 rounded-xl font-bold text-lg uppercase tracking-wider flex items-center justify-center gap-2 transition-all shadow-lg
                    ${(!selectedState || !selectedScenario)
                        ? 'bg-stone-200 text-stone-400 cursor-not-allowed'
                        : 'bg-red-700 text-white hover:bg-red-800 active:scale-95'
                    }
                    `}
                >
                    <span>Get Rights & Script</span>
                    <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
                    </svg>
                </button>
                <p className="text-center text-xs text-stone-400 mt-4">
                    This tool provides general information based on state laws. It is not a substitute for legal advice.
                </p>
                </div>

            </div>
            </div>
        )}

        {activeTab === 'learn' && (
            <div className="space-y-6 animate-fade-in-up">
                {learnTopics.map((topic, idx) => (
                    <div key={idx} className="bg-white rounded-xl border border-stone-200 p-6 shadow-sm hover:shadow-md transition-shadow">
                        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                            <div>
                                <h3 className="text-xl font-serif font-bold text-stone-900 mb-2">{topic.title}</h3>
                                <p className="text-stone-600 text-sm leading-relaxed max-w-xl">
                                    {topic.desc}
                                </p>
                            </div>
                            <button 
                                onClick={() => onGenerateAdvice(topic.action)}
                                className="px-6 py-3 bg-stone-100 text-stone-700 font-bold text-xs uppercase tracking-wide rounded-lg hover:bg-stone-900 hover:text-white transition-colors shrink-0 flex items-center justify-center gap-2"
                            >
                                Explain Concept
                                <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z" />
                                </svg>
                            </button>
                        </div>
                    </div>
                ))}
                
                <div className="bg-red-50 rounded-xl p-6 border border-red-100 mt-8">
                    <h3 className="text-red-900 font-bold mb-2">Civil Rights Violations (Section 1983)</h3>
                    <p className="text-red-800 text-sm leading-relaxed mb-4">
                        If a police officer violates your constitutional rights (like searching without Probable Cause or detaining you without Reasonable Suspicion), you may have grounds for a civil lawsuit under 42 U.S.C. § 1983. 
                    </p>
                    <button 
                        onClick={() => onGenerateAdvice("Explain Section 1983 Civil Rights Lawsuits. What is 'Qualified Immunity' and how does it make suing police difficult?")}
                        className="text-xs font-bold text-red-700 uppercase tracking-wide hover:underline"
                    >
                        Learn about Section 1983 &rarr;
                    </button>
                </div>
            </div>
        )}

      </div>
    </div>
  );
};