import React, { useState } from 'react';
import { generateQuizQuestion } from '../services/geminiService';
import { QuizQuestion, UserStats } from '../types';

interface QuizModeProps {
    userStats: UserStats;
    onQuizResult: (topic: string, isCorrect: boolean) => void;
}

export const QuizMode: React.FC<QuizModeProps> = ({ userStats, onQuizResult }) => {
  const [question, setQuestion] = useState<QuizQuestion | null>(null);
  const [loading, setLoading] = useState(false);
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [isCorrect, setIsCorrect] = useState(false);
  const [attempts, setAttempts] = useState<number>(0);

  const loadNewQuestion = async () => {
    setLoading(true);
    setSelectedOption(null);
    setIsCorrect(false);
    setAttempts(0);
    try {
      // Pass user stats to generator for adaptive difficulty
      const q = await generateQuizQuestion(userStats);
      setQuestion(q);
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  const handleOptionClick = (idx: number) => {
    if (!question) return;
    
    // If already correct, don't allow changing
    if (isCorrect) return;

    setSelectedOption(idx);
    
    if (idx === question.correctAnswerIndex) {
      setIsCorrect(true);
      // Report success for stats tracking
      onQuizResult(question.topic || "General", true);
    } else {
      setIsCorrect(false);
      setAttempts(prev => prev + 1);
      // Only report failure on first attempt to prevent spamming stats
      if (attempts === 0) {
          onQuizResult(question.topic || "General", false);
      }
    }
  };

  return (
    <div className="flex flex-col h-full overflow-y-auto animate-fade-in bg-[#f5f4f1] pb-12">
      <div className="max-w-3xl mx-auto w-full p-4 md:p-12">
        <div className="text-center mb-8">
            <div className="inline-flex items-center justify-center p-4 bg-purple-100/80 rounded-full mb-6 shadow-sm ring-1 ring-purple-200">
                <svg className="w-10 h-10 text-purple-800" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z" />
                </svg>
            </div>
            <h1 className="text-3xl md:text-5xl font-serif font-bold text-stone-900 mb-4">Professor Mode</h1>
            <p className="text-stone-600 text-lg mb-2">Test your knowledge. <span className="font-bold text-purple-900">You must answer correctly to proceed.</span></p>
            
            <div className="flex items-center justify-center gap-4 text-sm font-bold text-stone-500 uppercase tracking-widest mt-4">
                <span>Rank: <span className="text-amber-700">{userStats.level}</span></span>
                <span>•</span>
                <span>XP: <span className="text-amber-700">{userStats.xp}</span></span>
            </div>
        </div>

        {!question && !loading && (
             <div className="text-center mt-12">
                 <button 
                    onClick={loadNewQuestion}
                    className="bg-stone-900 text-white font-bold py-4 px-8 rounded-2xl shadow-lg hover:bg-stone-800 transform hover:scale-105 transition-all text-lg"
                 >
                    Start Quiz
                 </button>
             </div>
        )}

        {loading && (
            <div className="flex flex-col items-center justify-center py-20">
                <div className="w-12 h-12 border-4 border-stone-200 border-t-amber-600 rounded-full animate-spin mb-4"></div>
                <p className="text-stone-500 font-serif animate-pulse">Consulting the archives...</p>
            </div>
        )}

        {question && !loading && (
            <div className="bg-white rounded-2xl shadow-md border border-stone-200 overflow-hidden animate-fade-in-up">
                <div className="p-8 border-b border-stone-100 flex justify-between items-start gap-4">
                    <h2 className="text-xl md:text-2xl font-serif font-bold text-stone-800 leading-relaxed">
                        {question.question}
                    </h2>
                    {question.difficulty && (
                        <span className={`text-[10px] font-bold uppercase tracking-wider px-2 py-1 rounded border ${
                            question.difficulty === 'Easy' ? 'bg-green-100 text-green-700 border-green-200' :
                            question.difficulty === 'Medium' ? 'bg-amber-100 text-amber-700 border-amber-200' :
                            'bg-red-100 text-red-700 border-red-200'
                        }`}>
                            {question.difficulty}
                        </span>
                    )}
                </div>
                <div className="p-6 md:p-8 space-y-4 bg-stone-50/50">
                    {question.options.map((option, idx) => {
                        let btnClass = "w-full text-left p-4 rounded-xl border-2 transition-all duration-200 font-medium text-stone-700 ";
                        
                        // Logic for Strict Mode Styling
                        if (isCorrect && idx === question.correctAnswerIndex) {
                           // Correct Answer State
                           btnClass += "border-green-500 bg-green-50 text-green-800 shadow-sm";
                        } else if (selectedOption === idx && !isCorrect) {
                           // Wrong Selection State
                           btnClass += "border-red-500 bg-red-50 text-red-800 animate-shake";
                        } else {
                           // Default State
                           btnClass += "border-stone-200 bg-white hover:border-purple-300 hover:bg-purple-50";
                        }

                        // Disable buttons if correct answer has been found (lock state)
                        const disabled = isCorrect && idx !== question.correctAnswerIndex;

                        return (
                            <button
                                key={idx}
                                onClick={() => handleOptionClick(idx)}
                                disabled={disabled}
                                className={`${btnClass} ${disabled ? 'opacity-40 cursor-not-allowed' : ''}`}
                            >
                                <span className="inline-block w-8 font-bold opacity-50">{String.fromCharCode(65 + idx)}.</span>
                                {option}
                            </button>
                        );
                    })}
                </div>

                {/* Feedback Section */}
                {selectedOption !== null && (
                    <div className={`p-8 border-t ${isCorrect ? 'bg-green-50 border-green-100' : 'bg-red-50 border-red-100'}`}>
                        <h3 className={`text-sm font-bold uppercase tracking-wider mb-2 ${isCorrect ? 'text-green-800' : 'text-red-800'}`}>
                            {isCorrect ? "Correct!" : "Incorrect"}
                        </h3>
                        
                        {!isCorrect && (
                           <p className="text-red-700 font-medium">
                             That is not the right answer. Please try again.
                           </p>
                        )}

                        {isCorrect && (
                            <div className="animate-fade-in">
                                <p className="text-stone-800 leading-relaxed mb-6">
                                    {question.explanation}
                                </p>
                                <button 
                                    onClick={loadNewQuestion}
                                    className="bg-stone-900 text-white font-bold py-3 px-6 rounded-lg hover:bg-stone-800 transition-colors shadow-lg flex items-center gap-2"
                                >
                                    Next Question
                                    <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14 5l7 7m0 0l-7 7m7-7H3" />
                                    </svg>
                                </button>
                            </div>
                        )}
                    </div>
                )}
            </div>
        )}
      </div>
    </div>
  );
};