
import React, { useState } from 'react';
import { SCOTUS_CASES } from '../constants';
import { Bookmark } from '../types';

interface ScotusDocketProps {
  onSelectCase: (prompt: string) => void;
  bookmarks: Bookmark[];
  onToggleBookmark: (item: Bookmark) => void;
}

export const ScotusDocket: React.FC<ScotusDocketProps> = ({ onSelectCase, bookmarks, onToggleBookmark }) => {
  const [activeTab, setActiveTab] = useState<'cases' | 'guide'>('cases');
  const isBookmarked = (id: string) => bookmarks.some(b => b.id === id);

  return (
    <div className="flex flex-col h-full overflow-y-auto animate-fade-in bg-[#f5f4f1] pb-12">
      <div className="max-w-4xl mx-auto w-full p-4 md:p-12">
        
        <div className="text-center mb-10">
           <div className="inline-flex items-center justify-center p-4 bg-indigo-100/80 rounded-full mb-6 shadow-sm ring-1 ring-indigo-200">
              <svg className="w-10 h-10 text-indigo-800" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M3 6l3 1m0 0l-3 9a5.002 5.002 0 006.001 0M6 7l3 9M6 7l6-2m6 2l3-1m-3 1l-3 9a5.002 5.002 0 006.001 0M18 7l3 9m-3-9l-6-2m0-2v2m0 16V5m0 16H9m3 0h3" />
              </svg>
           </div>
           <h1 className="text-3xl md:text-5xl font-serif font-bold text-stone-900 mb-4">SCOTUS Docket</h1>
           <p className="text-stone-600 max-w-2xl mx-auto text-lg mb-8">
              Recent major rulings and upcoming cases from the Supreme Court of the United States.
           </p>

           <div className="flex justify-center gap-4 mb-8">
              <button
                 onClick={() => setActiveTab('cases')}
                 className={`px-6 py-2 rounded-full font-bold text-sm uppercase tracking-wide transition-all ${
                    activeTab === 'cases' 
                    ? 'bg-stone-800 text-white shadow-md' 
                    : 'bg-white text-stone-500 border border-stone-200 hover:bg-stone-50'
                 }`}
              >
                 Recent Rulings
              </button>
              <button
                 onClick={() => setActiveTab('guide')}
                 className={`px-6 py-2 rounded-full font-bold text-sm uppercase tracking-wide transition-all ${
                    activeTab === 'guide' 
                    ? 'bg-indigo-700 text-white shadow-md' 
                    : 'bg-white text-stone-500 border border-stone-200 hover:bg-stone-50'
                 }`}
              >
                 How the Court Works
              </button>
           </div>
        </div>

        {activeTab === 'cases' && (
            <div className="space-y-6 animate-fade-in-up">
                {SCOTUS_CASES.map((scotusCase, idx) => {
                    const saved = isBookmarked(scotusCase.name);
                    return (
                        <div key={idx} className="bg-white rounded-xl border border-stone-200 p-6 hover:shadow-lg transition-all duration-200 group relative">
                            {/* Bookmark Button */}
                            <div className="absolute top-4 right-4">
                                <button
                                    onClick={(e) => {
                                        e.stopPropagation();
                                        onToggleBookmark({
                                            id: scotusCase.name,
                                            type: 'case',
                                            title: scotusCase.name,
                                            prompt: scotusCase.prompt,
                                            subtitle: scotusCase.term,
                                            timestamp: Date.now()
                                        });
                                    }}
                                    className={`p-2 rounded-lg transition-all ${saved ? 'text-amber-600 bg-amber-100' : 'text-stone-300 hover:text-amber-500 hover:bg-amber-50'}`}
                                    title={saved ? "Remove from Briefcase" : "Save to Briefcase"}
                                >
                                    <svg className="w-5 h-5" fill={saved ? "currentColor" : "none"} viewBox="0 0 24 24" stroke="currentColor">
                                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 5a2 2 0 012-2h10a2 2 0 012 2v16l-7-3.5L5 21V5z" />
                                    </svg>
                                </button>
                            </div>

                            <span className="text-[10px] font-bold uppercase tracking-wider text-indigo-600 bg-indigo-50 px-2 py-1 rounded mb-3 inline-block">
                                Term: {scotusCase.term}
                            </span>
                            <h2 className="text-2xl font-serif font-bold text-stone-900 mb-4 pr-10">{scotusCase.name}</h2>
                            
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                                <div className="bg-stone-50 p-4 rounded-lg border border-stone-100">
                                    <h3 className="font-bold text-stone-800 text-sm mb-2 flex items-center gap-2">
                                        <svg className="w-4 h-4 text-green-600" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
                                        Holding (The Decision)
                                    </h3>
                                    <ul className="list-disc list-inside text-sm text-stone-600 space-y-1">
                                        {scotusCase.holding.map((h, i) => <li key={i}>{h}</li>)}
                                    </ul>
                                </div>
                                <div className="bg-amber-50 p-4 rounded-lg border border-amber-100">
                                    <h3 className="font-bold text-amber-900 text-sm mb-2 flex items-center gap-2">
                                        <svg className="w-4 h-4 text-amber-600" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" /></svg>
                                        Impact
                                    </h3>
                                    <ul className="list-disc list-inside text-sm text-amber-800 space-y-1">
                                        {scotusCase.impact.map((i, k) => <li key={k}>{i}</li>)}
                                    </ul>
                                </div>
                            </div>

                            <button 
                                onClick={() => onSelectCase(scotusCase.prompt)}
                                className="w-full py-3 bg-stone-900 text-white font-bold rounded-lg uppercase tracking-wider text-xs hover:bg-indigo-700 transition-colors shadow-md flex items-center justify-center gap-2"
                            >
                                Analyze Decision
                                <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14 5l7 7m0 0l-7 7m7-7H3" />
                                </svg>
                            </button>
                        </div>
                    );
                })}
            </div>
        )}

        {activeTab === 'guide' && (
            <div className="space-y-8 animate-fade-in-up">
                {/* Intro */}
                <div className="bg-indigo-50 border-l-4 border-indigo-600 p-6 rounded-r-xl">
                    <h2 className="text-xl font-bold text-indigo-900 mb-2">The "Court of Last Resort"</h2>
                    <p className="text-indigo-800 leading-relaxed text-sm">
                        The Supreme Court does not hold trials. It reviews decisions from lower courts to see if the Constitution was violated. Its word is final.
                    </p>
                </div>

                {/* Steps */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <div className="bg-white p-6 rounded-2xl border border-stone-200 shadow-sm">
                        <div className="text-4xl font-serif text-stone-200 font-bold mb-4">01</div>
                        <h3 className="font-bold text-stone-900 mb-2">Certiorari ("Cert")</h3>
                        <p className="text-sm text-stone-600 mb-4">
                            7,000 cases are sent to the court each year. They accept only about 80. 
                            Four justices must agree to hear a case ("Rule of Four").
                        </p>
                        <button 
                            onClick={() => onSelectCase("Explain the Writ of Certiorari process. How does the Supreme Court decide which cases to hear (Rule of Four)?")}
                            className="text-xs font-bold text-indigo-600 uppercase tracking-wide hover:underline"
                        >
                            Explain "Cert" &rarr;
                        </button>
                    </div>

                    <div className="bg-white p-6 rounded-2xl border border-stone-200 shadow-sm">
                        <div className="text-4xl font-serif text-stone-200 font-bold mb-4">02</div>
                        <h3 className="font-bold text-stone-900 mb-2">Oral Arguments</h3>
                        <p className="text-sm text-stone-600 mb-4">
                            Lawyers get exactly 30 minutes to argue. Justices interrupt constantly with questions. 
                            There are no witnesses or juries.
                        </p>
                        <button 
                            onClick={() => onSelectCase("Describe Supreme Court Oral Arguments. Why do Justices interrupt lawyers? What is the purpose if they've already read the briefs?")}
                            className="text-xs font-bold text-indigo-600 uppercase tracking-wide hover:underline"
                        >
                            What happens in arguments? &rarr;
                        </button>
                    </div>

                    <div className="bg-white p-6 rounded-2xl border border-stone-200 shadow-sm">
                        <div className="text-4xl font-serif text-stone-200 font-bold mb-4">03</div>
                        <h3 className="font-bold text-stone-900 mb-2">The Opinion</h3>
                        <p className="text-sm text-stone-600 mb-4">
                            Justices vote. The majority writes the "Opinion of the Court" (The Law). 
                            Those who disagree write "Dissents."
                        </p>
                        <button 
                            onClick={() => onSelectCase("Explain the difference between a Majority Opinion, a Concurrence, and a Dissenting Opinion. Why do Dissents matter if they aren't the law?")}
                            className="text-xs font-bold text-indigo-600 uppercase tracking-wide hover:underline"
                        >
                            Majority vs Dissent &rarr;
                        </button>
                    </div>
                </div>

                {/* Shadow Docket */}
                <div className="bg-stone-800 text-stone-300 p-8 rounded-2xl shadow-lg relative overflow-hidden">
                    <div className="absolute top-0 right-0 p-8 opacity-10">
                        <svg className="w-32 h-32" fill="currentColor" viewBox="0 0 24 24"><path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5"/></svg>
                    </div>
                    <div className="relative z-10">
                        <h3 className="text-xl font-bold text-white mb-2">The Shadow Docket</h3>
                        <p className="text-sm mb-4 max-w-lg leading-relaxed">
                            Emergency orders decided quickly without full arguments or signed opinions. 
                            These affect death penalty stays, abortion bans, and election rules instantly.
                        </p>
                        <button 
                            onClick={() => onSelectCase("Explain the 'Shadow Docket' (Emergency Orders) of the Supreme Court. How does it differ from the normal merits docket?")}
                            className="bg-stone-100 text-stone-900 px-6 py-2 rounded-full text-xs font-bold uppercase tracking-wider hover:bg-white transition-colors"
                        >
                            Investigate Shadow Docket
                        </button>
                    </div>
                </div>
            </div>
        )}

      </div>
    </div>
  );
};
