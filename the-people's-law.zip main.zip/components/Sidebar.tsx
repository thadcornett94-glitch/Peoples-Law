
import React, { useState, useRef } from 'react';
import { AppView, UserStats } from '../types';
import { ShareModal } from './ShareModal';

interface SidebarProps {
  onClear: () => void;
  isOpen: boolean;
  toggleSidebar: () => void;
  currentView: AppView;
  onChangeView: (view: AppView) => void;
  textSize: 'small' | 'normal' | 'large';
  onTextSizeChange: (size: 'small' | 'normal' | 'large') => void;
  userStats: UserStats;
  voicePreference: string;
  onVoiceChange: (voice: string) => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ 
  onClear, 
  isOpen, 
  toggleSidebar, 
  currentView, 
  onChangeView, 
  textSize, 
  onTextSizeChange, 
  userStats,
  voicePreference,
  onVoiceChange
}) => {
  const [showShareModal, setShowShareModal] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const shareText = "I'm using 'The People's Law' - The Civics Operating System. It's an AI Legal Assistant powered by Google Gemini. Check it out:";
  
  // TODO: CHANGE THIS URL TO YOUR DEPLOYED DOMAIN (e.g. https://your-project.vercel.app)
  const shareUrl = "https://thepeopleslaw.app";

  const handleShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: 'The People\'s Law - Civics OS',
          text: shareText,
          url: shareUrl,
        });
        return;
      } catch (err) {
        console.log("Native share failed/cancelled, opening modal.");
      }
    }
    setShowShareModal(true);
  };

  const handlePrint = () => {
    window.print();
  };

  const handleExportData = () => {
      const data = {
          userStats: localStorage.getItem('amicus_user_stats'),
          bookmarks: localStorage.getItem('amicus_bookmarks'),
          customModules: localStorage.getItem('amicus_custom_modules'),
          voicePref: localStorage.getItem('amicus_voice_pref'),
          timestamp: new Date().toISOString()
      };
      
      const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `ThePeoplesLaw_Backup_${new Date().toISOString().split('T')[0]}.json`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
  };

  const handleImportClick = () => {
      fileInputRef.current?.click();
  };

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
      const file = event.target.files?.[0];
      if (!file) return;

      const reader = new FileReader();
      reader.onload = (e) => {
          try {
              const content = e.target?.result as string;
              const data = JSON.parse(content);
              
              if (data.userStats) localStorage.setItem('amicus_user_stats', data.userStats);
              if (data.bookmarks) localStorage.setItem('amicus_bookmarks', data.bookmarks);
              if (data.customModules) localStorage.setItem('amicus_custom_modules', data.customModules);
              if (data.voicePref) localStorage.setItem('amicus_voice_pref', data.voicePref);
              
              alert("Backup restored successfully! The page will now reload.");
              window.location.reload();
          } catch (err) {
              alert("Failed to restore backup. Invalid file.");
          }
      };
      reader.readAsText(file);
  };

  const getRankColor = () => {
      switch(userStats.level) {
          case 'Partner': return 'text-purple-400';
          case 'Senior Counsel': return 'text-amber-400';
          case 'Associate': return 'text-blue-400';
          default: return 'text-stone-400';
      }
  };

  return (
    <>
      <ShareModal 
        isOpen={showShareModal} 
        onClose={() => setShowShareModal(false)} 
        url={shareUrl}
        text={shareText}
      />
      
      {/* Hidden File Input for Restore */}
      <input 
        type="file" 
        ref={fileInputRef}
        onChange={handleFileChange}
        className="hidden"
        accept=".json"
      />

      {isOpen && (
        <div 
          className="fixed inset-0 bg-stone-900/50 z-20 md:hidden backdrop-blur-sm"
          onClick={toggleSidebar}
        />
      )}

      <aside 
        className={`
          fixed md:static inset-y-0 left-0 z-30
          w-64 bg-[#1c1917] text-stone-300
          transform transition-transform duration-300 ease-in-out
          ${isOpen ? 'translate-x-0' : '-translate-x-full md:translate-x-0'}
          flex flex-col border-r border-stone-800 shadow-2xl h-full
        `}
      >
        {/* Header */}
        <div className="h-20 shrink-0 flex flex-col justify-center px-6 border-b border-stone-800 bg-[#0c0a09]">
          <div className="flex items-center gap-2 text-amber-600">
             <svg className="w-6 h-6" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <path strokeLinecap="round" strokeLinejoin="round" d="M3 6l3 1m0 0l-3 9a5.002 5.002 0 006.001 0M6 7l3 9M6 7l6-2m6 2l3-1m-3 1l-3 9a5.002 5.002 0 006.001 0M18 7l3 9m-3-9l-6-2m0-2v2m0 16V5m0 16H9m3 0h3" />
             </svg>
             <span className="text-lg font-serif font-bold tracking-wide text-stone-100">The People's Law</span>
          </div>
          <span className="text-[10px] text-stone-500 font-serif italic ml-8 -mt-0.5 tracking-wide opacity-80">Civics Operating System</span>
        </div>

        {/* Profile Card (Rank) */}
        <div className="px-4 pt-4 pb-2 shrink-0">
            <div className="bg-stone-900 rounded-lg p-3 border border-stone-800 flex items-center gap-3 shadow-inner">
                <div className={`w-8 h-8 rounded-full border-2 border-stone-700 flex items-center justify-center bg-stone-800 ${getRankColor()}`}>
                    <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                    </svg>
                </div>
                <div>
                    <span className={`block text-xs font-bold uppercase tracking-wider ${getRankColor()}`}>{userStats.level}</span>
                    <span className="text-[10px] text-stone-500 font-mono">{userStats.xp} XP</span>
                </div>
            </div>
        </div>

        {/* Nav Items - Scrollable Area */}
        <nav className="flex-1 overflow-y-auto py-2 px-4 space-y-1 custom-scrollbar min-h-0">
           
           <div className="text-xs font-semibold text-stone-500 uppercase tracking-wider mb-2 px-2 mt-2">Library</div>
           
           <NavItem icon={<ChatIcon />} label="Active Session" active={currentView === 'chat'} onClick={() => { onChangeView('chat'); if (window.innerWidth < 768) toggleSidebar(); }} />
           <NavItem icon={<DocIcon />} label="Founding Documents" active={currentView === 'founding_docs'} onClick={() => { onChangeView('founding_docs'); if (window.innerWidth < 768) toggleSidebar(); }} />
           <NavItem icon={<StarIcon />} label="Reflections & Tribute" active={currentView === 'tribute'} onClick={() => { onChangeView('tribute'); if (window.innerWidth < 768) toggleSidebar(); }} />
           <NavItem icon={<LibraryIcon />} label="Case Law Explorer" active={currentView === 'explorer'} onClick={() => { onChangeView('explorer'); if (window.innerWidth < 768) toggleSidebar(); }} />
           <NavItem icon={<ScaleIcon />} label="Common Law Guide" active={currentView === 'common_law'} onClick={() => { onChangeView('common_law'); if (window.innerWidth < 768) toggleSidebar(); }} />
           <NavItem icon={<MapIcon />} label="State Laws Index" active={currentView === 'state_laws'} onClick={() => { onChangeView('state_laws'); if (window.innerWidth < 768) toggleSidebar(); }} />
           <NavItem icon={<GlobeIcon />} label="Global Rights Atlas" active={currentView === 'global_map'} onClick={() => { onChangeView('global_map'); if (window.innerWidth < 768) toggleSidebar(); }} />
           <NavItem icon={<GavelIcon />} label="SCOTUS Docket" active={currentView === 'scotus'} onClick={() => { onChangeView('scotus'); if (window.innerWidth < 768) toggleSidebar(); }} />
           <NavItem icon={<BookIcon />} label="Legal Glossary" active={currentView === 'glossary'} onClick={() => { onChangeView('glossary'); if (window.innerWidth < 768) toggleSidebar(); }} />

           <div className="text-xs font-semibold text-stone-500 uppercase tracking-wider mb-2 mt-6 px-2">Education</div>

           <NavItem icon={<AcademicIcon />} label="Educators & Groups" active={currentView === 'educator'} onClick={() => { onChangeView('educator'); if (window.innerWidth < 768) toggleSidebar(); }} />
           <NavItem icon={<BuildingIcon />} label="Civics & Oversight" active={currentView === 'civics'} onClick={() => { onChangeView('civics'); if (window.innerWidth < 768) toggleSidebar(); }} />
           <NavItem icon={<PathIcon />} label="My Learning Path" active={currentView === 'learning'} onClick={() => { onChangeView('learning'); if (window.innerWidth < 768) toggleSidebar(); }} />

           <div className="text-xs font-semibold text-stone-500 uppercase tracking-wider mb-2 mt-6 px-2">Tools</div>

           <NavItem icon={<ScaleIcon />} label="Know Your Rights" active={currentView === 'know_rights'} onClick={() => { onChangeView('know_rights'); if (window.innerWidth < 768) toggleSidebar(); }} />
           <NavItem icon={<UsersIcon />} label="Courtroom Simulator" active={currentView === 'jury'} onClick={() => { onChangeView('jury'); if (window.innerWidth < 768) toggleSidebar(); }} />
           <NavItem icon={<FireIcon />} label="Debate Dojo" active={currentView === 'debate_dojo'} onClick={() => { onChangeView('debate_dojo'); if (window.innerWidth < 768) toggleSidebar(); }} />
           <NavItem icon={<PencilIcon />} label="Legal Document Center" active={currentView === 'drafting'} onClick={() => { onChangeView('drafting'); if (window.innerWidth < 768) toggleSidebar(); }} />
           <NavItem icon={<BriefcaseIcon />} label="My Briefcase" active={currentView === 'briefcase'} onClick={() => { onChangeView('briefcase'); if (window.innerWidth < 768) toggleSidebar(); }} />
           <NavItem icon={<BadgeIcon />} label="Police Encounters Guide" active={currentView === 'police_guide'} isAlert onClick={() => { onChangeView('police_guide'); if (window.innerWidth < 768) toggleSidebar(); }} />
           
           <div className="h-4"></div> {/* Spacer */}
        </nav>

        {/* Footer - Pinned to bottom */}
        <div className="shrink-0 border-t border-stone-800 bg-[#141211] p-4 space-y-4">
            
            {/* Settings Row */}
            <div className="grid grid-cols-2 gap-3">
                {/* Text Size */}
                <div className="space-y-1">
                    <label className="text-[10px] uppercase tracking-wider text-stone-500 font-bold">Text Size</label>
                    <div className="flex bg-stone-800 rounded-lg p-1 border border-stone-700">
                        <button onClick={() => onTextSizeChange('small')} className={`flex-1 text-xs py-1 rounded ${textSize === 'small' ? 'bg-stone-600 text-white' : 'text-stone-400 hover:text-stone-200'}`}>A</button>
                        <button onClick={() => onTextSizeChange('normal')} className={`flex-1 text-sm py-1 rounded ${textSize === 'normal' ? 'bg-stone-600 text-white' : 'text-stone-400 hover:text-stone-200'}`}>A</button>
                        <button onClick={() => onTextSizeChange('large')} className={`flex-1 text-base py-1 rounded ${textSize === 'large' ? 'bg-stone-600 text-white' : 'text-stone-400 hover:text-stone-200'}`}>A</button>
                    </div>
                </div>

                {/* Voice */}
                <div className="space-y-1">
                     <label className="text-[10px] uppercase tracking-wider text-stone-500 font-bold">Voice</label>
                     <div className="flex bg-stone-800 rounded-lg p-1 border border-stone-700">
                        <button 
                            onClick={() => onVoiceChange('Fenrir')} 
                            className={`flex-1 py-1 rounded flex items-center justify-center ${voicePreference === 'Fenrir' ? 'bg-stone-600 text-white' : 'text-stone-400 hover:text-stone-200'}`}
                            title="Male Voice"
                        >
                            <span className="text-xs font-bold">M</span>
                        </button>
                        <button 
                            onClick={() => onVoiceChange('Kore')} 
                            className={`flex-1 py-1 rounded flex items-center justify-center ${voicePreference === 'Kore' ? 'bg-stone-600 text-white' : 'text-stone-400 hover:text-stone-200'}`}
                            title="Female Voice"
                        >
                            <span className="text-xs font-bold">F</span>
                        </button>
                    </div>
                </div>
            </div>

            {/* Actions Row */}
            <div className="grid grid-cols-2 gap-3">
                 <button onClick={handleShare} className="flex items-center justify-center gap-2 bg-stone-800 hover:bg-stone-700 text-stone-300 py-2 rounded-lg text-xs font-bold uppercase tracking-wider border border-stone-700 transition-colors">
                    <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8.684 13.342C8.886 12.938 9 12.482 9 12c0-.482-.114-.938-.316-1.342m0 2.684a3 3 0 110-2.684m0 2.684l6.632 3.316m-6.632-6l6.632-3.316m0 0a3 3 0 105.367-2.684 3 3 0 00-5.367 2.684zm0 9.316a3 3 0 105.368 2.684 3 3 0 00-5.368-2.684z" /></svg>
                    Share
                 </button>
                 <button onClick={handlePrint} className="flex items-center justify-center gap-2 bg-stone-800 hover:bg-stone-700 text-stone-300 py-2 rounded-lg text-xs font-bold uppercase tracking-wider border border-stone-700 transition-colors">
                    <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 17h2a2 2 0 002-2v-4a2 2 0 00-2-2H5a2 2 0 00-2 2v4a2 2 0 002 2h2m2 4h6a2 2 0 002-2v-4a2 2 0 00-2-2H9a2 2 0 00-2 2v4a2 2 0 002 2zm8-12V5a2 2 0 00-2-2H9a2 2 0 00-2 2v4h10z" /></svg>
                    Print
                 </button>
            </div>

            {/* Backup & Restore */}
            <div className="grid grid-cols-2 gap-3 pt-1">
                 <button onClick={handleExportData} className="flex items-center justify-center gap-1.5 bg-stone-900 hover:bg-stone-800 text-stone-400 py-1.5 rounded-lg text-[10px] font-bold uppercase tracking-wider border border-stone-800 transition-colors">
                    <svg className="w-3 h-3" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" /></svg>
                    Backup Data
                 </button>
                 <button onClick={handleImportClick} className="flex items-center justify-center gap-1.5 bg-stone-900 hover:bg-stone-800 text-stone-400 py-1.5 rounded-lg text-[10px] font-bold uppercase tracking-wider border border-stone-800 transition-colors">
                    <svg className="w-3 h-3" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12" /></svg>
                    Restore
                 </button>
            </div>

            {/* Guide & Attribution */}
            <div className="pt-2 border-t border-stone-800 flex items-center justify-between">
                 <button onClick={() => { onChangeView('deployment'); if (window.innerWidth < 768) toggleSidebar(); }} className="text-[10px] text-stone-500 hover:text-amber-500 flex items-center gap-1 transition-colors">
                    <svg className="w-3 h-3" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
                    About & Safety
                 </button>
                 
                 <div className="flex flex-col items-end">
                     <span className="text-[9px] text-stone-600 font-mono">v1.0.0</span>
                     <div className="flex items-center gap-1.5 opacity-60 grayscale hover:grayscale-0 transition-all cursor-help" title="Powered by Google Gemini">
                        <span className="text-[9px] text-stone-500 font-medium">Powered by</span>
                        <svg className="w-4 h-4 text-blue-400" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M16 3L19 9L22 3M6 13L12 17L18 13M6 13L3 9L6 5L12 9L18 5L21 9L18 13L12 17L6 13Z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                            <path d="M12 17V21M6 5V3M18 5V3" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                        </svg>
                     </div>
                 </div>
            </div>

        </div>
      </aside>
    </>
  );
};

const NavItem = ({ icon, label, active, onClick, isAlert }: any) => (
  <button 
    onClick={onClick}
    className={`w-full flex items-center gap-3 px-3 py-2 text-sm font-medium rounded-lg transition-colors border ${
        active 
        ? (isAlert ? 'bg-red-900/30 text-red-100 border-red-900' : 'bg-stone-800 text-stone-100 border-stone-700') 
        : (isAlert ? 'text-red-400 hover:bg-stone-800' : 'border-transparent text-stone-400 hover:bg-stone-800 hover:text-stone-100')
    }`}
   >
      <div className={`${active ? (isAlert ? 'text-red-400' : 'text-amber-600') : (isAlert ? 'text-red-500' : 'text-stone-500')}`}>
        {icon}
      </div>
      {label}
   </button>
);

const ChatIcon = () => <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z" /></svg>;
const DocIcon = () => <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253" /></svg>;
const StarIcon = () => <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11.049 2.927c.3-.921 1.603-.921 1.902 0l1.519 4.674a1 1 0 00.95.69h4.915c.969 0 1.371 1.24.588 1.81l-3.976 2.888a1 1 0 00-.363 1.118l1.518 4.674c.3.922-.755 1.688-1.538 1.118l-3.976-2.888a1 1 0 00-1.176 0l-3.976 2.888c-.783.57-1.838-.197-1.538-1.118l1.518-4.674a1 1 0 00-.363-1.118l-3.976-2.888c-.784-.57-.38-1.81.588-1.81h4.914a1 1 0 00.951-.69l1.519-4.674z" /></svg>;
const LibraryIcon = () => <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10" /></svg>;
const MapIcon = () => <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3.055 11H5a2 2 0 012 2v1a2 2 0 002 2 2 2 0 012 2v2.945M8 3.935V5.5A2.5 2.5 0 0010.5 8h.5a2 2 0 012 2 2 2 0 104 0 2 2 0 012-2h1.064M15 20.488V18a2 2 0 012-2h3.064M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>;
const GavelIcon = () => <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 6l3 1m0 0l-3 9a5.002 5.002 0 006.001 0M6 7l3 9M6 7l6-2m6 2l3-1m-3 1l-3 9a5.002 5.002 0 006.001 0M18 7l3 9m-3-9l-6-2m0-2v2m0 16V5m0 16H9m3 0h3" /></svg>;
const BookIcon = () => <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253" /></svg>;
const AcademicIcon = () => <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z" /></svg>;
const BuildingIcon = () => <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" /></svg>;
const PathIcon = () => <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" /></svg>;
const UsersIcon = () => <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" /></svg>;
const PencilIcon = () => <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" /></svg>;
const BriefcaseIcon = () => <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 13.255A23.931 23.931 0 0112 15c-3.183 0-6.22-.62-9-1.745M16 6V4a2 2 0 00-2-2h-4a2 2 0 00-2 2v2m4 6h.01M5 20h14a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" /></svg>;
const BadgeIcon = () => <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" /></svg>;
const GlobeIcon = () => <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3.055 11H5a2 2 0 012 2v1a2 2 0 002 2 2 2 0 012 2v2.945M8 3.935V5.5A2.5 2.5 0 0010.5 8h.5a2 2 0 012 2 2 2 0 104 0 2 2 0 012-2h1.064M15 20.488V18a2 2 0 012-2h3.064M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>;
const FireIcon = () => <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17.657 18.657A8 8 0 016.343 7.343S7 9 9 10c0-2 .5-5 2.986-7C14 5 16.09 5.777 17.656 7.343A7.975 7.975 0 0120 13a7.975 7.975 0 01-2.343 5.657z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.879 16.121A3 3 0 1012.015 11L11 14H9c0 .768.293 1.536.879 2.121z" /></svg>;
const ScaleIcon = () => <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 6l3 1m0 0l-3 9a5.002 5.002 0 006.001 0M6 7l3 9M6 7l6-2m6 2l3-1m-3 1l-3 9a5.002 5.002 0 006.001 0M18 7l3 9m-3-9l-6-2m0-2v2m0 16V5m0 16H9m3 0h3" /></svg>;
