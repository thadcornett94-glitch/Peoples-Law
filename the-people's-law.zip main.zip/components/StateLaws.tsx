import React, { useState } from 'react';
import { US_STATES } from '../constants';

interface StateLawsProps {
  onSelectStateTopic: (prompt: string) => void;
}

export const StateLaws: React.FC<StateLawsProps> = ({ onSelectStateTopic }) => {
  const [searchTerm, setSearchTerm] = useState('');

  const filteredStates = US_STATES.filter(state => 
    state.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const topics = [
    { id: 'criminal', name: 'Criminal Code', icon: '⚖️', prompt: 'Explain the Criminal Code structure for [STATE] and key unique statutes. Provide a real-world analogy to explain how crimes are classified (Felony vs Misdemeanor) in this state.' },
    { id: 'family', name: 'Family Law', icon: '👨‍👩‍👧', prompt: 'Explain Family Law (divorce, custody) in [STATE]. Use an analogy to explain the standard of "Best Interests of the Child".' },
    { id: 'property', name: 'Property & Tenants', icon: '🏠', prompt: 'Explain Property Laws and Tenant Rights in [STATE]. Use an analogy to explain "Implied Warranty of Habitability".' },
    { id: 'traffic', name: 'Traffic & Vehicle', icon: '🚗', prompt: 'Explain Traffic Laws and Vehicle Code in [STATE].' },
    { id: 'constitution', name: 'State Constitution', icon: '📜', prompt: 'Analyze the State Constitution of [STATE] and its Bill of Rights. How does it differ from the Federal Constitution? Use an analogy.' }
  ];

  return (
    <div className="flex flex-col h-full overflow-y-auto animate-fade-in bg-[#f5f4f1] pb-12">
       <div className="max-w-6xl mx-auto w-full p-4 md:p-12">
          
          <div className="text-center mb-10">
             <div className="inline-flex items-center justify-center p-4 bg-orange-100/80 rounded-full mb-6 shadow-sm ring-1 ring-orange-200">
                <svg className="w-10 h-10 text-orange-800" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M3.055 11H5a2 2 0 012 2v1a2 2 0 002 2 2 2 0 012 2v2.945M8 3.935V5.5A2.5 2.5 0 0010.5 8h.5a2 2 0 012 2 2 2 0 104 0 2 2 0 012-2h1.064M15 20.488V18a2 2 0 012-2h3.064M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
             </div>
             <h1 className="text-3xl md:text-5xl font-serif font-bold text-stone-900 mb-4">50 State Laws Index</h1>
             <p className="text-stone-600 max-w-2xl mx-auto text-lg mb-8">
                Access codes, statutes, and constitutions for every U.S. State.
             </p>

             <div className="max-w-xl mx-auto relative">
                <input 
                    type="text" 
                    placeholder="Find your state..." 
                    className="w-full px-6 py-4 rounded-full border border-stone-200 shadow-lg text-lg focus:outline-none focus:ring-2 focus:ring-orange-500"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                />
                <div className="absolute right-4 top-4 text-stone-400">
                    <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                    </svg>
                </div>
             </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
             {filteredStates.map(state => (
                 <div key={state} className="bg-white rounded-xl border border-stone-200 p-6 shadow-sm hover:shadow-lg transition-all duration-200 group flex flex-col h-full">
                     <h2 className="text-2xl font-serif font-bold text-stone-800 mb-4 pb-2 border-b border-stone-100 group-hover:text-orange-800 transition-colors">
                        {state}
                     </h2>
                     <div className="space-y-2 mb-4 flex-1">
                        {topics.map(topic => (
                            <button
                                key={topic.id}
                                onClick={() => onSelectStateTopic(topic.prompt.replace('[STATE]', state))}
                                className="w-full flex items-center justify-between p-2 rounded-lg hover:bg-stone-50 transition-colors text-left text-sm font-medium text-stone-600 hover:text-stone-900 group/btn"
                            >
                                <span className="flex items-center gap-2">
                                    <span className="opacity-70 group-hover/btn:opacity-100">{topic.icon}</span> 
                                    {topic.name}
                                </span>
                                <svg className="w-4 h-4 opacity-0 group-hover/btn:opacity-100 transition-opacity text-orange-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                                </svg>
                            </button>
                        ))}
                     </div>
                     <button
                        onClick={() => onSelectStateTopic(`Provide a comprehensive legal analysis of the judicial system and constitutional framework of ${state}. Use analogies to explain its unique court structure.`)}
                        className="w-full py-2 bg-purple-50 text-purple-700 font-bold text-xs uppercase tracking-wider rounded-lg hover:bg-purple-100 transition-colors flex items-center justify-center gap-2 mt-auto"
                     >
                        Analyze Legal System
                        <svg className="w-3 h-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19.428 15.428a2 2 0 00-1.022-.547l-2.387-.477a6 6 0 00-3.86.517l-.318.158a6 6 0 01-3.86.517L6.05 15.21a2 2 0 00-1.806.547" />
                        </svg>
                     </button>
                 </div>
             ))}
          </div>

       </div>
    </div>
  );
};