
import React, { useState } from 'react';

interface TourModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAccept?: () => void; 
}

const TOUR_STEPS = [
  {
    title: "The Civics Operating System",
    description: "Welcome to The People's Law. Your personal 'Civics OS' designed to upgrade your understanding of US Rights, Constitution, and Government powered by Google's Gemini AI.",
    icon: (
        <svg className="w-12 h-12 text-amber-700" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
            <path strokeLinecap="round" strokeLinejoin="round" d="M3 6l3 1m0 0l-3 9a5.002 5.002 0 006.001 0M6 7l3 9M6 7l6-2m6 2l3-1m-3 1l-3 9a5.002 5.002 0 006.001 0M18 7l3 9m-3-9l-6-2m0-2v2m0 16V5m0 16H9m3 0h3" />
        </svg>
    )
  },
  {
    title: "The Legal Library",
    description: "Access the Sidebar to explore our extensive library. Browse Case Law, read the full Constitution, check State Laws, or look up definitions in the **Legal Glossary**.",
    icon: (
        <svg className="w-12 h-12 text-stone-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253" />
        </svg>
    )
  },
  {
    title: "Tutor Mode",
    description: "Toggle 'Tutor Mode' above the chat bar to switch The People's Law into Socratic Method. Instead of giving answers, it will ask guiding questions to help you learn.",
    icon: (
        <svg className="w-12 h-12 text-purple-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
             <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z" />
        </svg>
    )
  },
  {
    title: "Tools & Drafting",
    description: "Use the **Drafting Lab** to create legal documents or the **Police Encounters Guide** for real time rights education and Information. You can also use voice commands by clicking the microphone.",
    icon: (
        <svg className="w-12 h-12 text-blue-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" />
        </svg>
    )
  }
];

export const TourModal: React.FC<TourModalProps> = ({ isOpen, onClose }) => {
  const [currentStep, setCurrentStep] = useState(0);

  if (!isOpen) return null;

  const handleNext = () => {
    if (currentStep < TOUR_STEPS.length - 1) {
      setCurrentStep(prev => prev + 1);
    } else {
      onClose();
      // Reset for next time if opened manually
      setTimeout(() => setCurrentStep(0), 300);
    }
  };

  const handlePrev = () => {
    if (currentStep > 0) {
      setCurrentStep(prev => prev - 1);
    }
  };

  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-stone-900/60 backdrop-blur-sm animate-fade-in">
      <div className="bg-white rounded-2xl shadow-2xl max-w-md w-full border border-stone-200 overflow-hidden relative flex flex-col transform transition-all scale-100">
        
        {/* Close Button */}
        <button 
            onClick={onClose}
            className="absolute top-4 right-4 text-stone-400 hover:text-stone-600 transition-colors z-10"
        >
            <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
        </button>

        {/* Content */}
        <div className="p-8 flex flex-col items-center text-center flex-1">
            <div className="mb-6 p-4 bg-stone-50 rounded-full ring-1 ring-stone-100 shadow-sm animate-fade-in-up">
                {TOUR_STEPS[currentStep].icon}
            </div>
            
            <h2 className="text-2xl font-serif font-bold text-stone-900 mb-3 animate-fade-in">
                {TOUR_STEPS[currentStep].title}
            </h2>
            
            <div className="min-h-[5rem]">
                <p className="text-stone-600 leading-relaxed text-sm md:text-base animate-fade-in">
                    {TOUR_STEPS[currentStep].description}
                </p>
            </div>
        </div>

        {/* Footer / Controls */}
        <div className="bg-stone-50 px-6 py-4 border-t border-stone-100 flex items-center justify-between">
            
            {/* Dots */}
            <div className="flex gap-1.5">
                {TOUR_STEPS.map((_, idx) => (
                    <div 
                        key={idx} 
                        className={`w-2 h-2 rounded-full transition-all duration-300 ${idx === currentStep ? 'bg-stone-800 w-4' : 'bg-stone-300'}`}
                    />
                ))}
            </div>

            {/* Buttons */}
            <div className="flex gap-3">
                {currentStep > 0 && (
                    <button 
                        onClick={handlePrev}
                        className="px-4 py-2 text-stone-500 font-bold text-sm hover:text-stone-800 transition-colors"
                    >
                        Back
                    </button>
                )}
                <button 
                    onClick={handleNext}
                    className="px-6 py-2 bg-stone-900 text-white rounded-lg font-bold text-sm shadow-md hover:bg-amber-700 transition-all hover:-translate-y-0.5"
                >
                    {currentStep === TOUR_STEPS.length - 1 ? 'Get Started' : 'Next'}
                </button>
            </div>
        </div>

      </div>
    </div>
  );
};
