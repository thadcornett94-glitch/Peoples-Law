import React from 'react';

interface TributeProps {
  onSelectPrompt: (prompt: string) => void;
}

export const Tribute: React.FC<TributeProps> = ({ onSelectPrompt }) => {
  
  const alternatives = [
      {
          title: "Without the First Amendment",
          desc: "Imagine a United States with no freedom of speech, press, or religion.",
          icon: "🤐",
          prompt: "Write a short historical fiction scenario describing daily life in the United States if the First Amendment was never ratified. Focus on the loss of free press, ability to criticize the government, and religious freedom."
      },
      {
          title: "Without Due Process",
          desc: "Imagine a legal system without the 4th, 5th, and 6th Amendments.",
          icon: "⚖️",
          prompt: "Write a scenario describing the US Justice System if the 4th, 5th, and 6th Amendments did not exist. Focus on arbitrary arrests, lack of warrants, and no right to an attorney."
      },
      {
          title: "Without the 19th Amendment",
          desc: "Imagine a democracy where half the population has no voice.",
          icon: "🗳️",
          prompt: "Describe the state of American democracy if the 19th Amendment (Women's Suffrage) had never passed. How would society be different today?"
      }
  ];

  return (
    <div className="flex flex-col h-full overflow-y-auto animate-fade-in bg-[#f5f4f1] pb-12">
      <div className="max-w-4xl mx-auto w-full p-4 md:p-12">
        
        {/* Header */}
        <div className="text-center mb-16 relative">
           <div className="inline-flex items-center justify-center p-4 bg-stone-900 rounded-full mb-6 shadow-xl ring-4 ring-stone-200">
              <svg className="w-12 h-12 text-stone-100" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M11.049 2.927c.3-.921 1.603-.921 1.902 0l1.519 4.674a1 1 0 00.95.69h4.915c.969 0 1.371 1.24.588 1.81l-3.976 2.888a1 1 0 00-.363 1.118l1.518 4.674c.3.922-.755 1.688-1.538 1.118l-3.976-2.888a1 1 0 00-1.176 0l-3.976 2.888c-.783.57-1.838-.197-1.538-1.118l1.518-4.674a1 1 0 00-.363-1.118l-3.976-2.888c-.784-.57-.38-1.81.588-1.81h4.914a1 1 0 00.951-.69l1.519-4.674z" />
              </svg>
           </div>
           <h1 className="text-4xl md:text-6xl font-serif font-bold text-stone-900 mb-6 tracking-tight">The Cost of Liberty</h1>
           <p className="text-stone-600 max-w-2xl mx-auto text-xl leading-relaxed font-serif italic">
              "Freedom is never more than one generation away from extinction."
           </p>
        </div>

        {/* The Alternative Section */}
        <div className="mb-16">
            <div className="flex items-center gap-4 mb-8">
                 <div className="h-px bg-stone-300 flex-1"></div>
                 <h2 className="text-lg font-bold text-stone-400 uppercase tracking-widest">What If?</h2>
                 <div className="h-px bg-stone-300 flex-1"></div>
            </div>
            <p className="text-center text-stone-600 mb-8 max-w-2xl mx-auto">
                What would our nation be if not for these documents? Explore the alternative histories to understand the value of the rights we often take for granted.
            </p>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {alternatives.map((alt, idx) => (
                    <button 
                        key={idx}
                        onClick={() => onSelectPrompt(alt.prompt)}
                        className="bg-white p-6 rounded-2xl border border-stone-200 shadow-sm hover:shadow-xl hover:-translate-y-1 transition-all duration-300 group text-left"
                    >
                        <div className="text-4xl mb-4 group-hover:scale-110 transition-transform duration-300 origin-left">{alt.icon}</div>
                        <h3 className="font-serif font-bold text-xl text-stone-800 mb-2 group-hover:text-amber-800 transition-colors">{alt.title}</h3>
                        <p className="text-stone-500 text-sm leading-relaxed">{alt.desc}</p>
                        <div className="mt-4 text-xs font-bold text-amber-700 uppercase tracking-wider opacity-0 group-hover:opacity-100 transition-opacity">
                            Simulate Scenario &rarr;
                        </div>
                    </button>
                ))}
            </div>
        </div>

        {/* The Tribute Section */}
        <div className="bg-stone-900 rounded-3xl p-8 md:p-12 text-center text-stone-300 shadow-2xl relative overflow-hidden">
             <div className="absolute top-0 left-0 w-full h-full opacity-10 pointer-events-none">
                 <svg className="w-full h-full" viewBox="0 0 100 100" preserveAspectRatio="none">
                     <path d="M0 100 L100 0" stroke="white" strokeWidth="0.5" />
                     <path d="M10 100 L100 10" stroke="white" strokeWidth="0.5" />
                     <path d="M20 100 L100 20" stroke="white" strokeWidth="0.5" />
                 </svg>
             </div>
             
             <div className="relative z-10">
                 <div className="w-16 h-1 bg-amber-600 mx-auto mb-8 rounded-full"></div>
                 <h2 className="text-3xl md:text-4xl font-serif font-bold text-white mb-6">In Memoriam</h2>
                 
                 <p className="text-lg md:text-xl leading-relaxed max-w-2xl mx-auto mb-8 font-light text-stone-200">
                    The Constitution is ink on parchment. Its power comes from the blood, sweat, and sacrifice of those who defended it.
                 </p>

                 <blockquote className="text-2xl md:text-3xl font-serif italic text-amber-500 mb-10 max-w-3xl mx-auto leading-normal">
                    "And the untold numbers that gave everything for it."
                 </blockquote>

                 <button 
                    onClick={() => onSelectPrompt("Tell me about the 'untold numbers'—the soldiers, civil rights activists, and ordinary citizens—who sacrificed everything to defend the Constitution and the Bill of Rights. Provide historical examples of the cost of liberty.")}
                    className="inline-flex items-center gap-3 px-8 py-4 bg-amber-700 hover:bg-amber-600 text-white rounded-full font-bold uppercase tracking-widest text-sm transition-all shadow-lg hover:shadow-amber-900/50"
                 >
                    <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253" />
                    </svg>
                    Honor Their Story
                 </button>
             </div>
        </div>

      </div>
    </div>
  );
};