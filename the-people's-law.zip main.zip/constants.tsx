import React from 'react';
import { LearningModule, GlossaryTerm, DraftTemplate, ScotusCase, FoundingDoc, ConstitutionSection, RecordType } from './types';

// Using a functional component return type for icons to allow JSX
export const SYSTEM_INSTRUCTION = `
You are "The People's Law", an accessible, empowering, and friendly legal AI assistant.
Your core mission is to democratize legal knowledge. You believe that the law belongs to the people, and you are here to help ordinary citizens understand their rights, the Constitution, and the legal system without needing a law degree.
You are powered by Google's advanced Gemini AI models, which allow you to provide high-speed, reasoned, and accurate legal information grounded in real-time data.

**CORE PERSONA:**
- **Accessible & Plain English**: Your first priority is clarity. Avoid Latin and complex jargon unless you define it immediately. Explain things as if you were talking to a neighbor, not a judge.
- **Empowering**: Make the user feel capable. Instead of just giving answers, help them understand *why* they have that right.
- **Patient & Non-Judgmental**: Many users may be scared, confused, or frustrated. Be calm and reassuring.

**MANDATORY INSTRUCTION: THE ANALOGY RULE**
Whenever you explain a legal concept, term, statute, or court holding, you **MUST** provide a **"Real-World Analogy"** or **"Everyday Example"** to aid understanding.
- *Example:* If explaining "Jurisdiction", compare it to a referee who can only make calls on their specific field, not the one next door.
- *Example:* If explaining "Due Process", compare it to following a recipe exactly; if you skip a step, the cake (verdict) is ruined.
- **Do not** simply define the term. You must bridge the gap between abstract law and concrete reality.

Key Responsibilities:
1. **Structure & Formatting**: 
   - Use **Markdown Headers** (e.g., \`### The Fourth Amendment\`) to organize your response.
   - Use **Bullet Points** to break down rights or steps.
   - Use **Blockquotes** for Constitutional text.

2. **Thoroughness & Context**: 
   - **Constitutional Analysis**: When asked about the Constitution, quote the text, then break down exactly what it means for a regular person today.
   - **Historical Context**: Briefly mention why a law exists (e.g., "This amendment was added because the British soldiers used to...").

3. **State Law Expert**: You are an authority on the laws of all 50 US States. When discussing state-level issues (police stops, landlord/tenant), **YOU MUST ASK FOR THEIR STATE** (if not provided) to give accurate info. Cite specific codes (e.g., "California Penal Code") but explain what they mean.

4. **Police & Federal Encounters**: 
   - **CRITICAL DOCTRINE**: "Physically Compliant, Verbally Assertive."
   - Teach the user specific scripts: "I do not consent to searches," "Am I free to leave?"
   - Distinguish between Judicial Warrants (Judge signed) vs Administrative Warrants.
   - Explain the difference between "Reasonable Suspicion" (Terry Stop) and "Probable Cause" (Arrest).

5. **Privacy & Liberty (Safe Harbor)**: 
   - Researching the law is a fundamental right. Never treat a user's question as suspicious.
   - Reassure users that learning about their rights is a protected activity.

6. **Interactive Civics**: When explaining Government structure, use scenarios. "Imagine you are the President..."

Disclaimer: Always briefly imply or state you are an AI guide, not a substitute for a licensed attorney for personal legal representation.
`;

export const SOCRATIC_INSTRUCTION = `
You are "The People's Law" (Tutor Mode). 
Your goal is NOT to give the answer immediately. Your goal is to help the user derive the legal answer themselves.
- Ask guiding questions.
- If they ask "Is this illegal?", ask them "What does the law say about...?"
- Use simple analogies to guide their logic.
`;

export const QUIZ_PROMPT = `Generate a multiple-choice question about United States Law, Constitution, or Rights suitable for a general audience.
Format as JSON:
- question: string
- options: string array (4 options)
- correctAnswerIndex: number (0-3)
- explanation: string (Simple, plain English explanation with a real-world analogy)
- topic: string
- difficulty: "Easy" | "Medium" | "Hard"

Do not wrap in markdown code blocks. Just return the raw JSON.`;

export const CURRICULUM_GENERATION_PROMPT = `
You are an expert legal educator for the general public. Create a custom learning module for a student interested in: "{{GOAL}}".
Generate a JSON object representing a "LearningModule".
The structure must be exactly:
{
  "id": "custom_[random_string]",
  "title": "Module: [Title based on goal]",
  "description": "[Brief description]",
  "topics": [
    {
      "id": "topic_[random_string]",
      "title": "[Topic Title]",
      "description": "[Brief topic description]",
      "prompt": "[A specific prompt for the AI to teach this topic. Explicitly ask for analogies and real-world examples.]",
      "duration": "[e.g. 5 min read]"
    }
  ]
}
Generate 3 to 5 distinct topics that logically progress from beginner to advanced.
Return ONLY the JSON. Do not wrap in markdown code blocks.
`;

export const CONTRACT_REVIEW_PROMPT = `
You are "The People's Law". The user has provided a legal text (contract, lease, or waiver) for review.
Analyze the text below for:
1. **Red Flags**: Clauses that are unusually risky or unfavorable to the signer.
2. **Ambiguity**: Terms that are vague and could be interpreted poorly.
3. **Missing Standard Clauses**: Protections that are typically in such documents but are missing here.
4. **Plain English Summary**: Explain what the document actually commits the user to. Use analogies where helpful (e.g. "This clause is like giving them a spare key to your house forever").

Format the output clearly with Markdown headers. 
Disclaimer: Remind the user you are an AI, not a lawyer, and this is not legal advice.

TEXT TO ANALYZE:
"{{TEXT}}"
`;

export const IRAC_PROMPT = `
You are "The People's Law". Perform a formal legal analysis using the **IRAC Method** (Issue, Rule, Analysis, Conclusion) on the following fact pattern.

Structure your response exactly as follows:
### I. Issue
[Identify the legal question(s)]

### II. Rule
[State the relevant laws, statutes, or case law precedents. Provide a brief analogy for the rule.]

### III. Analysis
[Apply the rule to the specific facts provided. Discuss both sides if applicable.]

### IV. Conclusion
[State the likely legal outcome based on the analysis]

FACT PATTERN:
"{{TEXT}}"
`;

export const ARGUMENT_PROMPT = `
You are "The People's Law". For the following legal position/statement, provide the strongest arguments **FOR** (Pro) and **AGAINST** (Con).

Structure your response:
### Arguments For (Petitioner/Plaintiff)
- [Strongest Legal Argument 1]
- [Strongest Legal Argument 2]

### Arguments Against (Respondent/Defendant)
- [Strongest Legal Argument 1]
- [Strongest Legal Argument 2]

### Synthesis
[Brief summary of which side has the stronger legal standing]

POSITION TO ANALYZE:
"{{TEXT}}"
`;

export const PETITION_PROMPT = `
You are "The People's Law". Assist the user in drafting a **Petition to the Government** regarding: "{{TEXT}}".

1. **Identify the Target**: Recommend whether this should be sent to City Council, State Legislature, or Federal Congress based on the issue.
2. **Draft the Petition**: Write a formal, persuasive letter using the correct tone for a civic petition.
3. **Call to Action**: Suggest effective ways to deliver this (e.g., Public Comment, certified mail, Change.org).

Use formal but passionate language suitable for a "Redress of Grievances".
`;

export const CITATION_PROMPT = `
You are "The People's Law". Format the following case or statute information into a standard **Bluebook** citation style.
Also provide a brief 1-sentence explanation of what this source is, using an analogy if possible.

SOURCE INFO:
"{{TEXT}}"
`;

export const DEBATE_PROMPT = `
You are participating in the "Debate Dojo". 
The user will present an argument on the topic: "{{TOPIC}}".
You are the **Opposing Counsel**. Your job is to:
1. Respectfully but ruthlessly deconstruct their argument using logic, facts, and legal principles.
2. Point out logical fallacies (Ad Hominem, Strawman, etc.) and explain them with a simple analogy.
3. Present a strong counter-argument.
4. End by asking a challenging follow-up question.
`;

export const WELCOME_MESSAGE = "Welcome. I am 'The People's Law'—your Civics Operating System. The law belongs to you, and I am here to help you understand it. Whether you are facing a legal issue or just learning your rights, I'm here to help. How can I assist you?";

export const INITIAL_QUESTIONS = [
  { id: 'rights', title: 'Police Stops', subtitle: 'What do I say?', prompt: 'I got pulled over by the police. What exactly should I say to protect my rights? Please give me a script and explain "Reasonable Suspicion" using an analogy.' },
  { id: 'landlord', title: 'Landlord Issues', subtitle: 'Can they do that?', prompt: 'My landlord is entering my apartment without asking. Is that legal? What are my rights to privacy? Use an analogy to explain "Quiet Enjoyment".' },
  { id: 'const', title: 'Freedom of Speech', subtitle: 'What is protected?', prompt: 'Explain the First Amendment simply. Does it protect me from getting fired for what I post on social media? Use an analogy to explain "State Action".' },
  { id: 'basics', title: 'How Law Works', subtitle: 'A simple guide', prompt: 'Explain how the US legal system works like I am a beginner. What is the difference between Criminal and Civil law? Use a sports analogy.' },
];

export const LEGAL_FACTS = [
  "The Constitution is the shortest written Constitution of any major government in the world.",
  "The Supreme Court has no enforcement power; it relies on the Executive branch to enforce its rulings.",
  "Thomas Jefferson and John Adams both died on July 4th, 1826, exactly 50 years after the Declaration of Independence.",
  "The 27th Amendment (Congressional Pay) took over 202 years to be ratified. It was proposed in 1789 and ratified in 1992.",
  "Thurgood Marshall was the first African American Supreme Court Justice, appointed in 1967.",
  "The ' Miranda Warning' is named after Ernesto Miranda, whose conviction was overturned in 1966.",
  "There are currently 9 Justices on the Supreme Court, but there have been as few as 6 and as many as 10 in history.",
  "The Bill of Rights originally only applied to the Federal Government, not the States, until the 14th Amendment incorporated them.",
];

export const US_STATES = [
    "Alabama", "Alaska", "Arizona", "Arkansas", "California", "Colorado", "Connecticut", "Delaware", "Florida", "Georgia",
    "Hawaii", "Idaho", "Illinois", "Indiana", "Iowa", "Kansas", "Kentucky", "Louisiana", "Maine", "Maryland",
    "Massachusetts", "Michigan", "Minnesota", "Mississippi", "Missouri", "Montana", "Nebraska", "Nevada", "New Hampshire", "New Jersey",
    "New Mexico", "New York", "North Carolina", "North Dakota", "Ohio", "Oklahoma", "Oregon", "Pennsylvania", "Rhode Island", "South Carolina",
    "South Dakota", "Tennessee", "Texas", "Utah", "Vermont", "Virginia", "Washington", "West Virginia", "Wisconsin", "Wyoming"
];

export const CASE_LAW_CATEGORIES = [
  {
    id: 'civil_rights',
    title: 'Civil Rights & Liberties',
    description: 'Cases defining fundamental freedoms and equal protection.',
    cases: [
      { name: 'Brown v. Board of Education', prompt: 'Explain Brown v. Board of Education (1954). Use an analogy to explain why "Separate but Equal" is inherently unequal.', summary: 'Declared state laws establishing separate public schools for black and white students to be unconstitutional.', year: '1954' },
      { name: 'Roe v. Wade', prompt: 'Explain Roe v. Wade (1973) and the concept of a "Right to Privacy" found in the penumbras of the Constitution. Use an analogy.', summary: 'Ruled that the Constitution of the United States protects a pregnant woman\'s liberty to choose to have an abortion.', year: '1973' },
      { name: 'Obergefell v. Hodges', prompt: 'Explain Obergefell v. Hodges (2015). Use an analogy to explain the Equal Protection Clause application here.', summary: 'Ruled that the fundamental right to marry is guaranteed to same-sex couples.', year: '2015' },
      { name: 'Loving v. Virginia', prompt: 'Explain Loving v. Virginia (1967). Use an analogy to explain why state bans on interracial marriage were unconstitutional.', summary: 'Invalidated laws prohibiting interracial marriage.', year: '1967' },
      { name: 'Gideon v. Wainwright', prompt: 'Explain Gideon v. Wainwright (1963). Use an analogy to explain why a fair trial is impossible without a lawyer (like playing a sport without knowing the rules).', summary: 'Guaranteed the right to legal counsel for criminal defendants.', year: '1963' },
    ]
  },
  {
    id: 'federal_power',
    title: 'Federal Power & Structure',
    description: 'Cases determining the scope of government authority.',
    cases: [
      { name: 'Marbury v. Madison', prompt: 'Explain Marbury v. Madison (1803). Use a sports referee analogy to explain the concept of "Judicial Review".', summary: 'Established the principle of judicial review.', year: '1803' },
      { name: 'McCulloch v. Maryland', prompt: 'Explain McCulloch v. Maryland (1819). Use an analogy to explain the "Necessary and Proper" clause (Elastic Clause).', summary: 'Defined the scope of the U.S. Congress\'s legislative power and how it relates to the powers of American state legislatures.', year: '1819' },
      { name: 'Gibbons v. Ogden', prompt: 'Explain Gibbons v. Ogden (1824). Use an analogy to explain the Commerce Clause (like a river flowing between states).', summary: 'Held that the power to regulate interstate commerce was granted to Congress by the Commerce Clause.', year: '1824' },
      { name: 'Wickard v. Filburn', prompt: 'Explain Wickard v. Filburn (1942). Use an analogy to explain how growing your own wheat affects the national market price.', summary: 'Dramatically increased the regulatory power of the federal government.', year: '1942' },
    ]
  },
  {
    id: 'criminal_proc',
    title: 'Criminal Procedure',
    description: 'Rights of the accused, search and seizure.',
    cases: [
      { name: 'Miranda v. Arizona', prompt: 'Explain Miranda v. Arizona (1966). Use an analogy to explain why people need to be told their rights (like reading the rules before a game).', summary: 'Mandated that police inform suspects of their rights before custodial interrogation.', year: '1966' },
      { name: 'Mapp v. Ohio', prompt: 'Explain Mapp v. Ohio (1961) and the "Exclusionary Rule". Use the "Fruit of the Poisonous Tree" analogy.', summary: 'Established the exclusionary rule, preventing evidence collected in violation of the defendant\'s constitutional rights from being used in court.', year: '1961' },
      { name: 'Terry v. Ohio', prompt: 'Explain Terry v. Ohio (1968). Use an analogy to explain the difference between a "Pat Down" (safety) and a "Full Search" (evidence).', summary: 'Held that the Fourth Amendment is not violated when a police officer stops a suspect on the street and frisks him without probable cause to arrest.', year: '1968' },
      { name: 'Katz v. United States', prompt: 'Explain Katz v. United States (1967) and the "Reasonable Expectation of Privacy". Use the phone booth analogy.', summary: 'Extended the Fourth Amendment protection from unreasonable search and seizure to protect individuals with a "reasonable expectation of privacy".', year: '1967' },
    ]
  },
  {
    id: 'foundations',
    title: 'Foundations & History',
    description: 'The roots of American Law and early constitutional debates.',
    cases: [
        { name: 'The Federalist Papers', prompt: 'Explain the significance of the Federalist Papers, specifically No. 10 and No. 51. Use the "Ambition must be made to counteract ambition" concept with a real-world analogy.', summary: 'Essays promoting the ratification of the US Constitution.', year: '1788' },
        { name: 'Articles of Confederation', prompt: 'What were the Articles of Confederation and why did they fail? Use an analogy like "A Rope of Sand" or a "Herding Cats" to explain the weak central government.', summary: 'The first constitution of the US, replaced due to a weak central government.', year: '1781' },
        { name: 'Magna Carta', prompt: 'How did the Magna Carta influence the US Constitution? Use an analogy about limiting the power of a CEO or Coach.', summary: 'Early British document limiting the power of the king.', year: '1215' }
    ]
  },
  {
    id: 'know_your_rights',
    title: 'Know Your Rights',
    description: 'Practical legal scenarios: Police, Federal Agents, and Housing.',
    cases: [
        { name: 'Recording Police', prompt: 'Is it legal to record police officers in public? Explain the First Amendment rights involved. Use an analogy regarding "Public Space".', summary: 'The right to film public officials in public spaces.', year: 'Rights' },
        { name: 'Refusing Searches', prompt: 'When can I refuse a police search of my car or home? Use an analogy to explain the difference between "Probable Cause" and "Consent" (like inviting a vampire in).', summary: '4th Amendment protections against warrantless searches.', year: 'Rights' },
        { name: 'Federal Agents (FBI) at Door', prompt: 'I am at home and Federal Agents (FBI) are knocking. What are my rights? Use an analogy to explain the difference between an arrest warrant and a search warrant.', summary: 'Rights when interacting with the FBI or Federal investigators.', year: 'Federal' },
        { name: 'Immigration (ICE) Encounters', prompt: 'What are my rights if approached by ICE agents at home? Use an analogy to explain the difference between a judicial warrant and an administrative warrant regarding entry.', summary: 'Specific rights regarding administrative vs judicial warrants.', year: 'Federal' },
        { name: 'Landlord Entry & Privacy', prompt: 'My landlord keeps entering my apartment without notice. Explain "Quiet Enjoyment" using a hotel room analogy.', summary: 'Tenant rights regarding privacy and unauthorized entry.', year: 'Housing' },
        { name: 'Security Deposit Disputes', prompt: 'My landlord is refusing to return my security deposit. How do I write a demand letter? Use an analogy about holding money in trust.', summary: 'Recovering deposits and understanding deduction rules.', year: 'Housing' },
        { name: 'Workplace Discrimination', prompt: 'I believe I am being discriminated against at work. Explain Title VII rights using an analogy about fair play.', summary: 'Employee rights against workplace bias and harassment.', year: 'Labor' }
    ]
  },
  {
    id: 'common_law',
    title: 'Common Law Principles',
    description: 'Fundamental doctrines derived from judicial custom.',
    cases: [
        { name: 'Res Ipsa Loquitur', prompt: 'Define Res Ipsa Loquitur. Use the "Barrel falling from a window" analogy or something modern.', summary: '"The thing speaks for itself" - Negligence doctrine.', year: 'Tort' },
        { name: 'Habeas Corpus', prompt: 'Explain the Writ of Habeas Corpus ("Show me the body"). Use an analogy like demanding proof of detention.', summary: 'Protection against unlawful detention.', year: 'Right' },
        { name: 'Mens Rea', prompt: 'Explain the concept of Mens Rea ("Guilty Mind"). Use an analogy comparing an accident to an intentional act.', summary: '"Guilty Mind" - The intent behind a crime.', year: 'Crim' }
    ]
  },
  {
    id: 'statutes',
    title: 'Major Federal Statutes',
    description: 'Key Acts of Congress that shape modern life.',
    cases: [
        { name: 'Civil Rights Act of 1964', prompt: 'Explain the Civil Rights Act of 1964. Use an analogy to explain "Public Accommodations".', summary: 'Outlaws discrimination based on race, color, religion, sex, or national origin.', year: '1964' },
        { name: 'Voting Rights Act of 1965', prompt: 'Explain the Voting Rights Act of 1965. Use an analogy to explain "Preclearance" (like asking permission before changing rules).', summary: 'Prohibits racial discrimination in voting.', year: '1965' },
        { name: 'Americans with Disabilities Act', prompt: 'Explain the ADA (Americans with Disabilities Act). Use an analogy regarding "Reasonable Accommodation".', summary: 'Prohibits discrimination against individuals with disabilities.', year: '1990' },
        { name: 'Affordable Care Act', prompt: 'Explain the Affordable Care Act (Obamacare) legally. Use an analogy for the "Individual Mandate" and risk pools.', summary: 'Comprehensive healthcare reform law.', year: '2010' }
    ]
  }
];

export const LEARNING_CURRICULUM: LearningModule[] = [
    {
        id: 'module_branches',
        title: 'Module 1: The Three Branches',
        description: 'Interactive scenarios on Legislative, Executive, and Judicial powers.',
        topics: [
            { 
                id: 'topic_leg', 
                title: 'The Legislative Branch', 
                description: 'Article I: The Lawmakers.', 
                prompt: 'Act as an interactive civics tutor. Explain Article I (Congress). Use the analogy of an "Architect" designing a building to explain their role. Then, present me with a scenario: "A controversial bill about internet privacy is stuck in committee." Ask me what I think happens next, and guide me through the process.', 
                duration: '10 min' 
            },
            { 
                id: 'topic_exec', 
                title: 'The Executive Branch', 
                description: 'Article II: The Enforcers.', 
                prompt: 'Act as an interactive civics tutor. Explain Article II (The President). Use the analogy of a "General Contractor" or "Builder" who must execute the blueprints (laws). Then, give me a scenario where the President disagrees with a law Congress passed. Ask me what options the President has (Sign, Veto, Pocket Veto) to check my understanding.', 
                duration: '10 min' 
            },
            { 
                id: 'topic_jud', 
                title: 'The Judicial Branch', 
                description: 'Article III: The Interpreters.', 
                prompt: 'Act as an interactive civics tutor. Explain Article III (Supreme Court). Use the analogy of a "Building Inspector" or "Referee" who ensures the structure follows the code (Constitution). Then, quiz me: "If Congress passes a law that bans criticism of the government, what can the Supreme Court do?" Wait for my answer.', 
                duration: '10 min' 
            }
        ]
    },
    {
        id: 'module_checks',
        title: 'Module 2: Checks & Balances',
        description: 'Interactive games on how the branches limit each other.',
        topics: [
            { 
                id: 'topic_veto', 
                title: 'The Veto Game', 
                description: 'Roleplay: President vs Congress.', 
                prompt: 'Let\'s play the "Veto Game". I will act as Congress trying to pass a law (e.g., "Mandatory Pizza Fridays"). You act as the President. Explain your reasoning for vetoing or signing it based on the Constitution. Use a "Rock, Paper, Scissors" analogy for checks and balances.', 
                duration: '12 min' 
            },
            { 
                id: 'topic_appoint', 
                title: 'Scenario: Supreme Court Nomination', 
                description: 'Advice & Consent Simulation.', 
                prompt: 'Run a simulation: A Supreme Court Justice has retired. You are the President. I am the Senate. You must nominate a candidate and explain why. Then, I (the user) will ask you questions about the nominee. Explain the "Advice and Consent" process using a job interview analogy.', 
                duration: '15 min' 
            },
            { 
                id: 'topic_impeach', 
                title: 'Impeachment Process', 
                description: 'The ultimate check on power.', 
                prompt: 'Explain Impeachment using a "Grand Jury vs Trial Jury" analogy. Explain that the House "Indicts" (Impeaches) and the Senate "Tries" (Convicts). Then, give me a quiz question: "If the House impeaches the President, is he immediately removed from office?" Wait for my answer.', 
                duration: '15 min' 
            }
        ]
    },
    {
        id: 'module_foundations',
        title: 'Module 3: Foundations of US Law',
        description: 'Understand the bedrock of the legal system.',
        topics: [
            { id: 'topic_1_1', title: 'The Constitution', description: 'The Supreme Law of the Land.', prompt: 'Explain the structure and purpose of the US Constitution. Use the "Blueprint of a House" analogy.', duration: '10 min' },
            { id: 'topic_1_3', title: 'Federalism', description: 'State vs. Federal Power.', prompt: 'Explain Federalism and the 10th Amendment using the "Layer Cake vs Marble Cake" analogy.', duration: '8 min' },
            { id: 'topic_1_4', title: 'Sources of Law', description: 'Hierarchy of authority.', prompt: 'Explain the difference between Constitutional Law, Statutory Law, and Case Law using a "Pyramid" analogy.', duration: '5 min' }
        ]
    },
    {
        id: 'module_liberties',
        title: 'Module 4: Civil Liberties',
        description: 'Your rights as a citizen.',
        topics: [
            { id: 'topic_2_1', title: 'Freedom of Speech', description: 'The First Amendment.', prompt: 'Explain the First Amendment and its limitations (e.g. incitement). Use the "Shouting Fire in a Theater" analogy.', duration: '12 min' },
            { id: 'topic_2_2', title: 'Search & Seizure', description: 'The Fourth Amendment.', prompt: 'Explain the Fourth Amendment and what constitutes a reasonable search. Use the "Castle Doctrine" analogy.', duration: '15 min' },
            { id: 'topic_2_3', title: 'Due Process', description: 'The Fifth & Fourteenth Amendments.', prompt: 'Explain Procedural vs. Substantive Due Process using a "Recipe" analogy.', duration: '10 min' }
        ]
    },
    {
        id: 'module_police_rights',
        title: 'Module 5: Police & The Citizen',
        description: 'Understanding stops, detentions, and interactions.',
        topics: [
            { id: 'topic_police_1', title: 'The 3 Levels of Interaction', description: 'Consensual, Detention, Arrest.', prompt: 'Explain the three levels of police-citizen interaction: Consensual Encounter, Investigative Detention (Terry Stop), and Arrest. Use a "Traffic Light" analogy (Green, Yellow, Red).', duration: '12 min' },
            { id: 'topic_police_2', title: 'Terry Stops (Stop & Frisk)', description: 'Terry v. Ohio and Reasonable Suspicion.', prompt: 'Explain the case Terry v. Ohio. What is "Reasonable Articulable Suspicion"? Use a "Hunch vs Evidence" analogy.', duration: '10 min' },
            { id: 'topic_police_3', title: 'Traffic Stops', description: 'Driver and Passenger Rights.', prompt: 'Explain rights during a traffic stop. Can police order you out of the car? Use a "Temporary Time-Out" analogy for the legal status of the stop.', duration: '10 min' }
        ]
    }
];

export const GLOSSARY_TERMS: GlossaryTerm[] = [
    { id: '1', term: 'Acquittal', definition: 'A judgment that a person is not guilty of the crime with which the person has been charged.', category: 'Procedure', prompt: 'Explain "Acquittal" in plain English with a real-world analogy (like being cleared of charges by a principal).' },
    { id: '2', term: 'Affidavit', definition: 'A written statement confirmed by oath or affirmation, for use as evidence in court.', category: 'Procedure', prompt: 'Define Affidavit in plain English with a real-world analogy. When is it used?' },
    { id: '3', term: 'Amicus Curiae', definition: '"Friend of the court." A person or group who is not a party to a lawsuit, but has a strong interest in the matter.', category: 'Procedure', prompt: 'Explain "Amicus Curiae" in plain English. Use a real-world analogy (like a fan writing a letter to a referee).' },
    { id: '4', term: 'Arraignment', definition: 'The first court appearance where the defendant is formally charged and enters a plea.', category: 'Procedure', prompt: 'Explain Arraignment in plain English with a real-world analogy (like orientation day).' },
    { id: '5', term: 'Bail', definition: 'Money paid to the court to ensure that an accused person returns for trial.', category: 'Procedure', prompt: 'Explain Bail in plain English with a real-world analogy (like a security deposit).' },
    { id: '6', term: 'Bench Trial', definition: 'A trial held before a judge without a jury.', category: 'Procedure', prompt: 'Explain a Bench Trial in plain English with a real-world analogy (like a referee making the call without a replay booth).' },
    { id: '7', term: 'Brief', definition: 'A written document explaining one side\'s legal argument.', category: 'Procedure', prompt: 'Explain a Legal Brief in plain English with a real-world analogy (like a book report).' },
    { id: '8', term: 'Burden of Proof', definition: 'The obligation to prove one\'s assertion. In criminal cases, it is "Beyond a Reasonable Doubt".', category: 'Concept', prompt: 'Explain "Burden of Proof" in plain English using a real-world analogy (like a scale or a sports replay).' },
    { id: '9', term: 'Certiorari', definition: 'A writ or order by which a higher court reviews a decision of a lower court.', category: 'Procedure', prompt: 'Explain Writ of Certiorari in plain English with a real-world analogy (like a manager reviewing a cashier\'s decision).' },
    { id: '10', term: 'Chain of Custody', definition: 'The documented and unbroken transfer of evidence.', category: 'Procedure', prompt: 'Explain Chain of Custody in plain English with a real-world analogy (like package tracking).' },
    { id: '11', term: 'Class Action', definition: 'A lawsuit filed by a group of people with the same grievance.', category: 'Procedure', prompt: 'Explain Class Action lawsuits in plain English with a real-world analogy (like a group project).' },
    { id: '12', term: 'Closing Argument', definition: 'The final speech by a lawyer to the jury.', category: 'Procedure', prompt: 'Explain Closing Arguments in plain English with a real-world analogy (like a sales pitch).' },
    { id: '13', term: 'Common Law', definition: 'Law developed by judges through decisions rather than statutes.', category: 'Source of Law', prompt: 'Explain Common Law vs Civil Law in plain English with a real-world analogy (Building blocks vs Instruction manual).' },
    { id: '14', term: 'Complaint', definition: 'The initial document filed to start a civil lawsuit.', category: 'Procedure', prompt: 'Explain a Legal Complaint in plain English with a real-world analogy (like a formal grievance).' },
    { id: '15', term: 'Damages', definition: 'Money awarded to a plaintiff to compensate for injury or loss.', category: 'Concept', prompt: 'Explain Legal Damages in plain English with a real-world analogy (like a repair bill).' },
    { id: '16', term: 'Defamation', definition: 'The action of damaging the good reputation of someone; slander (spoken) or libel (written).', category: 'Concept', prompt: 'Explain Defamation (Libel vs Slander) in plain English with a real-world analogy.' },
    { id: '17', term: 'Deposition', definition: 'Sworn testimony given out of court before a trial begins.', category: 'Procedure', prompt: 'Explain a Deposition in plain English with a real-world analogy (like a pre-game interview).' },
    { id: '18', term: 'Discovery', definition: 'The process where lawyers exchange evidence before trial.', category: 'Procedure', prompt: 'Explain Legal Discovery in plain English with a real-world analogy (like showing your cards).' },
    { id: '19', term: 'Docket', definition: 'The official schedule of proceedings in a lawsuit or court.', category: 'Procedure', prompt: 'Explain a Court Docket in plain English with a real-world analogy (like a calendar).' },
    { id: '20', term: 'Double Jeopardy', definition: 'The prosecution of a person twice for the same offense.', category: 'Concept', prompt: 'Explain Double Jeopardy in plain English with a real-world analogy (like replay reviews in sports).' },
    { id: '21', term: 'Due Process', definition: 'Fair treatment through the normal judicial system.', category: 'Concept', prompt: 'Explain Due Process in plain English with a real-world analogy (like following a recipe exactly).' },
    { id: '22', term: 'Eminent Domain', definition: 'The right of a government to expropriate private property for public use.', category: 'Concept', prompt: 'Explain Eminent Domain in plain English with a real-world analogy.' },
    { id: '23', term: 'Ex Post Facto', definition: 'A law that makes illegal an act that was legal when committed.', category: 'Concept', prompt: 'Explain "Ex Post Facto" laws in plain English with a real-world analogy (like changing the rules of a game after it has been played).' },
    { id: '24', term: 'Felony', definition: 'A serious crime usually punishable by imprisonment for more than one year.', category: 'Concept', prompt: 'Explain the difference between Felony and Misdemeanor in plain English with a real-world analogy.' },
    { id: '25', term: 'Grand Jury', definition: 'A jury selected to examine the validity of an accusation before trial.', category: 'Procedure', prompt: 'Explain the purpose of a Grand Jury in plain English with a real-world analogy (like a screening committee).' },
    { id: '26', term: 'Habeas Corpus', definition: 'A writ requiring a person under arrest to be brought before a judge.', category: 'Concept', prompt: 'Explain Habeas Corpus in plain English with a real-world analogy (like demanding proof of detention).' },
    { id: '27', term: 'Hearsay', definition: 'Information received from other people that one cannot adequately substantiate.', category: 'Procedure', prompt: 'Explain Hearsay evidence in plain English with a real-world analogy (like the game of Telephone).' },
    { id: '28', term: 'Hung Jury', definition: 'A jury that cannot agree upon a verdict.', category: 'Procedure', prompt: 'Explain a Hung Jury in plain English with a real-world analogy (like a stalemate).' },
    { id: '29', term: 'Indictment', definition: 'A formal charge or accusation of a serious crime.', category: 'Procedure', prompt: 'Define Indictment in plain English with a real-world analogy.' },
    { id: '30', term: 'Injunction', definition: 'A judicial order that restrains a person from beginning or continuing an action.', category: 'Procedure', prompt: 'Explain a Court Injunction in plain English with a real-world analogy (like a referee blowing the whistle to stop play).' },
    { id: '31', term: 'Jurisdiction', definition: 'The official power to make legal decisions and judgments.', category: 'Concept', prompt: 'Explain Legal Jurisdiction in plain English with a real-world analogy (like a referee\'s authority on their specific field).' },
    { id: '32', term: 'Mistrial', definition: 'A trial rendered invalid through an error in proceedings.', category: 'Procedure', prompt: 'Explain a Mistrial in plain English with a real-world analogy (like a do-over).' },
    { id: '33', term: 'Motion', definition: 'A formal request made to a judge for an order or judgment.', category: 'Procedure', prompt: 'Explain a Legal Motion in plain English with a real-world analogy (like raising your hand to ask the teacher).' },
    { id: '34', term: 'Parole', definition: 'The release of a prisoner temporarily or permanently before the completion of a sentence.', category: 'Concept', prompt: 'Explain Parole in plain English with a real-world analogy (like a probationary period).' },
    { id: '35', term: 'Perjury', definition: 'The offense of willfully telling an untruth in a court after having taken an oath.', category: 'Procedure', prompt: 'Explain Perjury in plain English with a real-world analogy.' },
    { id: '36', term: 'Plaintiff', definition: 'A person who brings a case against another in a court of law.', category: 'People', prompt: 'Explain Plaintiff vs Defendant in plain English with a real-world analogy.' },
    { id: '37', term: 'Plea Bargain', definition: 'An agreement where the defendant pleads guilty to a lesser charge.', category: 'Procedure', prompt: 'Explain a Plea Bargain in plain English with a real-world analogy (like settling a debt for less).' },
    { id: '38', term: 'Precedent', definition: 'An earlier event or action that is regarded as an example or guide.', category: 'Concept', prompt: 'Explain Legal Precedent in plain English with a real-world analogy (like "setting the bar").' },
    { id: '39', term: 'Probation', definition: 'The release of an offender from detention, subject to a period of good behavior under supervision.', category: 'Concept', prompt: 'Explain Probation in plain English with a real-world analogy (like being on a short leash).' },
    { id: '40', term: 'Pro Bono', definition: 'Legal work undertaken voluntarily and without payment.', category: 'Concept', prompt: 'Explain Pro Bono work in plain English with a real-world analogy.' },
    { id: '41', term: 'Prosecutor', definition: 'A lawyer who conducts the case against a defendant in a criminal court.', category: 'People', prompt: 'Explain the role of a Prosecutor in plain English with a real-world analogy (like playing Offense).' },
    { id: '42', term: 'Public Defender', definition: 'A lawyer employed at public expense in a criminal trial to represent a defendant who cannot afford legal assistance.', category: 'People', prompt: 'Explain the role of a Public Defender in plain English with a real-world analogy (like a free coach).' },
    { id: '43', term: 'Recusal', definition: 'To disqualify oneself as a judge in a particular case to avoid a conflict of interest.', category: 'Procedure', prompt: 'Explain Judicial Recusal in plain English with a real-world analogy (like a referee stepping out because their child is playing).' },
    { id: '44', term: 'Settlement', definition: 'An official agreement intended to resolve a dispute or conflict.', category: 'Procedure', prompt: 'Explain a Legal Settlement in plain English with a real-world analogy (like meeting in the middle).' },
    { id: '45', term: 'Standing', definition: 'The capacity of a party to bring suit in court. To have standing, one must have suffered an actual injury.', category: 'Concept', prompt: 'Explain Legal Standing in plain English with a real-world analogy (like "no harm, no foul").' },
    { id: '46', term: 'Statute', definition: 'A written law passed by a legislative body.', category: 'Source of Law', prompt: 'Explain what a Statute is in plain English with a real-world analogy.' },
    { id: '47', term: 'Subpoena', definition: 'A writ ordering a person to attend a court.', category: 'Procedure', prompt: 'Explain a Subpoena in plain English with a real-world analogy (like a mandatory invitation).' },
    { id: '48', term: 'Tort', definition: 'A wrongful act leading to civil legal liability.', category: 'Concept', prompt: 'What is a Tort? Explain in plain English with a real-world analogy (like accidentally breaking a neighbor\'s window).' },
    { id: '49', term: 'Verdict', definition: 'The findings of a jury on issues of fact submitted to it for decision.', category: 'Procedure', prompt: 'Explain a Legal Verdict in plain English with a real-world analogy (like the final score).' },
    { id: '50', term: 'Voir Dire', definition: 'A preliminary examination of a witness or a juror by a judge or counsel.', category: 'Procedure', prompt: 'Explain Voir Dire in plain English with a real-world analogy (like job interviews for jurors).' },
    { id: '51', term: 'Warrant', definition: 'A document issued by a legal or government official authorizing the police to make an arrest or search premises.', category: 'Procedure', prompt: 'When is a Warrant required? Explain in plain English with a real-world analogy (like a permission slip).' },
    { id: '52', term: 'Strict Scrutiny', definition: 'The highest standard of review used by courts to determine the constitutionality of certain laws.', category: 'Concept', prompt: 'Explain Strict Scrutiny in plain English using a real-world analogy (like a very strict security checkpoint).' },
    { id: '53', term: 'Prior Restraint', definition: 'Government action that prohibits speech or other expression before the speech happens.', category: 'Concept', prompt: 'Explain Prior Restraint (Censorship) in plain English using a real-world analogy (like stopping a movie from being released).' },
    { id: '54', term: 'Establishment Clause', definition: 'The First Amendment clause prohibiting the government from establishing an official religion.', category: 'Concept', prompt: 'Explain the Establishment Clause in plain English using a real-world analogy.' },
    { id: '55', term: 'Gerrymandering', definition: 'Manipulating the boundaries of an electoral constituency so as to favor one party or class.', category: 'Concept', prompt: 'Explain Gerrymandering in plain English using a real-world analogy (like picking your own opponents in a game).' },
    { id: '56', term: 'Checks and Balances', definition: 'A system that allows each branch of a government to amend or veto acts of another branch.', category: 'Concept', prompt: 'Explain Checks and Balances in plain English using a real-world analogy (like Rock, Paper, Scissors).' },
    // NEW TERMS FOR POLICE & RIGHTS
    { id: '57', term: 'Terry Stop', definition: 'A brief, temporary detention by police based on "Reasonable Suspicion" of criminal activity.', category: 'Procedure', prompt: 'Explain a "Terry Stop" (Stop and Frisk). What is the difference between this and an Arrest? Use the analogy of a "Time Out" vs "Detention".' },
    { id: '58', term: 'Reasonable Suspicion', definition: 'A legal standard of proof that is less than probable cause, but more than an "inchoate and unparticularized suspicion or hunch".', category: 'Concept', prompt: 'Explain "Reasonable Suspicion". How is it different from a "Hunch"? Use a real-world analogy.' },
    { id: '59', term: 'Probable Cause', definition: 'Reasonable grounds (for making a search, pressing a charge, etc.).', category: 'Concept', prompt: 'Explain "Probable Cause". How is it different from Reasonable Suspicion? Use the analogy of "Smoke vs Fire".' },
    { id: '60', term: 'Stop and Identify', definition: 'Statutes in some states that authorize police to lawfully order people they have detained to identify themselves.', category: 'Concept', prompt: 'Explain "Stop and Identify" laws. Do I always have to show ID? Explain the difference between being detained and being free to go.' },
    { id: '61', term: 'Qualified Immunity', definition: 'A legal doctrine that protects government officials from being held personally liable for constitutional violations.', category: 'Concept', prompt: 'Explain "Qualified Immunity" for police officers in plain English with a real-world analogy.' },
    { id: '62', term: 'Section 1983', definition: 'A federal statute that allows people to sue the government for civil rights violations.', category: 'Source of Law', prompt: 'Explain "Section 1983" lawsuits (Civil Rights Violations). How does a citizen sue for rights infringement?' },
    { id: '63', term: 'Color of Law', definition: 'The appearance of legal authority. Acts done under "color of law" are done by public officials acting in their official capacity.', category: 'Concept', prompt: 'Explain acting under "Color of Law" in plain English.' },
    { id: '64', term: 'Exclusionary Rule', definition: 'A law that prohibits the use of illegally obtained evidence in a criminal trial.', category: 'Concept', prompt: 'Explain the Exclusionary Rule (Fruit of the Poisonous Tree) in plain English using a real-world analogy.' }
];

export const DRAFTING_TEMPLATES: DraftTemplate[] = [
    { id: 'foia', title: 'FOIA Request', description: 'Request public records from a government agency.', difficulty: 'Beginner', prompt: 'Draft a Freedom of Information Act (FOIA) request letter for [INSERT AGENCY] regarding [INSERT TOPIC].' },
    { id: 'demand', title: 'Security Deposit Demand', description: 'Demand return of deposit from a landlord.', difficulty: 'Beginner', prompt: 'Draft a formal demand letter to a landlord for the return of a security deposit under [STATE] law.' },
    { id: 'contract', title: 'Simple Service Contract', description: 'Agreement between freelancer and client.', difficulty: 'Intermediate', prompt: 'Draft a simple service agreement contract between a freelancer and a client.' },
    { id: 'cease', title: 'Cease and Desist', description: 'Stop harassment or infringement.', difficulty: 'Intermediate', prompt: 'Draft a Cease and Desist letter regarding harassment/stalking.' },
    { id: 'will', title: 'Simple Will', description: 'Basic last will and testament structure.', difficulty: 'Intermediate', prompt: 'Draft a template for a simple Last Will and Testament.' },
];

export const PUBLIC_RECORD_TYPES: RecordType[] = [
    { id: 'court', title: 'Court Records', description: 'Look up civil, criminal, and bankruptcy case dockets.', prompt: 'How do I search for court records and case dockets online? Explain PACER for federal cases and general state court portals.' },
    { id: 'property', title: 'Property Deeds & Liens', description: 'Find ownership history, deeds, and recorded liens.', prompt: 'How do I do a public property record search for deeds and liens? Explain the role of the County Recorder or Clerk.' },
    { id: 'business', title: 'Business Entity Search', description: 'Verify LLCs, Corporations, and registered agents.', prompt: 'How do I look up a business entity or LLC? Explain the Secretary of State business search tool.' },
    { id: 'inmate', title: 'Inmate & Arrest Records', description: 'Locate incarcerated individuals or arrest logs.', prompt: 'How do I search for inmate locations or recent arrest records? Explain BOP.gov and county sheriff databases.' },
    { id: 'vital', title: 'Vital Records', description: 'Birth, death, marriage, and divorce certificates.', prompt: 'How do I request public vital records like birth, death, or marriage certificates?' },
    { id: 'sex_offender', title: 'Sex Offender Registry', description: 'Check local registries for safety.', prompt: 'How do I check the National Sex Offender Public Website (NSOPW) and state registries?' }
];

export const SCOTUS_CASES: ScotusCase[] = [
    { 
        term: '2023-2024', 
        name: 'Loper Bright Enterprises v. Raimondo', 
        holding: ['Overturned Chevron Deference.', 'Ended judicial deference to federal agency interpretations of ambiguous statutes.'], 
        impact: ['Courts must now exercise independent judgment.', 'Significantly reduces the regulatory power of federal agencies.'], 
        prompt: 'Explain Loper Bright Enterprises v. Raimondo and the end of Chevron Deference. Use an analogy to explain the shift in power.' 
    },
    { 
        term: '2023-2024', 
        name: 'Trump v. United States', 
        holding: ['Established absolute immunity for core constitutional acts of the President.', 'Granted presumptive immunity for all official acts.'], 
        impact: ['Fundamentally alters the separation of powers.', 'Complicates criminal prosecutions of former Presidents.'], 
        prompt: 'Explain the Supreme Court ruling in Trump v. United States regarding Presidential Immunity. Use an analogy.' 
    },
    { 
        term: '2021-2022', 
        name: 'Dobbs v. Jackson', 
        holding: ['Overturned Roe v. Wade (1973) and Planned Parenthood v. Casey (1992).', 'Held that the Constitution does not confer a right to abortion.'], 
        impact: ['Returned the authority to regulate or ban abortion to individual states.', 'Ended nearly 50 years of federal constitutional protection for abortion access.'], 
        prompt: 'Analyze the legal reasoning in Dobbs v. Jackson Women\'s Health Organization. Use an analogy to explain the concept of returning power to the states.' 
    },
    { 
        term: '2021-2022', 
        name: 'NYSRPA v. Bruen', 
        holding: ['Struck down New York\'s "proper cause" requirement for concealed carry.', 'Established that gun laws must be consistent with the nation\'s historical tradition.'], 
        impact: ['Invalidated "may-issue" licensing regimes in multiple states.', 'Shifted the standard for evaluating Second Amendment challenges.'], 
        prompt: 'Explain NYSRPA v. Bruen and the new standard for Second Amendment cases. Use an analogy for the "History and Tradition" test.' 
    },
];

export const FOUNDING_DOCUMENTS: FoundingDoc[] = [
    {
        id: 'magna_carta',
        title: 'Magna Carta',
        year: '1215',
        description: 'The "Great Charter" agreed to by King John of England. It established the principle that everyone is subject to the law, even the king, and guarantees the rights of individuals, the right to justice, and the right to a fair trial.',
        facts: ['Foundation of the Fifth Amendment (Due Process).', 'Originally protected rights of rebellious Barons.', 'Cited by the Supreme Court over 170 times.'],
        prompt: 'Analyze the Magna Carta (1215). Explain its specific influence on the US Constitution, particularly regarding Due Process, Trial by Jury, and Habeas Corpus. Use an analogy to explain limiting the King\'s power.'
    },
    {
        id: 'mayflower',
        title: 'Mayflower Compact',
        year: '1620',
        description: 'The first governing document of Plymouth Colony. It was written by the male passengers of the Mayflower, consisting of separatist Puritans, adventurers, and tradesmen.',
        facts: ['Signed aboard the ship Mayflower.', 'Created a "Civil Body Politic".', 'Early model of consensual government by majority rule.'],
        prompt: 'Explain the significance of the Mayflower Compact as an early example of social contract theory and self-government in the American colonies. Use an analogy.'
    },
    {
        id: 'spirit_laws',
        title: 'The Spirit of Laws',
        year: '1748',
        description: 'A treatise on political theory by Baron de Montesquieu. It is the primary source of the doctrine of "Separation of Powers" adopted by the US Founders.',
        facts: ['Advocated for Legislative, Executive, and Judicial branches.', 'Heavily influenced James Madison.', 'Banned by the Catholic Church in 1751.'],
        prompt: 'Analyze Montesquieu\'s "The Spirit of Laws". How did his theory of Separation of Powers directly shape Articles I, II, and III of the US Constitution? Use a "Rock Paper Scissors" or similar analogy.'
    },
    {
        id: 'blackstone',
        title: 'Blackstone\'s Commentaries',
        year: '1765',
        description: 'Commentaries on the Laws of England. The influential treatise on English common law that served as the foundational textbook for American lawyers for a century.',
        facts: ['Defined rights of persons (Absolute vs Relative).', 'Basis for US Property and Tort law.', 'Read by Lincoln, Marshall, and Jefferson.'],
        prompt: 'Explain the influence of William Blackstone\'s Commentaries on the American legal system, specifically regarding Property Rights and Self-Defense.'
    },
    {
        id: 'common_sense',
        title: 'Common Sense',
        year: '1776',
        description: 'A pamphlet written by Thomas Paine advocating independence from Great Britain to people in the Thirteen Colonies.',
        facts: ['Sold 500,000 copies in first year.', 'Written in plain English for common people.', 'Argued that monarchy was a "sin".'],
        prompt: 'Analyze Thomas Paine\'s "Common Sense". How did it shift public opinion towards independence and reject the "Divine Right of Kings"? Use an analogy.'
    },
    {
        id: 'declaration',
        title: 'Declaration of Independence',
        year: '1776',
        description: 'The formal statement written by Thomas Jefferson declaring the freedom of the thirteen American colonies from Great Britain.',
        facts: ['Adopted July 4, 1776.', 'Lists grievances against King George III.', 'Asserts "unalienable Rights" of Life, Liberty, and the pursuit of Happiness.'],
        prompt: 'Analyze the Declaration of Independence, its philosophical roots (John Locke), and the list of grievances. Use an analogy to explain the break-up with Britain.'
    },
    {
        id: 'articles_confed',
        title: 'Articles of Confederation',
        year: '1781',
        description: 'The original constitution of the US, ratified in 1781, which was replaced by the US Constitution in 1789.',
        facts: ['Created a weak central government.', 'No power to tax or regulate trade.', 'Its failure led to the Constitutional Convention.'],
        prompt: 'Analyze the Articles of Confederation. Why did it fail? Compare its weakness regarding taxation and commerce to the current Constitution using a "Rope of Sand" analogy.'
    },
    {
        id: 'constitution',
        title: 'U.S. Constitution',
        year: '1787',
        description: 'The supreme law of the United States. It delineates the national frame of government.',
        facts: ['Written in 1787, ratified in 1788.', 'Contains 7 Articles and 27 Amendments.', 'Shortest written Constitution still in use.'],
        prompt: 'Analyze the US Constitution, its structure (Articles I-VII), and its core principles of Separation of Powers and Federalism. Use the "Blueprint" analogy.'
    },
    {
        id: 'federalist',
        title: 'The Federalist Papers',
        year: '1788',
        description: 'A collection of 85 articles and essays written by Alexander Hamilton, James Madison, and John Jay to promote the ratification of the Constitution.',
        facts: ['Published under the pseudonym "Publius".', 'Federalist No. 10 warns against factions.', 'Federalist No. 51 explains checks and balances.'],
        prompt: 'Analyze the Federalist Papers, focusing on No. 10 (Factions) and No. 51 (Checks and Balances). Use an analogy to explain "Ambition counteracting ambition".'
    },
    {
        id: 'bill_of_rights',
        title: 'Bill of Rights',
        year: '1791',
        description: 'The first ten amendments to the US Constitution, guaranteeing personal freedoms and rights.',
        facts: ['Drafted by James Madison.', 'Influenced by the Virginia Declaration of Rights.', 'Originally only applied to the Federal Government.'],
        prompt: 'Explain the Bill of Rights (Amendments 1-10) in detail and their importance to civil liberties. Use specific analogies for each amendment.'
    },
    {
        id: 'emancipation',
        title: 'Emancipation Proclamation',
        year: '1863',
        description: 'President Abraham Lincoln\'s executive order changing the federal legal status of more than 3.5 million enslaved African Americans in the designated areas of the South from slave to free.',
        facts: ['Issued as a war measure.', 'Did not free slaves in Union states initially.', 'Led to the 13th Amendment.'],
        prompt: 'Analyze the legal basis of the Emancipation Proclamation as an exercise of War Powers. How did it differ from the 13th Amendment?'
    },
    {
        id: 'gettysburg',
        title: 'Gettysburg Address',
        year: '1863',
        description: 'A speech by Abraham Lincoln during the Civil War. It redefined the war as not just a struggle for the Union, but as "a new birth of freedom".',
        facts: ['Only 272 words long.', 'Invoked the Declaration of Independence.', 'Redefined the purpose of the United States.'],
        prompt: 'Analyze the Gettysburg Address. How did Lincoln use this speech to redefine the purpose of the Civil War and the meaning of the Constitution?'
    }
];

// New Data for the Constitutional Clause Analyzer - ALL Amendments
export const CONSTITUTIONAL_SECTIONS = [
    { id: 'art1', title: 'Article I', subtitle: 'The Legislative Branch', prompt: 'Analyze Article I of the US Constitution clause-by-clause. Explain the powers of Congress, the Commerce Clause, and the Necessary and Proper Clause. Use analogies.' },
    { id: 'art2', title: 'Article II', subtitle: 'The Executive Branch', prompt: 'Analyze Article II of the US Constitution. Explain the powers of the Presidency, the Electoral College, and Impeachment. Use analogies.' },
    { id: 'art3', title: 'Article III', subtitle: 'The Judicial Branch', prompt: 'Analyze Article III of the US Constitution. Explain the power of the Supreme Court and Judicial Tenure. Use analogies.' },
    { id: 'art4', title: 'Article IV', subtitle: 'States\' Relations', prompt: 'Analyze Article IV. Explain the Full Faith and Credit Clause and Privileges and Immunities. Use an analogy.' },
    { id: 'art5', title: 'Article V', subtitle: 'Amendment Process', prompt: 'Explain Article V and the process for amending the Constitution. Use an analogy.' },
    { id: 'art6', title: 'Article VI', subtitle: 'Supremacy Clause', prompt: 'Explain Article VI. Discuss the Supremacy Clause and Oaths of Office. Use an analogy.' },
    { id: 'art7', title: 'Article VII', subtitle: 'Ratification', prompt: 'Explain Article VII and the history of Ratification.' },
    // Bill of Rights
    { id: 'amend1', title: '1st Amendment', subtitle: 'Freedom of Expression', prompt: 'Analyze the First Amendment clause-by-clause: Establishment, Free Exercise, Speech, Press, Assembly, and Petition. Use analogies for each.' },
    { id: 'amend2', title: '2nd Amendment', subtitle: 'Right to Bear Arms', prompt: 'Analyze the Second Amendment. Discuss the Prefatory Clause vs the Operative Clause and modern interpretation. Use an analogy.' },
    { id: 'amend3', title: '3rd Amendment', subtitle: 'Quartering Soldiers', prompt: 'Explain the Third Amendment and its privacy implications. Use an analogy.' },
    { id: 'amend4', title: '4th Amendment', subtitle: 'Search & Seizure', prompt: 'Analyze the Fourth Amendment. Explain "Reasonable Expectation of Privacy", Warrants, and Probable Cause using the "Castle Doctrine" analogy.' },
    { id: 'amend5', title: '5th Amendment', subtitle: 'Rights of Persons', prompt: 'Analyze the Fifth Amendment: Grand Jury, Double Jeopardy, Self-Incrimination, and Due Process. Use specific analogies.' },
    { id: 'amend6', title: '6th Amendment', subtitle: 'Rights of Accused', prompt: 'Analyze the Sixth Amendment: Speedy Trial, Impartial Jury, Confrontation Clause, and Right to Counsel. Use analogies.' },
    { id: 'amend7', title: '7th Amendment', subtitle: 'Civil Trials', prompt: 'Explain the Seventh Amendment and the right to jury trial in civil cases. Use an analogy.' },
    { id: 'amend8', title: '8th Amendment', subtitle: 'Cruel & Unusual', prompt: 'Analyze the Eighth Amendment. Discuss Bail, Fines, and Cruel and Unusual Punishment. Use an analogy.' },
    { id: 'amend9', title: '9th Amendment', subtitle: 'Unenumerated Rights', prompt: 'Explain the Ninth Amendment and the concept of rights retained by the people using an analogy (like a menu that doesn\'t list every possible dish).' },
    { id: 'amend10', title: '10th Amendment', subtitle: 'States\' Rights', prompt: 'Explain the Tenth Amendment and the principle of Federalism/Reserved Powers using the "Layer Cake" analogy.' },
    // Later Amendments
    { id: 'amend11', title: '11th Amendment', subtitle: 'Sovereign Immunity', prompt: 'Explain the 11th Amendment and how it restricts lawsuits against States. Use an analogy.' },
    { id: 'amend12', title: '12th Amendment', subtitle: 'Presidential Election', prompt: 'Explain the 12th Amendment and how it changed the Electoral College process.' },
    { id: 'amend13', title: '13th Amendment', subtitle: 'Abolition of Slavery', prompt: 'Analyze the 13th Amendment and the end of slavery.' },
    { id: 'amend14', title: '14th Amendment', subtitle: 'Equal Protection', prompt: 'Analyze the 14th Amendment. Explain the Citizenship Clause, Due Process Clause, and Equal Protection Clause. Discuss Incorporation Doctrine using an analogy.' },
    { id: 'amend15', title: '15th Amendment', subtitle: 'Voting Rights (Race)', prompt: 'Explain the 15th Amendment and voting rights regarding race.' },
    { id: 'amend16', title: '16th Amendment', subtitle: 'Income Tax', prompt: 'Explain the 16th Amendment and the power of Congress to levy income tax.' },
    { id: 'amend17', title: '17th Amendment', subtitle: 'Direct Senate Elections', prompt: 'Explain the 17th Amendment and the direct election of Senators.' },
    { id: 'amend18', title: '18th Amendment', subtitle: 'Prohibition', prompt: 'Explain the 18th Amendment (Prohibition) and its historical context.' },
    { id: 'amend19', title: '19th Amendment', subtitle: 'Women\'s Suffrage', prompt: 'Explain the 19th Amendment and the history of women\'s right to vote.' },
    { id: 'amend20', title: '20th Amendment', subtitle: 'Lame Duck', prompt: 'Explain the 20th Amendment regarding term start dates and presidential succession.' },
    { id: 'amend21', title: '21st Amendment', subtitle: 'Repeal of Prohibition', prompt: 'Explain the 21st Amendment, repealing the 18th Amendment.' },
    { id: 'amend22', title: '22nd Amendment', subtitle: 'Term Limits', prompt: 'Explain the 22nd Amendment and the two-term limit for Presidents.' },
    { id: 'amend23', title: '23rd Amendment', subtitle: 'DC Voting Rights', prompt: 'Explain the 23rd Amendment giving DC residents the right to vote for President.' },
    { id: 'amend24', title: '24th Amendment', subtitle: 'Poll Taxes', prompt: 'Explain the 24th Amendment banning poll taxes in federal elections.' },
    { id: 'amend25', title: '25th Amendment', subtitle: 'Presidential Succession', prompt: 'Analyze the 25th Amendment regarding presidential disability and succession.' },
    { id: 'amend26', title: '26th Amendment', subtitle: 'Voting Age (18)', prompt: 'Explain the 26th Amendment lowering the voting age to 18.' },
    { id: 'amend27', title: '27th Amendment', subtitle: 'Congressional Pay', prompt: 'Explain the 27th Amendment regarding Congressional salary changes.' },
];

export const US_CONSTITUTION_TEXT: ConstitutionSection[] = [
  {
    id: 'preamble',
    title: 'Preamble',
    content: `We the People of the United States, in Order to form a more perfect Union, establish Justice, insure domestic Tranquility, provide for the common defence, promote the general Welfare, and secure the Blessings of Liberty to ourselves and our Posterity, do ordain and establish this Constitution for the United States of America.`
  },
  {
    id: 'art1',
    title: 'Article I',
    subtitle: 'The Legislative Branch',
    content: `Section 1. All legislative Powers herein granted shall be vested in a Congress of the United States, which shall consist of a Senate and House of Representatives.

Section 2. The House of Representatives shall be composed of Members chosen every second Year by the People of the several States, and the Electors in each State shall have the Qualifications requisite for Electors of the most numerous Branch of the State Legislature...

Section 8. The Congress shall have Power To lay and collect Taxes, Duties, Imposts and Excises, to pay the Debts and provide for the common Defence and general Welfare of the United States... To regulate Commerce with foreign Nations, and among the several States, and with the Indian Tribes... To make all Laws which shall be necessary and proper for carrying into Execution the foregoing Powers...`
  },
  {
    id: 'art2',
    title: 'Article II',
    subtitle: 'The Executive Branch',
    content: `Section 1. The executive Power shall be vested in a President of the United States of America. He shall hold his Office during the Term of four Years, and, together with the Vice President, chosen for the same Term, be elected, as follows...

Section 2. The President shall be Commander in Chief of the Army and Navy of the United States, and of the Militia of the several States, when called into the actual Service of the United States...

Section 3. He shall from time to time give to the Congress Information of the State of the Union, and recommend to their Consideration such Measures as he shall judge necessary and expedient...

Section 4. The President, Vice President and all civil Officers of the United States, shall be removed from Office on Impeachment for, and Conviction of, Treason, Bribery, or other high Crimes and Misdemeanors.`
  },
  {
    id: 'art3',
    title: 'Article III',
    subtitle: 'The Judicial Branch',
    content: `Section 1. The judicial Power of the United States, shall be vested in one supreme Court, and in such inferior Courts as the Congress may from time to time ordain and establish. The Judges, both of the supreme and inferior Courts, shall hold their Offices during good Behaviour...

Section 2. The judicial Power shall extend to all Cases, in Law and Equity, arising under this Constitution, the Laws of the United States, and Treaties made, or which shall be made, under their Authority...

Section 3. Treason against the United States, shall consist only in levying War against them, or in adhering to their Enemies, giving them Aid and Comfort. No Person shall be convicted of Treason unless on the Testimony of two Witnesses to the same overt Act, or on Confession in open Court.`
  },
  {
    id: 'art4',
    title: 'Article IV',
    subtitle: 'States\' Relations',
    content: `Section 1. Full Faith and Credit shall be given in each State to the public Acts, Records, and judicial Proceedings of every other State...

Section 2. The Citizens of each State shall be entitled to all Privileges and Immunities of Citizens in the several States.`
  },
  {
    id: 'art5',
    title: 'Article V',
    subtitle: 'Amendment Process',
    content: `The Congress, whenever two thirds of both Houses shall deem it necessary, shall propose Amendments to this Constitution, or, on the Application of the Legislatures of two thirds of the several States, shall call a Convention for proposing Amendments...`
  },
  {
    id: 'art6',
    title: 'Article VI',
    subtitle: 'Supremacy Clause',
    content: `This Constitution, and the Laws of the United States which shall be made in Pursuance thereof; and all Treaties made, or which shall be made, under the Authority of the United States, shall be the supreme Law of the Land; and the Judges in every State shall be bound thereby, any Thing in the Constitution or Laws of any State to the Contrary notwithstanding.`
  },
  {
    id: 'art7',
    title: 'Article VII',
    subtitle: 'Ratification',
    content: `The Ratification of the Conventions of nine States, shall be sufficient for the Establishment of this Constitution between the States so ratifying the Same.`
  },
  {
    id: 'amendments_1_10',
    title: 'Amendments I-X',
    subtitle: 'The Bill of Rights (Ratified 1791)',
    content: `Amendment I. Congress shall make no law respecting an establishment of religion, or prohibiting the free exercise thereof; or abridging the freedom of speech, or of the press; or the right of the people peaceably to assemble, and to petition the Government for a redress of grievances.

Amendment II. A well regulated Militia, being necessary to the security of a free State, the right of the people to keep and bear Arms, shall not be infringed.

Amendment III. No Soldier shall, in time of peace be quartered in any house, without the consent of the Owner, nor in time of war, but in a manner to be prescribed by law.

Amendment IV. The right of the people to be secure in their persons, houses, papers, and effects, against unreasonable searches and seizures, shall not be violated, and no Warrants shall issue, but upon probable cause, supported by Oath or affirmation, and particularly describing the place to be searched, and the persons or things to be seized.

Amendment V. No person shall be held to answer for a capital, or otherwise infamous crime, unless on a presentment or indictment of a Grand Jury... nor shall any person be subject for the same offence to be twice put in jeopardy of life or limb; nor shall be compelled in any criminal case to be a witness against himself, nor be deprived of life, liberty, or property, without due process of law...

Amendment VI. In all criminal prosecutions, the accused shall enjoy the right to a speedy and public trial, by an impartial jury of the State and district wherein the crime shall have been committed... and to have the Assistance of Counsel for his defence.

Amendment VII. In Suits at common law, where the value in controversy shall exceed twenty dollars, the right of trial by jury shall be preserved...

Amendment VIII. Excessive bail shall not be required, nor excessive fines imposed, nor cruel and unusual punishments inflicted.

Amendment IX. The enumeration in the Constitution, of certain rights, shall not be construed to deny or disparage others retained by the people.

Amendment X. The powers not delegated to the United States by the Constitution, nor prohibited by it to the States, are reserved to the States respectively, or to the people.`
  },
  {
    id: 'amendments_11_27',
    title: 'Amendments XI-XXVII',
    subtitle: 'Later Amendments',
    content: `(Includes the 13th Amendment abolishing slavery, the 14th Amendment establishing Equal Protection, the 19th Amendment granting women the right to vote, and more.)
    
    [Full text available via specific query to The People's Law AI]`
  }
];