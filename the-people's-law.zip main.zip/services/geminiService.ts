import { GoogleGenAI, Chat, GenerateContentResponse, Modality } from "@google/genai";
import { SYSTEM_INSTRUCTION, SOCRATIC_INSTRUCTION, QUIZ_PROMPT, CURRICULUM_GENERATION_PROMPT } from "../constants";
import { GroundingSource, QuizQuestion, TutorMode, LearningModule, UserStats } from "../types";

// Initialize the API client
const getClient = () => new GoogleGenAI({ apiKey: process.env.API_KEY });

let chatSession: Chat | null = null;
let currentMode: TutorMode = 'standard';
let currentUserStatsStr: string = '';

export const resetChat = () => {
  chatSession = null;
};

// Now accepts a mode to determine instruction
export const getChatSession = (mode: TutorMode = 'standard', userStats?: UserStats): Chat => {
  // If the mode changed or user stats significantly changed, we reset
  const userStatsStr = userStats ? `User Level: ${userStats.level}` : '';
  
  if (chatSession && (currentMode !== mode || currentUserStatsStr !== userStatsStr)) {
    chatSession = null;
  }
  currentMode = mode;
  currentUserStatsStr = userStatsStr;

  if (!chatSession) {
    const ai = getClient();
    let instruction = mode === 'socratic' 
      ? `${SYSTEM_INSTRUCTION}\n\n${SOCRATIC_INSTRUCTION}` 
      : SYSTEM_INSTRUCTION;

    // Inject User Context for Adaptive Learning
    if (userStats) {
       instruction += `\n\nUSER CONTEXT:\n- Legal Knowledge Level: ${userStats.level}\n- Questions Answered: ${userStats.questionsAnswered}`;
       if (userStats.level === 'Law Student' || userStats.level === 'Associate') {
           instruction += `\n(The user is learning. Use more analogies and simple explanations.)`;
       } else {
           instruction += `\n(The user is advanced. You may use more technical legal terminology.)`;
       }
    }

    chatSession = ai.chats.create({
      model: 'gemini-2.5-flash', 
      config: {
        systemInstruction: instruction,
        tools: [{ googleSearch: {} }],
      },
    });
  }
  return chatSession;
};

export const generateQuizQuestion = async (userStats?: UserStats): Promise<QuizQuestion> => {
    const ai = getClient();
    try {
        let prompt = QUIZ_PROMPT;
        
        // Adaptive Logic: Find weak areas
        if (userStats) {
            const weakTopics = Object.entries(userStats.topicScores)
                .filter(([_, score]) => score < 0)
                .map(([topic]) => topic);
            
            if (weakTopics.length > 0) {
                // Pick a random weak topic to reinforce
                const targetTopic = weakTopics[Math.floor(Math.random() * weakTopics.length)];
                prompt += `\n\nADAPTIVE INSTRUCTION: The user is struggling with "${targetTopic}". Generate a question about this topic to help them practice.`;
            } else if (userStats.level === 'Senior Counsel' || userStats.level === 'Partner') {
                prompt += `\n\nADAPTIVE INSTRUCTION: The user is an expert. Generate a 'Hard' difficulty question involving complex case law nuances.`;
            }
        }

        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: prompt,
            config: {
                responseMimeType: 'application/json'
            }
        });

        if (response.text) {
            return JSON.parse(response.text) as QuizQuestion;
        }
        throw new Error("No data returned");
    } catch (e) {
        console.error("Quiz generation failed", e);
        return {
            question: "Which Supreme Court case established Judicial Review?",
            options: ["Roe v. Wade", "Marbury v. Madison", "McCulloch v. Maryland", "Gibbons v. Ogden"],
            correctAnswerIndex: 1,
            explanation: "Marbury v. Madison (1803) is the landmark case where the Supreme Court asserted its power to review acts of Congress and declare them unconstitutional.",
            topic: "Federal Power",
            difficulty: "Easy"
        };
    }
};

export const generateCustomCurriculum = async (goal: string): Promise<LearningModule | null> => {
  const ai = getClient();
  try {
    const prompt = CURRICULUM_GENERATION_PROMPT.replace('{{GOAL}}', goal);
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json'
      }
    });

    if (response.text) {
      return JSON.parse(response.text) as LearningModule;
    }
    return null;
  } catch (e) {
    console.error("Curriculum generation failed", e);
    return null;
  }
};

/**
 * Generates high-quality speech using Gemini's TTS model
 * @param text The text to speak
 * @param voiceName The specific voice model to use ('Fenrir' = Male, 'Kore' = Female)
 */
export const generateSpeech = async (text: string, voiceName: string = 'Fenrir'): Promise<string | null> => {
  const ai = getClient();
  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash-preview-tts",
      contents: [{ parts: [{ text: text }] }],
      config: {
        responseModalities: [Modality.AUDIO],
        speechConfig: {
            voiceConfig: {
              prebuiltVoiceConfig: { voiceName: voiceName },
            },
        },
      },
    });

    const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
    return base64Audio || null;
  } catch (error) {
    console.error("TTS Generation Error:", error);
    return null;
  }
};

/**
 * Sends a message to the Gemini API and yields chunks of text as they arrive.
 */
export async function* sendMessageStream(
  message: string,
  mode: TutorMode = 'standard',
  userStats?: UserStats
): AsyncGenerator<{ text: string; groundingSources?: GroundingSource[] }, void, unknown> {
  const chat = getChatSession(mode, userStats);
  let fullText = "";
  let groundingSources: GroundingSource[] = [];

  try {
    const resultStream = await chat.sendMessageStream({ message });

    for await (const chunk of resultStream) {
      const c = chunk as GenerateContentResponse;
      
      if (c.text) {
        fullText += c.text;
        yield { text: fullText, groundingSources };
      }

      const candidates = c.candidates;
      if (candidates && candidates.length > 0) {
        const metadata = candidates[0].groundingMetadata;
        if (metadata?.groundingChunks) {
          const newSources: GroundingSource[] = [];
          
          metadata.groundingChunks.forEach((chunk: any) => {
             if (chunk.web?.uri && chunk.web?.title) {
               newSources.push({
                 title: chunk.web.title,
                 uri: chunk.web.uri
               });
             }
          });

          if (newSources.length > 0) {
            groundingSources = [...groundingSources, ...newSources];
            groundingSources = groundingSources.filter((v, i, a) => a.findIndex(t => (t.uri === v.uri)) === i);
            yield { text: fullText, groundingSources };
          }
        }
      }
    }
  } catch (error) {
    console.error("Error in Gemini stream:", error);
    throw error;
  }
}